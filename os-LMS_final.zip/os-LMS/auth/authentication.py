"""
Authentication module for Smart LMS.
Implements PBKDF2-HMAC-SHA256 password hashing and role-based access control.
"""
import hashlib
import os
import secrets
from typing import Optional, Dict, Any

class Authenticator:
    @staticmethod
    def hash_password(password: str, salt: Optional[str] = None) -> str:
        """Hash a password using PBKDF2-HMAC-SHA256 with a secure salt."""
        if not salt:
            salt = secrets.token_hex(16)
        
        # 100,000 iterations of PBKDF2
        key = hashlib.pbkdf2_hmac(
            'sha256',
            password.encode('utf-8'),
            salt.encode('utf-8'),
            100000
        )
        return f"{salt}${key.hex()}"

    @staticmethod
    def verify_password(stored_hash: str, provided_password: str) -> bool:
        """Verify a stored hash against the provided password."""
        try:
            salt, key_hex = stored_hash.split('$')
            new_key = hashlib.pbkdf2_hmac(
                'sha256',
                provided_password.encode('utf-8'),
                salt.encode('utf-8'),
                100000
            )
            return secrets.compare_digest(new_key.hex(), key_hex)
        except Exception:
            return False

    @staticmethod
    def validate_user_access(user: Dict[str, Any], required_role: str) -> bool:
        """Check whether user has required role and active status."""
        if not user or not user.get("is_active", True):
            return False
        if required_role == "admin":
            return user.get("role") == "admin"
        if required_role == "teacher":
            return user.get("role") in ["admin", "teacher"]
        if required_role == "student":
            return user.get("role") in ["admin", "teacher", "student"]
        return True
