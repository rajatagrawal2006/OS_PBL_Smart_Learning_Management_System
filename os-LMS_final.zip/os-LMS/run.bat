@echo off
echo ========================================================
echo   Launching Smart LMS (with Operating System Simulator)
echo ========================================================
echo.
python main.py
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo An error occurred while launching. Make sure Python 3.10+ is installed and in PATH.
    pause
)
