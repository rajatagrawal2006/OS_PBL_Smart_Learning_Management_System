"""
OS Simulator - Deadlock Simulation View.
Follows Panel 4.6 of UI Blueprint with enhanced interactive simulation:
- Editable Resource Allocation Table (Processes P1..P3, Resources R1..R3)
- Editable Resource Request Table (Waiting For)
- Editable Available Resources Vector (Work Pool)
- Truly Dynamic Resource Allocation Graph (RAG) with real directed edges & cycle highlighting
- Step-by-step animated simulation trace for Banker's Algorithm & cycle detection
- Presets: Load Safe State, Load Deadlock State, Reset Matrix
- Immediate visual feedback and detailed execution log on Run Detection
"""
import math
import time
import tkinter as tk
from tkinter import ttk, messagebox
from typing import Dict, Any, Callable, List, Optional, Tuple

try:
    from config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_DANGER, COLOR_SUCCESS, COLOR_WARNING
    )
    from os_simulator.deadlock import DeadlockDetector
    from gui.components import ContentCard, PrimaryButton, SecondaryButton
except ImportError:
    from SmartLMS.config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_DANGER, COLOR_SUCCESS, COLOR_WARNING
    )
    from SmartLMS.os_simulator.deadlock import DeadlockDetector
    from SmartLMS.gui.components import ContentCard, PrimaryButton, SecondaryButton

class DeadlockPage(tk.Frame):
    def __init__(self, parent, current_user: Dict[str, Any], on_navigate: Callable[[str], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.user = current_user
        self.on_navigate = on_navigate
        self.detector = DeadlockDetector()

        # Tkinter entry storage for dynamic inputs
        self.alloc_entries: Dict[str, Dict[str, tk.Entry]] = {}
        self.req_entries: Dict[str, Dict[str, tk.Entry]] = {}
        self.avail_entries: Dict[str, tk.Entry] = {}

        # Simulation animation state
        self._sim_job: Optional[str] = None
        self._sim_step_index = 0
        self._sim_active_node: Optional[str] = None
        self._sim_completed_nodes: List[str] = []

        self._build_ui()
        self._load_matrix_into_ui()
        self.run_detection()

    def _build_ui(self):
        for widget in self.winfo_children():
            widget.destroy()

        container = tk.Frame(self, bg=COLOR_BG_LIGHT, padx=20, pady=16)
        container.pack(fill="both", expand=True)

        # -------------------------------------------------------------
        # Header with Title and Control Buttons
        # -------------------------------------------------------------
        header_frame = tk.Frame(container, bg=COLOR_BG_LIGHT)
        header_frame.pack(fill="x", pady=(0, 14))

        title_frame = tk.Frame(header_frame, bg=COLOR_BG_LIGHT)
        title_frame.pack(side="left")
        tk.Label(title_frame, text="Deadlock Simulation", font=("Segoe UI", 16, "bold"),
                 fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(anchor="w")
        tk.Label(title_frame, text="Interactive Resource Allocation Graph (RAG) & Banker's Safe State Simulation",
                 font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_BG_LIGHT).pack(anchor="w")

        # Top Buttons Bar
        btn_frame = tk.Frame(header_frame, bg=COLOR_BG_LIGHT)
        btn_frame.pack(side="right")

        SecondaryButton(btn_frame, text="🟢 Load Safe State", command=self._set_safe).pack(side="left", padx=3)
        SecondaryButton(btn_frame, text="🔴 Load Deadlock State", command=self._set_deadlock).pack(side="left", padx=3)
        SecondaryButton(btn_frame, text="↺ Clear / Reset", command=self._reset_matrix).pack(side="left", padx=3)
        PrimaryButton(btn_frame, text="⚡ Simulate Steps", command=self._start_step_simulation, bg_color="#7C3AED").pack(side="left", padx=3)
        PrimaryButton(btn_frame, text="▶ Run Detection", command=self.run_detection).pack(side="left", padx=3)

        # -------------------------------------------------------------
        # Main Split: Left Tables (60%), Right Graph & Log (40%)
        # -------------------------------------------------------------
        split_frame = tk.Frame(container, bg=COLOR_BG_LIGHT)
        split_frame.pack(fill="both", expand=True, pady=(0, 12))

        # Left Column: Editable Tables
        left_card = ContentCard(split_frame, title="Resource Matrices & Allocation State")
        left_card.pack(side="left", fill="both", expand=True, padx=(0, 8))

        # Allocation Table
        tk.Label(left_card, text="Resource Allocation Table (Held by Process)",
                 font=("Segoe UI", 10, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(anchor="w", pady=(0, 4))

        th = tk.Frame(left_card, bg="#F1F5F9", pady=4)
        th.pack(fill="x", pady=(0, 2))
        tk.Label(th, text="Process", font=("Segoe UI", 8, "bold"), width=10, anchor="w", bg="#F1F5F9").pack(side="left", padx=6)
        for r in self.detector.resources:
            tk.Label(th, text=r, font=("Segoe UI", 8, "bold"), width=8, anchor="center", bg="#F1F5F9").pack(side="left", padx=4)

        self.alloc_entries = {}
        for p in self.detector.processes:
            p_row = tk.Frame(left_card, bg=COLOR_CARD_WHITE, pady=3, highlightbackground=COLOR_BORDER, highlightthickness=1)
            p_row.pack(fill="x", pady=1)
            tk.Label(p_row, text=p, font=("Segoe UI", 9, "bold"), fg=COLOR_PRIMARY_BLUE, bg=COLOR_CARD_WHITE, width=10, anchor="w").pack(side="left", padx=6)
            self.alloc_entries[p] = {}
            for r in self.detector.resources:
                ent = tk.Entry(p_row, width=6, font=("Segoe UI", 9, "bold"), justify="center",
                               highlightthickness=1, highlightbackground=COLOR_BORDER, relief="flat")
                ent.pack(side="left", padx=8, pady=2)
                ent.bind("<KeyRelease>", lambda e: self._on_entry_change())
                self.alloc_entries[p][r] = ent

        # Request Table
        tk.Label(left_card, text="Resource Request Table (Waiting For)",
                 font=("Segoe UI", 10, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(anchor="w", pady=(10, 4))

        req_th = tk.Frame(left_card, bg="#F1F5F9", pady=4)
        req_th.pack(fill="x", pady=(0, 2))
        tk.Label(req_th, text="Process", font=("Segoe UI", 8, "bold"), width=10, anchor="w", bg="#F1F5F9").pack(side="left", padx=6)
        for r in self.detector.resources:
            tk.Label(req_th, text=r, font=("Segoe UI", 8, "bold"), width=8, anchor="center", bg="#F1F5F9").pack(side="left", padx=4)

        self.req_entries = {}
        for p in self.detector.processes:
            p_row = tk.Frame(left_card, bg=COLOR_CARD_WHITE, pady=3, highlightbackground=COLOR_BORDER, highlightthickness=1)
            p_row.pack(fill="x", pady=1)
            tk.Label(p_row, text=p, font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE, width=10, anchor="w").pack(side="left", padx=6)
            self.req_entries[p] = {}
            for r in self.detector.resources:
                ent = tk.Entry(p_row, width=6, font=("Segoe UI", 9, "bold"), justify="center",
                               highlightthickness=1, highlightbackground=COLOR_BORDER, relief="flat")
                ent.pack(side="left", padx=8, pady=2)
                ent.bind("<KeyRelease>", lambda e: self._on_entry_change())
                self.req_entries[p][r] = ent

        # Available Vector Row
        tk.Label(left_card, text="Available Resources Vector (Work Pool)",
                 font=("Segoe UI", 10, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(anchor="w", pady=(10, 4))

        avail_frame = tk.Frame(left_card, bg="#F8FAFC", pady=6, padx=8, highlightbackground=COLOR_BORDER, highlightthickness=1)
        avail_frame.pack(fill="x")
        tk.Label(avail_frame, text="Available Units: ", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MUTED, bg="#F8FAFC").pack(side="left", padx=(0, 8))

        self.avail_entries = {}
        for r in self.detector.resources:
            tk.Label(avail_frame, text=f"{r}:", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg="#F8FAFC").pack(side="left", padx=(4, 2))
            ent = tk.Entry(avail_frame, width=5, font=("Segoe UI", 9, "bold"), justify="center",
                           highlightthickness=1, highlightbackground=COLOR_BORDER, relief="flat")
            ent.pack(side="left", padx=(0, 10))
            ent.bind("<KeyRelease>", lambda e: self._on_entry_change())
            self.avail_entries[r] = ent

        # Right Column: Visual Graph + Trace Log
        right_card = ContentCard(split_frame, title="Resource Allocation Graph (RAG)")
        right_card.pack(side="right", fill="both", expand=True, padx=(8, 0))

        # Canvas for RAG
        self.graph_canvas = tk.Canvas(right_card, height=230, bg=COLOR_CARD_WHITE, highlightthickness=0)
        self.graph_canvas.pack(fill="x", expand=False)

        # Graph Legend
        legend_frame = tk.Frame(right_card, bg=COLOR_CARD_WHITE, pady=2)
        legend_frame.pack(fill="x", pady=(2, 6))
        tk.Label(legend_frame, text="Legend: ", font=("Segoe UI", 8, "bold"), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(side="left")
        tk.Label(legend_frame, text="■ Held (R→P) ", font=("Segoe UI", 8, "bold"), fg="#10B981", bg=COLOR_CARD_WHITE).pack(side="left")
        tk.Label(legend_frame, text="■ Request (P→R) ", font=("Segoe UI", 8, "bold"), fg="#3B82F6", bg=COLOR_CARD_WHITE).pack(side="left")
        tk.Label(legend_frame, text="■ Deadlock Cycle ", font=("Segoe UI", 8, "bold"), fg=COLOR_DANGER, bg=COLOR_CARD_WHITE).pack(side="left")

        # Live Simulation & Trace Log
        tk.Label(right_card, text="Simulation Trace Log", font=("Segoe UI", 9, "bold"),
                 fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(anchor="w", pady=(4, 2))
        log_frame = tk.Frame(right_card, bg="#0F172A", padx=8, pady=6)
        log_frame.pack(fill="both", expand=True)

        self.log_text = tk.Text(log_frame, bg="#0F172A", fg="#38BDF8", font=("Consolas", 8),
                                height=5, relief="flat", highlightthickness=0, wrap="word")
        self.log_text.pack(fill="both", expand=True)

        # -------------------------------------------------------------
        # Bottom Detection Banner Card
        # -------------------------------------------------------------
        self.banner_card = tk.Frame(container, bg="#FEE2E2", padx=16, pady=10,
                                    highlightbackground="#FCA5A5", highlightthickness=1)
        self.banner_card.pack(fill="x")

        self.banner_icon = tk.Label(self.banner_card, text="⚠️", font=("Segoe UI", 16), bg="#FEE2E2")
        self.banner_icon.pack(side="left", padx=(0, 10))

        text_box = tk.Frame(self.banner_card, bg="#FEE2E2")
        text_box.pack(side="left", fill="both", expand=True)

        self.banner_title = tk.Label(text_box, text="", font=("Segoe UI", 10, "bold"),
                                     fg=COLOR_DANGER, bg="#FEE2E2", anchor="w")
        self.banner_title.pack(anchor="w")

        self.banner_subtitle = tk.Label(text_box, text="", font=("Segoe UI", 8),
                                        fg="#7F1D1D", bg="#FEE2E2", anchor="w")
        self.banner_subtitle.pack(anchor="w")

        self.banner_time = tk.Label(self.banner_card, text="", font=("Segoe UI", 8),
                                    fg=COLOR_TEXT_MUTED, bg="#FEE2E2")
        self.banner_time.pack(side="right")

    def _read_entries_into_detector(self):
        """Read current user values from Entry widgets into the detector."""
        for p in self.detector.processes:
            for r in self.detector.resources:
                ent = self.alloc_entries.get(p, {}).get(r)
                if ent:
                    try:
                        val = int(ent.get().strip() or 0)
                    except ValueError:
                        val = 0
                    self.detector.allocation[p][r] = max(0, val)

        for p in self.detector.processes:
            for r in self.detector.resources:
                ent = self.req_entries.get(p, {}).get(r)
                if ent:
                    try:
                        val = int(ent.get().strip() or 0)
                    except ValueError:
                        val = 0
                    self.detector.request[p][r] = max(0, val)

        for r in self.detector.resources:
            ent = self.avail_entries.get(r)
            if ent:
                try:
                    val = int(ent.get().strip() or 0)
                except ValueError:
                    val = 0
                self.detector.available[r] = max(0, val)

    def _load_matrix_into_ui(self):
        """Populate the entry widgets from current detector state."""
        for p in self.detector.processes:
            for r in self.detector.resources:
                ent = self.alloc_entries.get(p, {}).get(r)
                if ent:
                    ent.delete(0, tk.END)
                    ent.insert(0, str(self.detector.allocation.get(p, {}).get(r, 0)))

        for p in self.detector.processes:
            for r in self.detector.resources:
                ent = self.req_entries.get(p, {}).get(r)
                if ent:
                    ent.delete(0, tk.END)
                    ent.insert(0, str(self.detector.request.get(p, {}).get(r, 0)))

        for r in self.detector.resources:
            ent = self.avail_entries.get(r)
            if ent:
                ent.delete(0, tk.END)
                ent.insert(0, str(self.detector.available.get(r, 0)))

    def _on_entry_change(self):
        """Triggered when user types in any entry field."""
        self._read_entries_into_detector()
        # Keep graph updated live with user edits
        res = self.detector.detect_deadlock()
        self._draw_graph(res)

    def _set_safe(self):
        """Loads a clearly distinct safe scenario with distinct tables."""
        self._stop_simulation()
        self.detector.set_safe_state()
        self._load_matrix_into_ui()
        self.run_detection()
        self._log("🟢 Loaded Safe State: Orderly resource distribution (No circular wait).")

    def _set_deadlock(self):
        """Loads a classic 3-way circular wait deadlock scenario."""
        self._stop_simulation()
        self.detector.set_deadlock_state()
        self._load_matrix_into_ui()
        self.run_detection()
        self._log("🔴 Loaded Deadlock State: Circular dependency (P1->R2->P2->R3->P3->R1->P1).")

    def _reset_matrix(self):
        """Clears all matrix entries to 0 for custom experimentation."""
        self._stop_simulation()
        self.detector.reset_state()
        self._load_matrix_into_ui()
        self.run_detection()
        self._log("↺ Matrix reset. You can now enter custom allocation and request values.")

    def run_detection(self):
        """Executes full deadlock detection and Banker's algorithm on current inputs."""
        self._stop_simulation()
        self._read_entries_into_detector()
        res = self.detector.detect_deadlock()
        has_deadlock = res.get("has_deadlock", False)
        now_str = time.strftime("%H:%M:%S")

        if has_deadlock:
            self.banner_card.config(bg="#FEE2E2", highlightbackground="#FCA5A5")
            self.banner_icon.config(text="⚠️", bg="#FEE2E2")
            self.banner_title.config(
                text=f"Deadlock Detected! Cycle: {res.get('cycle_string')}",
                fg=COLOR_DANGER, bg="#FEE2E2"
            )
            blocked_procs = ", ".join(res.get("deadlocked_processes", []))
            self.banner_subtitle.config(
                text=f"Circular wait detected among processes [{blocked_procs}]. System cannot progress.",
                fg="#991B1B", bg="#FEE2E2"
            )
            self.banner_time.config(text=f"Detected at {now_str}", bg="#FEE2E2")
            self._log(f"[{now_str}] ⚠️ Deadlock Detected: Cycle = {res.get('cycle_string')}")
        else:
            self.banner_card.config(bg="#DCFCE7", highlightbackground="#86EFAC")
            self.banner_icon.config(text="✅", bg="#DCFCE7")
            seq_str = res.get("safe_sequence_string", "All satisfied")
            self.banner_title.config(
                text=f"No Deadlock Detected! Safe Sequence: {seq_str}",
                fg=COLOR_SUCCESS, bg="#DCFCE7"
            )
            self.banner_subtitle.config(
                text="System is in a safe operational state. All processes can acquire resources and terminate.",
                fg="#166534", bg="#DCFCE7"
            )
            self.banner_time.config(text=f"Verified at {now_str}", bg="#DCFCE7")
            self._log(f"[{now_str}] ✅ System Safe: Safe Sequence = {seq_str}")

        # Update trace log with algorithm steps
        for step in res.get("simulation_steps", []):
            self._log(f"  • {step}")

        self._draw_graph(res)

    def _start_step_simulation(self):
        """Starts an animated, step-by-step evaluation of the simulation."""
        self._stop_simulation()
        self._read_entries_into_detector()
        is_safe, safe_seq, steps = self.detector.run_bankers_safety()

        self._log("\n⚡ Starting Step-by-Step Simulation...")
        self._sim_step_index = 0
        self._sim_completed_nodes = []
        self._sim_steps = steps
        self._sim_seq = safe_seq
        self._sim_safe = is_safe
        self._run_next_sim_step()

    def _run_next_sim_step(self):
        """Executes one simulation step and schedules the next one."""
        if self._sim_step_index < len(self._sim_seq):
            proc = self._sim_seq[self._sim_step_index]
            self._sim_active_node = proc
            self._log(f"⚡ Executing {proc}: Acquiring needed resources, terminating, and returning held resources...")

            res = self.detector.detect_deadlock()
            self._draw_graph(res, active_node=proc, completed_nodes=self._sim_completed_nodes)

            # Schedule release of resources after 700ms
            self._sim_job = self.after(750, self._step_release_resources, proc)
        else:
            self._sim_active_node = None
            res = self.detector.detect_deadlock()
            self._draw_graph(res, completed_nodes=self._sim_completed_nodes)
            if self._sim_safe:
                self._log("🎉 Simulation Finished: All processes completed safely!")
            else:
                self._log("⛔ Simulation Finished: Processes blocked due to deadlock / lack of available resources.")
            self._sim_job = None

    def _step_release_resources(self, proc: str):
        self._sim_completed_nodes.append(proc)
        self._sim_step_index += 1
        res = self.detector.detect_deadlock()
        self._draw_graph(res, active_node=None, completed_nodes=self._sim_completed_nodes)
        self._sim_job = self.after(600, self._run_next_sim_step)

    def _stop_simulation(self):
        if self._sim_job:
            try:
                self.after_cancel(self._sim_job)
            except Exception:
                pass
            self._sim_job = None
        self._sim_active_node = None
        self._sim_completed_nodes = []

    def _log(self, text: str):
        """Appends a line to the simulation text log."""
        self.log_text.insert(tk.END, text + "\n")
        self.log_text.see(tk.END)

    def _draw_graph(self, res: Dict[str, Any], active_node: Optional[str] = None, completed_nodes: Optional[List[str]] = None):
        """Dynamically draws the Resource Allocation Graph with exact real edges & cycles."""
        self.graph_canvas.delete("all")
        completed_nodes = completed_nodes or []
        cycle = res.get("cycle", [])
        has_deadlock = res.get("has_deadlock", False)

        # Build pair set of cycle edges for fast lookup
        cycle_edges = set()
        if has_deadlock and len(cycle) >= 2:
            for i in range(len(cycle) - 1):
                cycle_edges.add((cycle[i], cycle[i+1]))

        # Canvas Dimensions & Circular Node Layout
        # Centered circle with nodes positioned clockwise:
        # P1 (top), R2 (top-right), P2 (bottom-right), R3 (bottom), P3 (bottom-left), R1 (top-left)
        cx, cy = 180, 115
        radius = 80
        node_positions = {
            "P1": (cx, cy - radius),
            "R2": (round(cx + radius * math.cos(math.radians(-30))), round(cy + radius * math.sin(math.radians(-30)))),
            "P2": (round(cx + radius * math.cos(math.radians(30))), round(cy + radius * math.sin(math.radians(30)))),
            "R3": (cx, cy + radius),
            "P3": (round(cx + radius * math.cos(math.radians(150))), round(cy + radius * math.sin(math.radians(150)))),
            "R1": (round(cx + radius * math.cos(math.radians(210))), round(cy + radius * math.sin(math.radians(210))))
        }

        # -------------------------------------------------------------
        # Draw Directed Edges:
        # Allocation Edge: R -> P (Resource held by process)
        # Request Edge:    P -> R (Process waiting for resource)
        # -------------------------------------------------------------
        drawn_edges = []
        for p in self.detector.processes:
            for r in self.detector.resources:
                # Allocation: R -> P
                alloc_val = self.detector.allocation.get(p, {}).get(r, 0)
                if alloc_val > 0:
                    is_in_cycle = (r, p) in cycle_edges
                    drawn_edges.append((r, p, alloc_val, "allocation", is_in_cycle))

                # Request: P -> R
                req_val = self.detector.request.get(p, {}).get(r, 0)
                if req_val > 0:
                    is_in_cycle = (p, r) in cycle_edges
                    drawn_edges.append((p, r, req_val, "request", is_in_cycle))

        # Draw non-cycle edges first, then cycle edges on top for clarity
        sorted_edges = sorted(drawn_edges, key=lambda x: x[4])

        node_radius = 18
        for u, v, val, kind, is_cycle in sorted_edges:
            if u in node_positions and v in node_positions:
                x1, y1 = node_positions[u]
                x2, y2 = node_positions[v]

                dx = x2 - x1
                dy = y2 - y1
                dist = math.hypot(dx, dy)
                if dist == 0:
                    continue

                # Adjust start and end coordinates to touch node boundaries
                sx = x1 + (dx / dist) * node_radius
                sy = y1 + (dy / dist) * node_radius
                ex = x2 - (dx / dist) * (node_radius + 2)
                ey = y2 - (dy / dist) * (node_radius + 2)

                if is_cycle:
                    edge_color = COLOR_DANGER
                    edge_width = 3
                elif kind == "allocation":
                    edge_color = "#10B981"  # Emerald green for held allocation
                    edge_width = 2
                else:
                    edge_color = "#3B82F6"  # Blue for requested resources
                    edge_width = 2

                self.graph_canvas.create_line(
                    sx, sy, ex, ey,
                    arrow=tk.LAST, arrowshape=(9, 11, 4),
                    width=edge_width, fill=edge_color
                )

                # If allocation/request count > 1, draw a small count pill
                if val > 1:
                    mx = (sx + ex) / 2
                    my = (sy + ey) / 2
                    self.graph_canvas.create_oval(mx - 8, my - 8, mx + 8, my + 8, fill="#FFFFFF", outline=edge_color)
                    self.graph_canvas.create_text(mx, my, text=str(val), font=("Segoe UI", 7, "bold"), fill=edge_color)

        # -------------------------------------------------------------
        # Draw Nodes: Processes (Circles) & Resources (Rounded Squares)
        # -------------------------------------------------------------
        for name, (nx, ny) in node_positions.items():
            is_proc = name.startswith("P")
            is_in_cycle = name in cycle and has_deadlock
            is_active = (name == active_node)
            is_done = (name in completed_nodes)

            if is_proc:
                # Process Node (Circle)
                if is_active:
                    fill_col = "#FEF08A"   # Bright gold
                    border_col = "#CA8A04"
                    txt_col = "#713F12"
                elif is_done:
                    fill_col = "#DCFCE7"   # Success green
                    border_col = "#16A34A"
                    txt_col = "#14532D"
                elif is_in_cycle:
                    fill_col = "#FEE2E2"   # Danger soft red
                    border_col = COLOR_DANGER
                    txt_col = "#991B1B"
                else:
                    fill_col = "#DBEAFE"   # Soft blue
                    border_col = "#2563EB"
                    txt_col = "#1E3A8A"

                r = node_radius
                self.graph_canvas.create_oval(
                    nx - r, ny - r, nx + r, ny + r,
                    fill=fill_col, outline=border_col, width=2.5 if (is_in_cycle or is_active) else 1.5
                )
                self.graph_canvas.create_text(
                    nx, ny, text=name,
                    font=("Segoe UI", 8, "bold"), fill=txt_col
                )
            else:
                # Resource Node (Square / Box)
                if is_in_cycle:
                    fill_col = "#FFEDD5"
                    border_col = "#EA580C"
                    txt_col = "#9A3412"
                else:
                    fill_col = "#F1F5F9"
                    border_col = "#64748B"
                    txt_col = "#334155"

                s = node_radius - 1
                self.graph_canvas.create_rectangle(
                    nx - s, ny - s, nx + s, ny + s,
                    fill=fill_col, outline=border_col, width=2 if is_in_cycle else 1.5
                )
                self.graph_canvas.create_text(
                    nx, ny, text=name,
                    font=("Segoe UI", 8, "bold"), fill=txt_col
                )
