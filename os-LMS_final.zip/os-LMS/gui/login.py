"""
Login View for Smart LMS.
Provides role-separated authentication for:
1. Student Profile (opens Student Dashboard only)
2. Teacher Profile (opens Teacher Dashboard only)
3. Administrator Profile (opens Admin Dashboard & OS Simulator)

Validates credentials via PBKDF2-HMAC-SHA256 and passes authenticated user to main controller.
Includes Sign Up for students & faculty.
"""
import tkinter as tk
from tkinter import ttk, messagebox
from typing import Callable, Dict, Any
from datetime import datetime

try:
    from config import (
        COLOR_PRIMARY_DARK, COLOR_PRIMARY_BLUE, COLOR_BG_LIGHT,
        COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_BORDER, COLOR_SUCCESS, COLOR_WARNING, COLOR_DANGER
    )
    from auth.authentication import Authenticator
    from storage.json_store import JSONStore, ActivityLogger
    from gui.components import PrimaryButton
except ImportError:
    from SmartLMS.config import (
        COLOR_PRIMARY_DARK, COLOR_PRIMARY_BLUE, COLOR_BG_LIGHT,
        COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_BORDER, COLOR_SUCCESS, COLOR_WARNING, COLOR_DANGER
    )
    from SmartLMS.auth.authentication import Authenticator
    from SmartLMS.storage.json_store import JSONStore, ActivityLogger
    from SmartLMS.gui.components import PrimaryButton

class LoginFrame(tk.Frame):
    def __init__(self, parent, on_login_success: Callable[[Dict[str, Any]], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.on_login_success = on_login_success
        self.users_store = JSONStore("users.json")
        self.selected_role = "student"  # 'student', 'teacher', or 'admin'
        self._build_ui()

    def _build_ui(self):
        # Clear if re-building
        for w in self.winfo_children():
            w.destroy()

        container = tk.Frame(self, bg=COLOR_BG_LIGHT)
        container.place(relx=0.5, rely=0.5, anchor="center")

        # Main Login Card
        card = tk.Frame(
            container, bg=COLOR_CARD_WHITE, padx=36, pady=28,
            highlightbackground=COLOR_BORDER, highlightthickness=1
        )
        card.pack()

        # Logo / Brand Header
        logo_frame = tk.Frame(card, bg=COLOR_CARD_WHITE)
        logo_frame.pack(pady=(0, 14))

        tk.Label(
            logo_frame, text="🎓 Smart LMS",
            font=("Segoe UI", 20, "bold"),
            fg=COLOR_PRIMARY_DARK, bg=COLOR_CARD_WHITE
        ).pack()

        tk.Label(
            logo_frame, text="Learning Management System with OS Architecture",
            font=("Segoe UI", 9),
            fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE
        ).pack(pady=(2, 0))

        # Role Selector Buttons (Student / Teacher / Admin Profiles)
        role_select_frame = tk.Frame(card, bg="#F1F5F9", padx=4, pady=4, highlightbackground=COLOR_BORDER, highlightthickness=1)
        role_select_frame.pack(fill="x", pady=(0, 14))

        roles = [
            ("student", "👨‍🎓 Student", "rohan", "student123"),
            ("teacher", "👨‍🏫 Teacher", "drsharma", "teacher123"),
            ("admin", "🛡️ Admin", "admin", "admin123")
        ]

        self.role_buttons = {}
        for role_key, role_label, def_u, def_p in roles:
            is_active = self.selected_role == role_key
            btn = tk.Button(
                role_select_frame,
                text=role_label,
                font=("Segoe UI", 9, "bold" if is_active else "normal"),
                bg=COLOR_PRIMARY_BLUE if is_active else "#F1F5F9",
                fg="white" if is_active else COLOR_TEXT_MAIN,
                activebackground=COLOR_PRIMARY_BLUE,
                activeforeground="white",
                relief="flat",
                padx=10,
                pady=6,
                cursor="hand2",
                command=lambda r=role_key, u=def_u, p=def_p: self._select_role_profile(r, u, p)
            )
            btn.pack(side="left", fill="both", expand=True, padx=2)
            self.role_buttons[role_key] = btn

        # Error label
        self.error_label = tk.Label(card, text="", font=("Segoe UI", 9), fg="#EF4444", bg=COLOR_CARD_WHITE)
        self.error_label.pack(pady=(0, 4))

        # Username Field
        tk.Label(card, text="Username", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE, anchor="w").pack(fill="x")
        self.username_var = tk.StringVar(value="rohan" if self.selected_role == "student" else ("drsharma" if self.selected_role == "teacher" else "admin"))
        self.username_entry = tk.Entry(card, textvariable=self.username_var, font=("Segoe UI", 10),
                                       relief="solid", bd=1, highlightthickness=0)
        self.username_entry.pack(fill="x", pady=(3, 10), ipady=3)

        # Password Field
        tk.Label(card, text="Password", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE, anchor="w").pack(fill="x")
        self.password_var = tk.StringVar(value="student123" if self.selected_role == "student" else ("teacher123" if self.selected_role == "teacher" else "admin123"))
        self.password_entry = tk.Entry(card, textvariable=self.password_var, show="•", font=("Segoe UI", 10),
                                       relief="solid", bd=1, highlightthickness=0)
        self.password_entry.pack(fill="x", pady=(3, 14), ipady=3)
        self.password_entry.bind("<Return>", lambda e: self.do_login())

        # Login Button
        self.login_btn = PrimaryButton(card, text=f"Sign In as {self.selected_role.capitalize()}", command=self.do_login)
        self.login_btn.pack(fill="x", ipady=3)

        # Sign Up Section
        signup_row = tk.Frame(card, bg=COLOR_CARD_WHITE)
        signup_row.pack(fill="x", pady=(14, 0))

        tk.Label(signup_row, text="New user? ", font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(side="left")
        tk.Button(
            signup_row, text="Sign Up / Register", font=("Segoe UI", 9, "bold"), fg=COLOR_PRIMARY_BLUE, bg=COLOR_CARD_WHITE,
            relief="flat", cursor="hand2", command=self._open_signup_dialog
        ).pack(side="left")

    def _select_role_profile(self, role: str, default_user: str, default_pass: str):
        self.selected_role = role
        self.username_var.set(default_user)
        self.password_var.set(default_pass)
        self.error_label.config(text="")
        self._build_ui()

    def _quick_shortcut_login(self, u_name: str, u_pass: str):
        self.username_var.set(u_name)
        self.password_var.set(u_pass)
        self.do_login()

    def _open_signup_dialog(self):
        dialog = tk.Toplevel(self)
        dialog.title("Sign Up — Smart LMS")
        dialog.geometry("400x380")
        dialog.configure(bg="white")
        dialog.transient(self)
        dialog.grab_set()

        pad_f = tk.Frame(dialog, bg="white", padx=24, pady=20)
        pad_f.pack(fill="both", expand=True)

        tk.Label(pad_f, text="Create New Profile", font=("Segoe UI", 14, "bold"), fg=COLOR_PRIMARY_DARK, bg="white").pack(anchor="w")
        tk.Label(pad_f, text="Minimal details to register as a student or teacher", font=("Segoe UI", 8), fg=COLOR_TEXT_MUTED, bg="white").pack(anchor="w", pady=(0, 14))

        # Role select
        role_var = tk.StringVar(value="student")
        r_frame = tk.Frame(pad_f, bg="#F1F5F9", padx=4, pady=4)
        r_frame.pack(fill="x", pady=(0, 12))
        tk.Radiobutton(r_frame, text="Student Profile", variable=role_var, value="student", bg="#F1F5F9", font=("Segoe UI", 9, "bold")).pack(side="left", padx=8)
        tk.Radiobutton(r_frame, text="Teacher Profile", variable=role_var, value="teacher", bg="#F1F5F9", font=("Segoe UI", 9, "bold")).pack(side="left", padx=8)

        # Name
        tk.Label(pad_f, text="Full Name *", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg="white").pack(anchor="w")
        name_entry = tk.Entry(pad_f, font=("Segoe UI", 10), relief="solid", bd=1)
        name_entry.pack(fill="x", pady=(2, 8), ipady=2)

        # Username
        tk.Label(pad_f, text="Username *", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg="white").pack(anchor="w")
        user_entry = tk.Entry(pad_f, font=("Segoe UI", 10), relief="solid", bd=1)
        user_entry.pack(fill="x", pady=(2, 8), ipady=2)

        # Password
        tk.Label(pad_f, text="Password *", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg="white").pack(anchor="w")
        pass_entry = tk.Entry(pad_f, show="•", font=("Segoe UI", 10), relief="solid", bd=1)
        pass_entry.pack(fill="x", pady=(2, 14), ipady=2)

        def submit_signup():
            name = name_entry.get().strip()
            uname = user_entry.get().strip().lower()
            pwd = pass_entry.get().strip()
            role = role_var.get()

            if not name or not uname or not pwd:
                messagebox.showerror("Error", "Please fill in all fields.", parent=dialog)
                return

            users = self.users_store.load_all()
            if any(u.get("username", "").lower() == uname for u in users):
                messagebox.showerror("Error", f"Username '{uname}' is already taken.", parent=dialog)
                return

            new_user = Authenticator.register_user(name, uname, pwd, role)
            messagebox.showinfo("Success", f"Account created for {name}! Signing you in...", parent=dialog)
            dialog.destroy()
            self.on_login_success(new_user)

        PrimaryButton(pad_f, text="Create Account & Sign In", command=submit_signup).pack(fill="x", ipady=3)

    def do_login(self):
        username = self.username_var.get().strip()
        password = self.password_var.get().strip()

        if not username or not password:
            self.error_label.config(text="Please enter both username and password.")
            return

        users = self.users_store.load_all()
        matched = None
        for u in users:
            if u.get("username", "").lower() == username.lower():
                matched = u
                break

        if not matched:
            self.error_label.config(text="Invalid username or password.")
            return

        if not matched.get("is_active", True):
            self.error_label.config(text="Account deactivated. Contact administrator.")
            return

        is_valid = Authenticator.verify_password(matched.get("password_hash", ""), password)
        if not is_valid:
            self.error_label.config(text="Invalid username or password.")
            return

        # Verify role matches selected profile
        actual_role = matched.get("role", "")
        if self.selected_role and actual_role != self.selected_role:
            self.selected_role = actual_role

        ActivityLogger.log(f"User logged in ({matched.get('name')}) as {matched.get('role').upper()}", user=matched.get("name"))
        self.on_login_success(matched)
