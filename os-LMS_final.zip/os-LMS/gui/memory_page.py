"""
OS Simulator - Memory Management View.
Follows Panel 4.3 of UI Blueprint:
- Algorithm selector: First Fit, Best Fit
- Request Memory (MB) and Process selection
- [ Allocate ] (blue), [ Release ] (orange/red), [ Reset ]
- Visual Simulated Memory map (1000 MB) with partition colors
- Memory Blocks Table (Start MB, Size MB, Status, Process)
"""
import tkinter as tk
from tkinter import ttk, messagebox
from typing import Dict, Any, Callable

try:
    from config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_SUCCESS, COLOR_DANGER
    )
    from os_simulator.memory_manager import MemoryManager, TOTAL_MEMORY_SIZE
    from gui.components import ContentCard, PrimaryButton, SecondaryButton, BadgeLabel
except ImportError:
    from SmartLMS.config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_SUCCESS, COLOR_DANGER
    )
    from SmartLMS.os_simulator.memory_manager import MemoryManager, TOTAL_MEMORY_SIZE
    from SmartLMS.gui.components import ContentCard, PrimaryButton, SecondaryButton, BadgeLabel

class MemoryPage(tk.Frame):
    def __init__(self, parent, current_user: Dict[str, Any], on_navigate: Callable[[str], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.user = current_user
        self.on_navigate = on_navigate
        self.mem_mgr = MemoryManager()
        self._build_ui()

    def _build_ui(self):
        for widget in self.winfo_children():
            widget.destroy()

        container = tk.Frame(self, bg=COLOR_BG_LIGHT, padx=24, pady=20)
        container.pack(fill="both", expand=True)

        # Header
        header_frame = tk.Frame(container, bg=COLOR_BG_LIGHT)
        header_frame.pack(fill="x", pady=(0, 16))

        title_frame = tk.Frame(header_frame, bg=COLOR_BG_LIGHT)
        title_frame.pack(side="left")
        tk.Label(title_frame, text="Memory Management", font=("Segoe UI", 16, "bold"),
                 fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(anchor="w")
        tk.Label(title_frame, text="Simulate memory allocation algorithms (First Fit, Best Fit) in 1000 MB pool",
                 font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_BG_LIGHT).pack(anchor="w")

        # Controls Card
        ctrl_card = ContentCard(container)
        ctrl_card.pack(fill="x", pady=(0, 16))

        c_row = tk.Frame(ctrl_card, bg=COLOR_CARD_WHITE)
        c_row.pack(fill="x")

        # Select Algorithm
        tk.Label(c_row, text="Select Algorithm", font=("Segoe UI", 8, "bold"), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).grid(row=0, column=0, sticky="w", padx=6)
        self.algo_var = tk.StringVar(value="First Fit")
        algo_combo = ttk.Combobox(c_row, textvariable=self.algo_var, values=["First Fit", "Best Fit"], state="readonly", width=14)
        algo_combo.grid(row=1, column=0, padx=6, pady=2)

        # Process ID
        tk.Label(c_row, text="Process", font=("Segoe UI", 8, "bold"), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).grid(row=0, column=1, sticky="w", padx=6)
        self.proc_var = tk.StringVar(value="P4")
        proc_entry = tk.Entry(c_row, textvariable=self.proc_var, width=10, font=("Segoe UI", 9), relief="solid", bd=1)
        proc_entry.grid(row=1, column=1, padx=6, pady=2, ipady=2)

        # Request Memory
        tk.Label(c_row, text="Request Memory (MB)", font=("Segoe UI", 8, "bold"), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).grid(row=0, column=2, sticky="w", padx=6)
        self.mem_var = tk.StringVar(value="150")
        mem_entry = tk.Entry(c_row, textvariable=self.mem_var, width=12, font=("Segoe UI", 9), relief="solid", bd=1)
        mem_entry.grid(row=1, column=2, padx=6, pady=2, ipady=2)

        # Buttons
        PrimaryButton(c_row, text="Allocate", command=self._do_allocate).grid(row=1, column=3, padx=8)
        PrimaryButton(c_row, text="Release", command=self._do_release, bg_color="#EF4444").grid(row=1, column=4, padx=4)
        SecondaryButton(c_row, text="Reset Pool", command=self._do_reset).grid(row=1, column=5, padx=8)

        # Visual Memory Section Card
        vis_card = ContentCard(container, title=f"Simulated Memory ({TOTAL_MEMORY_SIZE} MB)")
        vis_card.pack(fill="x", pady=(0, 16))

        summary = self.mem_mgr.get_summary()
        stat_bar = tk.Frame(vis_card, bg=COLOR_CARD_WHITE)
        stat_bar.pack(fill="x", pady=(0, 10))
        tk.Label(stat_bar, text=f"Total: {summary['total']} MB   |   Allocated: {summary['allocated']} MB   |   Free: {summary['free']} MB   |   Utilization: {summary['utilization']}%",
                 font=("Segoe UI", 9, "bold"), fg=COLOR_PRIMARY_BLUE, bg=COLOR_CARD_WHITE).pack(anchor="w")

        # Canvas Memory Map
        self.mem_canvas = tk.Canvas(vis_card, height=70, bg=COLOR_CARD_WHITE, highlightthickness=0)
        self.mem_canvas.pack(fill="x", pady=(0, 10))

        # Memory Blocks Table Card
        tbl_card = ContentCard(container, title="Memory Blocks")
        tbl_card.pack(fill="both", expand=True)

        # Table header
        th = tk.Frame(tbl_card, bg="#F1F5F9", pady=6)
        th.pack(fill="x", pady=(0, 4))
        tk.Label(th, text="Start (MB)", font=("Segoe UI", 9, "bold"), width=12, anchor="w", bg="#F1F5F9").pack(side="left", padx=8)
        tk.Label(th, text="Size (MB)", font=("Segoe UI", 9, "bold"), width=12, anchor="w", bg="#F1F5F9").pack(side="left", padx=8)
        tk.Label(th, text="Status", font=("Segoe UI", 9, "bold"), width=14, anchor="w", bg="#F1F5F9").pack(side="left", padx=8)
        tk.Label(th, text="Process", font=("Segoe UI", 9, "bold"), width=14, anchor="w", bg="#F1F5F9").pack(side="left", padx=8)

        self.table_content = tk.Frame(tbl_card, bg=COLOR_CARD_WHITE)
        self.table_content.pack(fill="both", expand=True)

        self._render_memory()

    def _render_memory(self):
        blocks = self.mem_mgr.get_memory_state()
        self.mem_canvas.delete("all")
        for w in self.table_content.winfo_children():
            w.destroy()

        canvas_width = 720
        bar_height = 42
        start_y = 6

        color_palette = {
            "P1": "#7DD3FC",  # Blueprint soft sky blue
            "P2": "#86EFAC",  # Blueprint soft green
            "P3": "#FCA5A5",  # Blueprint soft red / salmon
            "P4": "#FDE047",
            "P5": "#C4B5FD",
            "-": "#E2E8F0"    # Blueprint free block gray
        }

        for b in blocks:
            s = b["start"]
            size = b["size"]
            status = b["status"]
            proc = b["process"]

            x1 = (s / TOTAL_MEMORY_SIZE) * canvas_width
            x2 = ((s + size) / TOTAL_MEMORY_SIZE) * canvas_width

            col = color_palette.get(proc, "#CBD5E1" if status == "Free" else "#93C5FD")
            self.mem_canvas.create_rectangle(x1, start_y, x2, start_y + bar_height,
                                             fill=col, outline="#64748B", width=1)

            # Labels inside block
            text = f"{proc}\n{size} MB" if status == "Allocated" else f"Free\n{size} MB"
            mid_x = (x1 + x2) / 2
            if (x2 - x1) > 35:
                self.mem_canvas.create_text(mid_x, start_y + bar_height / 2,
                                            text=text, font=("Segoe UI", 8, "bold"), fill="#0F172A", justify="center")

            # Table row
            r_row = tk.Frame(self.table_content, bg=COLOR_CARD_WHITE, pady=4, highlightbackground=COLOR_BORDER, highlightthickness=1)
            r_row.pack(fill="x", pady=1)

            tk.Label(r_row, text=str(s), font=("Segoe UI", 9), width=12, anchor="w", bg=COLOR_CARD_WHITE).pack(side="left", padx=8)
            tk.Label(r_row, text=str(size), font=("Segoe UI", 9), width=12, anchor="w", bg=COLOR_CARD_WHITE).pack(side="left", padx=8)
            
            BadgeLabel(r_row, text=status, status_type=status).pack(side="left", padx=8)
            tk.Label(r_row, text=proc, font=("Segoe UI", 9, "bold"), fg=COLOR_PRIMARY_BLUE if proc != "-" else COLOR_TEXT_MUTED,
                     width=14, anchor="w", bg=COLOR_CARD_WHITE).pack(side="left", padx=8)

    def _do_allocate(self):
        proc = self.proc_var.get().strip()
        try:
            size = int(self.mem_var.get().strip())
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter a valid numeric memory size.")
            return

        if not proc:
            messagebox.showerror("Invalid Input", "Please provide a process identifier.")
            return

        success, msg = self.mem_mgr.allocate_memory(proc, size, algorithm=self.algo_var.get(), user=self.user.get("name"))
        if success:
            messagebox.showinfo("Allocation Successful", msg)
            self._render_memory()
        else:
            messagebox.showwarning("Allocation Failed", msg)

    def _do_release(self):
        proc = self.proc_var.get().strip()
        if not proc:
            messagebox.showerror("Invalid Input", "Please enter the process identifier to release.")
            return

        success, msg = self.mem_mgr.release_memory(proc, user=self.user.get("name"))
        if success:
            messagebox.showinfo("Released", msg)
            self._render_memory()
        else:
            messagebox.showwarning("Release Failed", msg)

    def _do_reset(self):
        if messagebox.askyesno("Reset Memory", "Reset entire memory pool to 1000 MB free state?"):
            self.mem_mgr.reset_memory(user=self.user.get("name"))
            self._render_memory()
