"""
Reusable Tkinter UI components and styled widgets for Smart LMS.
Encapsulates cards, stat boxes, styled buttons, badges, and tables.
"""
import tkinter as tk
from tkinter import ttk
from typing import Optional, Callable, Dict, Any, List

try:
    from config import (
        COLOR_PRIMARY_DARK, COLOR_PRIMARY_BLUE, COLOR_BG_LIGHT,
        COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_BORDER, COLOR_SUCCESS, COLOR_WARNING, COLOR_DANGER
    )
except ImportError:
    from SmartLMS.config import (
        COLOR_PRIMARY_DARK, COLOR_PRIMARY_BLUE, COLOR_BG_LIGHT,
        COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_BORDER, COLOR_SUCCESS, COLOR_WARNING, COLOR_DANGER
    )

class StatCard(tk.Frame):
    """Clean stat card widget with value, title, and optional badge icon."""
    def __init__(self, parent, title: str, value: str, icon_symbol: str = "📊", value_color: str = COLOR_TEXT_MAIN, **kwargs):
        super().__init__(parent, bg=COLOR_CARD_WHITE, relief="flat", highlightbackground=COLOR_BORDER, highlightthickness=1, padx=16, pady=14, **kwargs)
        
        top_row = tk.Frame(self, bg=COLOR_CARD_WHITE)
        top_row.pack(fill="x", expand=True)

        icon_lbl = tk.Label(top_row, text=icon_symbol, font=("Segoe UI", 16), bg=COLOR_CARD_WHITE)
        icon_lbl.pack(side="left", padx=(0, 10))

        val_frame = tk.Frame(top_row, bg=COLOR_CARD_WHITE)
        val_frame.pack(side="left", fill="both")

        self.val_lbl = tk.Label(val_frame, text=value, font=("Segoe UI", 20, "bold"), fg=value_color, bg=COLOR_CARD_WHITE, anchor="w")
        self.val_lbl.pack(anchor="w")

        title_lbl = tk.Label(val_frame, text=title, font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE, anchor="w")
        title_lbl.pack(anchor="w")

    def set_value(self, new_val: str):
        self.val_lbl.config(text=new_val)


class ContentCard(tk.Frame):
    """White card container with border and internal padding."""
    def __init__(self, parent, title: Optional[str] = None, subtitle: Optional[str] = None, **kwargs):
        super().__init__(parent, bg=COLOR_CARD_WHITE, relief="flat", highlightbackground=COLOR_BORDER, highlightthickness=1, padx=20, pady=18, **kwargs)
        if title:
            header_frame = tk.Frame(self, bg=COLOR_CARD_WHITE)
            header_frame.pack(fill="x", pady=(0, 12))
            
            t_lbl = tk.Label(header_frame, text=title, font=("Segoe UI", 12, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE, anchor="w")
            t_lbl.pack(anchor="w")
            
            if subtitle:
                st_lbl = tk.Label(header_frame, text=subtitle, font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE, anchor="w")
                st_lbl.pack(anchor="w")


class PrimaryButton(tk.Button):
    """Consistent primary action button."""
    def __init__(self, parent, text: str, command: Optional[Callable] = None, bg_color: str = COLOR_PRIMARY_BLUE, **kwargs):
        super().__init__(
            parent,
            text=text,
            command=command,
            bg=bg_color,
            fg="white",
            activebackground="#1D4ED8",
            activeforeground="white",
            relief="flat",
            font=("Segoe UI", 10, "bold"),
            padx=14,
            pady=6,
            cursor="hand2",
            **kwargs
        )


class SecondaryButton(tk.Button):
    """Subtle secondary button with light background and border."""
    def __init__(self, parent, text: str, command: Optional[Callable] = None, **kwargs):
        super().__init__(
            parent,
            text=text,
            command=command,
            bg="#F1F5F9",
            fg=COLOR_TEXT_MAIN,
            activebackground="#E2E8F0",
            relief="flat",
            font=("Segoe UI", 9, "bold"),
            padx=10,
            pady=4,
            cursor="hand2",
            highlightbackground=COLOR_BORDER,
            highlightthickness=1,
            **kwargs
        )


class BadgeLabel(tk.Label):
    """Pill-shaped status badge label."""
    def __init__(self, parent, text: str, status_type: str = "Ready", **kwargs):
        status_colors = {
            "Ready": (COLOR_SUCCESS, "#DCFCE7"),
            "Running": (COLOR_PRIMARY_BLUE, "#DBEAFE"),
            "Waiting": (COLOR_WARNING, "#FEF3C7"),
            "Terminated": ("#64748B", "#F1F5F9"),
            "Submitted": (COLOR_SUCCESS, "#DCFCE7"),
            "Graded": ("#2563EB", "#DBEAFE"),
            "Pending": (COLOR_WARNING, "#FEF3C7"),
            "Late": (COLOR_DANGER, "#FEE2E2"),
            "Allocated": (COLOR_SUCCESS, "#DCFCE7"),
            "Free": ("#0284C7", "#E0F2FE")
        }
        fg, bg = status_colors.get(status_type, ("#475569", "#F1F5F9"))
        super().__init__(
            parent,
            text=f"  {text}  ",
            bg=bg,
            fg=fg,
            font=("Segoe UI", 9, "bold"),
            relief="flat",
            padx=4,
            pady=2,
            **kwargs
        )
