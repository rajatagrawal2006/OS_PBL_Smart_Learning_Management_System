"""
OS Simulator - CPU Scheduling View.
Follows Panel 4.2 of UI Blueprint:
- Algorithm selector: FCFS, SJF, Priority, Round Robin
- Dynamic Process input list
- Run Simulation button
- Dynamic Canvas Gantt Chart with time ticks (0, 5, 8, 12...)
- Metrics output: Execution Order, Average Waiting Time, Average Turnaround Time
- Results table (PID, Arrival, Burst, Completion, Turnaround, Waiting)
"""
import tkinter as tk
from tkinter import ttk, messagebox
from typing import Dict, Any, Callable, List

try:
    from config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_SUCCESS
    )
    from os_simulator.process_manager import ProcessManager
    from os_simulator.cpu_scheduler import CPUScheduler
    from gui.components import ContentCard, PrimaryButton, SecondaryButton
except ImportError:
    from SmartLMS.config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_SUCCESS
    )
    from SmartLMS.os_simulator.process_manager import ProcessManager
    from SmartLMS.os_simulator.cpu_scheduler import CPUScheduler
    from SmartLMS.gui.components import ContentCard, PrimaryButton, SecondaryButton

class SchedulerPage(tk.Frame):
    def __init__(self, parent, current_user: Dict[str, Any], on_navigate: Callable[[str], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.user = current_user
        self.on_navigate = on_navigate
        self.pm = ProcessManager()

        # Seeded process list matching blueprint P1(0,5), P2(1,3), P3(2,4)
        self.processes: List[Dict[str, Any]] = [
            {"pid": "P1", "arrival_time": 0, "burst_time": 5, "priority": 2},
            {"pid": "P2", "arrival_time": 1, "burst_time": 3, "priority": 1},
            {"pid": "P3", "arrival_time": 2, "burst_time": 4, "priority": 3},
        ]
        self.last_result: Optional[Dict[str, Any]] = None
        self._build_ui()
        self.run_simulation()

    def _build_ui(self):
        for widget in self.winfo_children():
            widget.destroy()

        container = tk.Frame(self, bg=COLOR_BG_LIGHT, padx=24, pady=20)
        container.pack(fill="both", expand=True)

        # Header
        header_frame = tk.Frame(container, bg=COLOR_BG_LIGHT)
        header_frame.pack(fill="x", pady=(0, 16))

        title_frame = tk.Frame(header_frame, bg=COLOR_BG_LIGHT)
        title_frame.pack(side="left")
        tk.Label(title_frame, text="CPU Scheduling", font=("Segoe UI", 16, "bold"),
                 fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(anchor="w")
        tk.Label(title_frame, text="Simulate CPU scheduling algorithms with dynamic Gantt charts and mathematical metrics",
                 font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_BG_LIGHT).pack(anchor="w")

        # Top Control Bar
        control_card = ContentCard(container)
        control_card.pack(fill="x", pady=(0, 16))

        c_row = tk.Frame(control_card, bg=COLOR_CARD_WHITE)
        c_row.pack(fill="x")

        tk.Label(c_row, text="Select Algorithm:", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(side="left", padx=(0, 8))
        self.algo_var = tk.StringVar(value="FCFS (First Come First Served)")
        algo_combo = ttk.Combobox(c_row, textvariable=self.algo_var,
                                  values=[
                                      "FCFS (First Come First Served)",
                                      "SJF Non-Preemptive (Shortest Job First)",
                                      "SJF Preemptive (SRTF)",
                                      "Priority Scheduling",
                                      "Round Robin"
                                  ],
                                  state="readonly", width=34)
        algo_combo.pack(side="left", padx=(0, 20))
        algo_combo.bind("<<ComboboxSelected>>", lambda e: self._on_algo_change())

        self.quantum_frame = tk.Frame(c_row, bg=COLOR_CARD_WHITE)
        tk.Label(self.quantum_frame, text="Time Quantum:", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(side="left", padx=(0, 6))
        self.quantum_var = tk.StringVar(value="2")
        tk.Entry(self.quantum_frame, textvariable=self.quantum_var, width=6, font=("Segoe UI", 9), relief="solid", bd=1).pack(side="left")

        PrimaryButton(c_row, text="Run Simulation", command=self.run_simulation).pack(side="right")
        SecondaryButton(c_row, text="+ Add Process", command=self._add_process_dialog).pack(side="right", padx=8)

        # Main Split Content
        split_frame = tk.Frame(container, bg=COLOR_BG_LIGHT)
        split_frame.pack(fill="both", expand=True)

        # Left Column: Input Process Table
        left_card = ContentCard(split_frame, title="Input Processes")
        left_card.pack(side="left", fill="both", expand=True, padx=(0, 10))

        # Process Table Header
        th = tk.Frame(left_card, bg="#F1F5F9", pady=6)
        th.pack(fill="x", pady=(0, 4))
        tk.Label(th, text="Process", font=("Segoe UI", 9, "bold"), width=8, anchor="w", bg="#F1F5F9").pack(side="left", padx=6)
        tk.Label(th, text="Arrival Time", font=("Segoe UI", 9, "bold"), width=12, anchor="w", bg="#F1F5F9").pack(side="left", padx=6)
        tk.Label(th, text="Burst Time", font=("Segoe UI", 9, "bold"), width=12, anchor="w", bg="#F1F5F9").pack(side="left", padx=6)
        tk.Label(th, text="Priority", font=("Segoe UI", 9, "bold"), width=10, anchor="w", bg="#F1F5F9").pack(side="left", padx=6)

        for p in self.processes:
            p_row = tk.Frame(left_card, bg=COLOR_CARD_WHITE, pady=6, highlightbackground=COLOR_BORDER, highlightthickness=1)
            p_row.pack(fill="x", pady=2)
            tk.Label(p_row, text=p["pid"], font=("Segoe UI", 9, "bold"), fg=COLOR_PRIMARY_BLUE, bg=COLOR_CARD_WHITE, width=8, anchor="w").pack(side="left", padx=6)
            tk.Label(p_row, text=str(p["arrival_time"]), font=("Segoe UI", 9), bg=COLOR_CARD_WHITE, width=12, anchor="w").pack(side="left", padx=6)
            tk.Label(p_row, text=str(p["burst_time"]), font=("Segoe UI", 9), bg=COLOR_CARD_WHITE, width=12, anchor="w").pack(side="left", padx=6)
            tk.Label(p_row, text=str(p["priority"]), font=("Segoe UI", 9), bg=COLOR_CARD_WHITE, width=10, anchor="w").pack(side="left", padx=6)

        # Right Column: Results & Dynamic Gantt Chart
        self.right_card = ContentCard(split_frame, title="Results")
        self.right_card.pack(side="right", fill="both", expand=True, padx=(10, 0))

        tk.Label(self.right_card, text="Gantt Chart", font=("Segoe UI", 10, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(anchor="w", pady=(0, 6))

        # Dynamic Canvas Gantt Chart
        self.gantt_canvas = tk.Canvas(self.right_card, height=75, bg=COLOR_CARD_WHITE, highlightthickness=0)
        self.gantt_canvas.pack(fill="x", pady=(0, 14))

        # Metrics Labels
        self.exec_order_lbl = tk.Label(self.right_card, text="Execution Order: ", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE)
        self.exec_order_lbl.pack(anchor="w", pady=2)

        self.wt_lbl = tk.Label(self.right_card, text="Average Waiting Time: ", font=("Segoe UI", 9), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE)
        self.wt_lbl.pack(anchor="w", pady=2)

        self.tat_lbl = tk.Label(self.right_card, text="Average Turnaround Time: ", font=("Segoe UI", 9), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE)
        self.tat_lbl.pack(anchor="w", pady=2)

        # Results table placeholder
        self.results_frame = tk.Frame(self.right_card, bg=COLOR_CARD_WHITE)
        self.results_frame.pack(fill="both", expand=True, pady=(10, 0))

    def _on_algo_change(self):
        if "Round Robin" in self.algo_var.get():
            self.quantum_frame.pack(side="left", padx=10)
        else:
            self.quantum_frame.pack_forget()

    def _add_process_dialog(self):
        top = tk.Toplevel(self)
        top.title("Add Process")
        top.geometry("320x260")
        top.configure(bg=COLOR_CARD_WHITE)

        tk.Label(top, text="Add Scheduling Process", font=("Segoe UI", 10, "bold"), bg=COLOR_CARD_WHITE).pack(pady=10)
        
        f = tk.Frame(top, bg=COLOR_CARD_WHITE, padx=16)
        f.pack(fill="both")

        tk.Label(f, text="Arrival Time:", bg=COLOR_CARD_WHITE).grid(row=0, column=0, sticky="w", pady=4)
        at_e = tk.Entry(f, width=10)
        at_e.insert(0, "0")
        at_e.grid(row=0, column=1, pady=4)

        tk.Label(f, text="Burst Time:", bg=COLOR_CARD_WHITE).grid(row=1, column=0, sticky="w", pady=4)
        bt_e = tk.Entry(f, width=10)
        bt_e.insert(0, "4")
        bt_e.grid(row=1, column=1, pady=4)

        tk.Label(f, text="Priority:", bg=COLOR_CARD_WHITE).grid(row=2, column=0, sticky="w", pady=4)
        pr_e = tk.Entry(f, width=10)
        pr_e.insert(0, "1")
        pr_e.grid(row=2, column=1, pady=4)

        def save():
            try:
                at = int(at_e.get())
                bt = int(bt_e.get())
                pr = int(pr_e.get())
            except ValueError:
                messagebox.showerror("Error", "Please enter valid integers.")
                return
            new_pid = f"P{len(self.processes) + 1}"
            self.processes.append({"pid": new_pid, "arrival_time": at, "burst_time": bt, "priority": pr})
            top.destroy()
            self._build_ui()
            self.run_simulation()

        PrimaryButton(top, text="Add", command=save).pack(pady=12)

    def run_simulation(self):
        algo_name = self.algo_var.get()
        if "Preemptive" in algo_name or "SRTF" in algo_name:
            res = CPUScheduler.run_sjf_preemptive(self.processes)
        elif "FCFS" in algo_name:
            res = CPUScheduler.run_fcfs(self.processes)
        elif "SJF" in algo_name:
            res = CPUScheduler.run_sjf(self.processes)
        elif "Priority" in algo_name:
            res = CPUScheduler.run_priority(self.processes)
        elif "Round Robin" in algo_name:
            try:
                q = int(self.quantum_var.get())
            except ValueError:
                q = 2
            res = CPUScheduler.run_round_robin(self.processes, quantum=q)
        else:
            res = CPUScheduler.run_fcfs(self.processes)

        self.last_result = res
        self._render_results(res)

    def _render_results(self, res: Dict[str, Any]):
        timeline = res.get("timeline", [])
        if not timeline:
            return

        self.exec_order_lbl.config(text=f"Execution Order:  {res.get('execution_order')}")
        self.wt_lbl.config(text=f"Average Waiting Time:  {res.get('avg_wt')} ms")
        self.tat_lbl.config(text=f"Average Turnaround Time:  {res.get('avg_tat')} ms")

        # Draw Dynamic Canvas Gantt Chart
        self.gantt_canvas.delete("all")
        total_time = max(timeline[-1]["end"], 1)
        canvas_width = 380
        bar_height = 36
        start_y = 10

        # Colors for processes
        colors = {
            "P1": "#38BDF8",  # Sky blue (Blueprint style)
            "P2": "#4ADE80",  # Light green (Blueprint style)
            "P3": "#F87171",  # Soft coral / red (Blueprint style)
            "P4": "#FBBF24",
            "P5": "#A78BFA",
            "IDLE": "#E2E8F0"
        }

        # Clear background
        for block in timeline:
            s = block["start"]
            e = block["end"]
            pid = block["pid"]

            x1 = (s / total_time) * canvas_width
            x2 = (e / total_time) * canvas_width
            color = colors.get(pid, "#93C5FD")

            self.gantt_canvas.create_rectangle(x1, start_y, x2, start_y + bar_height,
                                               fill=color, outline="#1E293B", width=1)
            # Text label
            mid_x = (x1 + x2) / 2
            self.gantt_canvas.create_text(mid_x, start_y + bar_height / 2,
                                          text=pid, font=("Segoe UI", 9, "bold"), fill="#0F172A")
            # Tick label at start
            self.gantt_canvas.create_text(x1, start_y + bar_height + 12,
                                          text=str(s), font=("Segoe UI", 8), fill="#475569")

        # Final tick label
        self.gantt_canvas.create_text(canvas_width, start_y + bar_height + 12,
                                      text=str(total_time), font=("Segoe UI", 8), fill="#475569")

        # Results table
        for w in self.results_frame.winfo_children():
            w.destroy()

        r_th = tk.Frame(self.results_frame, bg="#F1F5F9", pady=4)
        r_th.pack(fill="x")
        for col_name, w in [("PID", 6), ("Arrival", 8), ("Burst", 8), ("CT", 6), ("TAT", 6), ("WT", 6)]:
            tk.Label(r_th, text=col_name, font=("Segoe UI", 8, "bold"), width=w, bg="#F1F5F9").pack(side="left", padx=2)

        for r in res.get("results", []):
            row = tk.Frame(self.results_frame, bg=COLOR_CARD_WHITE, pady=2)
            row.pack(fill="x")
            tk.Label(row, text=r["pid"], font=("Segoe UI", 8, "bold"), fg=COLOR_PRIMARY_BLUE, width=6, bg=COLOR_CARD_WHITE).pack(side="left", padx=2)
            tk.Label(row, text=str(r["arrival_time"]), font=("Segoe UI", 8), width=8, bg=COLOR_CARD_WHITE).pack(side="left", padx=2)
            tk.Label(row, text=str(r["burst_time"]), font=("Segoe UI", 8), width=8, bg=COLOR_CARD_WHITE).pack(side="left", padx=2)
            tk.Label(row, text=str(r["completion_time"]), font=("Segoe UI", 8), width=6, bg=COLOR_CARD_WHITE).pack(side="left", padx=2)
            tk.Label(row, text=str(r["turnaround_time"]), font=("Segoe UI", 8), width=6, bg=COLOR_CARD_WHITE).pack(side="left", padx=2)
            tk.Label(row, text=str(r["waiting_time"]), font=("Segoe UI", 8), width=6, bg=COLOR_CARD_WHITE).pack(side="left", padx=2)
