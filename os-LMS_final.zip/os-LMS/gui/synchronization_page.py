"""
OS Simulator - Synchronization Lab View (Producer-Consumer).
Follows Panel 4.5 of UI Blueprint:
- Simulate synchronization using semaphore and bounded buffer (Size 5)
- Controls: Start Simulation (green), Pause (yellow), Reset (red), Step Produce, Step Consume
- Buffer visualization [ A ] [ B ] [ C ] [   ] [   ]
- Producer Log (green text) and Consumer Log (blue text)
"""
import tkinter as tk
from tkinter import ttk, messagebox
from typing import Dict, Any, Callable

try:
    from config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_SUCCESS, COLOR_WARNING, COLOR_DANGER
    )
    from os_simulator.synchronization import ProducerConsumerLab
    from gui.components import ContentCard, PrimaryButton, SecondaryButton
except ImportError:
    from SmartLMS.config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_SUCCESS, COLOR_WARNING, COLOR_DANGER
    )
    from SmartLMS.os_simulator.synchronization import ProducerConsumerLab
    from SmartLMS.gui.components import ContentCard, PrimaryButton, SecondaryButton

class SynchronizationPage(tk.Frame):
    def __init__(self, parent, current_user: Dict[str, Any], on_navigate: Callable[[str], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.user = current_user
        self.on_navigate = on_navigate
        self.lab = ProducerConsumerLab(capacity=5)
        self.lab.on_update = self._schedule_update
        self._build_ui()

    def _schedule_update(self):
        try:
            self.after(0, self._render_state)
        except Exception:
            pass

    def _build_ui(self):
        for widget in self.winfo_children():
            widget.destroy()

        container = tk.Frame(self, bg=COLOR_BG_LIGHT, padx=24, pady=20)
        container.pack(fill="both", expand=True)

        # Header
        header_frame = tk.Frame(container, bg=COLOR_BG_LIGHT)
        header_frame.pack(fill="x", pady=(0, 16))

        title_frame = tk.Frame(header_frame, bg=COLOR_BG_LIGHT)
        title_frame.pack(side="left")
        tk.Label(title_frame, text="Producer – Consumer Problem", font=("Segoe UI", 16, "bold"),
                 fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(anchor="w")
        tk.Label(title_frame, text="Simulate synchronization and critical section control using semaphores & mutex",
                 font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_BG_LIGHT).pack(anchor="w")

        # Action Buttons matching Blueprint colors: Green, Yellow, Red
        btn_frame = tk.Frame(header_frame, bg=COLOR_BG_LIGHT)
        btn_frame.pack(side="right")

        PrimaryButton(btn_frame, text="Start Simulation", command=self._start, bg_color=COLOR_SUCCESS).pack(side="left", padx=4)
        PrimaryButton(btn_frame, text="Pause", command=self._pause, bg_color=COLOR_WARNING).pack(side="left", padx=4)
        PrimaryButton(btn_frame, text="Reset", command=self._reset, bg_color=COLOR_DANGER).pack(side="left", padx=4)

        # Step manual controls
        step_frame = tk.Frame(container, bg=COLOR_BG_LIGHT)
        step_frame.pack(fill="x", pady=(0, 12))
        SecondaryButton(step_frame, text="👉 Step Produce Item", command=self._step_produce).pack(side="left", padx=(0, 8))
        SecondaryButton(step_frame, text="👈 Step Consume Item", command=self._step_consume).pack(side="left")

        # Buffer Card
        self.buf_card = ContentCard(container, title="Buffer (Size: 5)")
        self.buf_card.pack(fill="x", pady=(0, 16))

        self.slots_container = tk.Frame(self.buf_card, bg=COLOR_CARD_WHITE)
        self.slots_container.pack(fill="x", pady=10)

        # Bottom Split: Producer Log vs Consumer Log
        logs_frame = tk.Frame(container, bg=COLOR_BG_LIGHT)
        logs_frame.pack(fill="both", expand=True)

        # Left: Producer Log
        p_card = ContentCard(logs_frame, title="Producer Log")
        p_card.pack(side="left", fill="both", expand=True, padx=(0, 10))

        self.p_log_box = tk.Text(p_card, height=10, font=("Consolas", 10), bg="#F0FDF4", fg="#15803D",
                                 relief="flat", highlightbackground=COLOR_BORDER, highlightthickness=1)
        self.p_log_box.pack(fill="both", expand=True)

        # Right: Consumer Log
        c_card = ContentCard(logs_frame, title="Consumer Log")
        c_card.pack(side="right", fill="both", expand=True, padx=(10, 0))

        self.c_log_box = tk.Text(c_card, height=10, font=("Consolas", 10), bg="#EFF6FF", fg="#1D4ED8",
                                 relief="flat", highlightbackground=COLOR_BORDER, highlightthickness=1)
        self.c_log_box.pack(fill="both", expand=True)

        self._render_state()

    def _render_state(self):
        state = self.lab.get_state()
        buf = state["buffer"]
        cap = state["capacity"]

        # Clear and redraw slots
        for w in self.slots_container.winfo_children():
            w.destroy()

        for i in range(cap):
            is_filled = i < len(buf)
            item_val = buf[i] if is_filled else ""

            slot_frame = tk.Frame(self.slots_container, bg="#93C5FD" if is_filled else "#F1F5F9",
                                  width=70, height=55, highlightbackground="#3B82F6" if is_filled else "#CBD5E1",
                                  highlightthickness=2)
            slot_frame.pack_propagate(False)
            slot_frame.pack(side="left", padx=8)

            tk.Label(slot_frame, text=item_val, font=("Segoe UI", 16, "bold"),
                     fg="#1E3A8A" if is_filled else "#94A3B8",
                     bg="#93C5FD" if is_filled else "#F1F5F9").pack(expand=True)

        # Update logs
        self.p_log_box.delete("1.0", "end")
        for line in state["producer_log"]:
            self.p_log_box.insert("end", f"{line}\n")
        self.p_log_box.see("end")

        self.c_log_box.delete("1.0", "end")
        for line in state["consumer_log"]:
            self.c_log_box.insert("end", f"{line}\n")
        self.c_log_box.see("end")

    def _start(self):
        self.lab.start(interval=1.0)

    def _pause(self):
        self.lab.pause()

    def _reset(self):
        self.lab.reset()
        self._render_state()

    def _step_produce(self):
        ok = self.lab.produce_item()
        if not ok:
            messagebox.showwarning("Buffer Full", "Buffer is full (Size 5)! Producer cannot insert into bounded buffer.")
        self._render_state()

    def _step_consume(self):
        ok = self.lab.consume_item()
        if not ok:
            messagebox.showwarning("Buffer Empty", "Buffer is empty! Consumer cannot remove from bounded buffer.")
        self._render_state()
