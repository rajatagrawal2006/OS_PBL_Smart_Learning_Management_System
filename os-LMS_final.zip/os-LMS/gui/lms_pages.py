"""
Dedicated LMS Pages for Smart LMS Tkinter Application:
- Grades & Academic Performance (GradesPage - Pixel-perfect grid alignment for Student & Teacher)
- My Courses (MyCoursesPage - Custom views for Student and Teacher)
- Assignments List & Submission (AssignmentsPage - For Students)
- Create Assignment (CreateAssignmentPage - For Teachers)
- View & Grade Submissions (ViewSubmissionsPage - For Teachers)
- Course Materials Library (MaterialsPage - For Students)
- Upload Course Materials (UploadMaterialsPage - For Teachers)
- User Profile & Credentials (ProfilePage)
- Admin Course Manager (ManageCoursesPage)
- Admin User Manager (ManageUsersPage)
- Admin System Activity (SystemActivityPage)
"""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from typing import Dict, Any, Callable, List
from datetime import datetime
from pathlib import Path
import shutil
import os

try:
    from config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_SUCCESS,
        COLOR_WARNING, COLOR_DANGER, SUBMISSIONS_DIR, MATERIALS_DIR
    )
    from storage.json_store import JSONStore, ActivityLogger
    from lms.courses import CourseManager
    from lms.assignments import AssignmentManager
    from lms.submissions import SubmissionManager
    from lms.materials import MaterialManager
    from gui.components import StatCard, ContentCard, PrimaryButton, SecondaryButton, BadgeLabel
except ImportError:
    from SmartLMS.config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_SUCCESS,
        COLOR_WARNING, COLOR_DANGER, SUBMISSIONS_DIR, MATERIALS_DIR
    )
    from SmartLMS.storage.json_store import JSONStore, ActivityLogger
    from SmartLMS.lms.courses import CourseManager
    from SmartLMS.lms.assignments import AssignmentManager
    from SmartLMS.lms.submissions import SubmissionManager
    from SmartLMS.lms.materials import MaterialManager
    from SmartLMS.gui.components import StatCard, ContentCard, PrimaryButton, SecondaryButton, BadgeLabel


def _create_scrollable_container(parent):
    canvas = tk.Canvas(parent, bg=COLOR_BG_LIGHT, highlightthickness=0)
    scrollbar = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
    scroll_frame = tk.Frame(canvas, bg=COLOR_BG_LIGHT)

    scroll_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
    )
    canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
    # BUG-FIX: was xscrollcommand — must be yscrollcommand for vertical scrolling
    canvas.configure(yscrollcommand=scrollbar.set)

    # Mouse-wheel support
    def _on_mousewheel(event):
        canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
    canvas.bind_all("<MouseWheel>", _on_mousewheel)

    canvas.pack(side="left", fill="both", expand=True, padx=24, pady=20)
    scrollbar.pack(side="right", fill="y")
    return scroll_frame


# ==============================================================================
# 1. GRADES & ACADEMIC PERFORMANCE PAGE (Pixel-Perfect Mathematical Grid Alignment)
# ==============================================================================
class GradesPage(tk.Frame):
    def __init__(self, parent, current_user: Dict[str, Any], on_navigate: Callable[[str], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.user = current_user
        self.on_navigate = on_navigate
        self._build_ui()

    def _build_ui(self):
        for w in self.winfo_children():
            w.destroy()

        container = _create_scrollable_container(self)
        role = self.user.get("role", "student")

        # Header
        hdr = tk.Frame(container, bg=COLOR_BG_LIGHT)
        hdr.pack(fill="x", pady=(0, 16))

        if role == "student":
            tk.Label(hdr, text="Academic Grades & Performance", font=("Segoe UI", 16, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(anchor="w")
            tk.Label(hdr, text=f"Official submission grades, faculty feedback, and academic report for {self.user.get('name')}", font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_BG_LIGHT).pack(anchor="w")
        else:
            tk.Label(hdr, text="Student Grading & Performance Overview", font=("Segoe UI", 16, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(anchor="w")
            tk.Label(hdr, text="Review student grades and performance metrics", font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_BG_LIGHT).pack(anchor="w")

        # Load submissions
        sub_store = JSONStore("submissions.json")
        all_subs = sub_store.load_all()

        if role == "student":
            user_subs = [s for s in all_subs if s.get("student_id") == self.user.get("id")]
        else:
            # For teacher, filter submissions for courses they teach
            teacher_courses = [c.get("name") for c in CourseManager().get_courses_by_teacher(self.user.get("id"))]
            if teacher_courses:
                user_subs = [s for s in all_subs if s.get("course_name") in teacher_courses]
            else:
                user_subs = all_subs

        graded_subs = [s for s in user_subs if s.get("status") == "Graded" and s.get("marks") is not None]
        avg_score = 0
        if graded_subs:
            avg_score = round(sum(s.get("marks", 0) for s in graded_subs) / len(graded_subs), 1)

        # Stat cards row
        stats_frame = tk.Frame(container, bg=COLOR_BG_LIGHT)
        stats_frame.pack(fill="x", pady=(0, 20))

        StatCard(stats_frame, "Total Submissions", str(len(user_subs)), "📝").pack(side="left", fill="both", expand=True, padx=(0, 8))
        StatCard(stats_frame, "Graded Assignments", str(len(graded_subs)), "✅", value_color=COLOR_SUCCESS).pack(side="left", fill="both", expand=True, padx=4)
        StatCard(stats_frame, "Average Score", f"{avg_score} pts", "🎯", value_color=COLOR_PRIMARY_BLUE).pack(side="left", fill="both", expand=True, padx=4)
        pending_count = len(user_subs) - len(graded_subs)
        StatCard(stats_frame, "Pending Review", str(pending_count), "⏳", value_color=COLOR_WARNING).pack(side="left", fill="both", expand=True, padx=(8, 0))

        # Grades Detail Card
        card = ContentCard(container, title="Graded Assignments & Feedback Table")
        card.pack(fill="x", expand=True)


        if not user_subs:
            tk.Label(card, text="No submissions recorded yet.", font=("Segoe UI", 10, "italic"), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE, pady=24).pack()
            return

        # Unified Mathematical Grid Container: every column is mathematically locked!
        grid_table = tk.Frame(card, bg=COLOR_CARD_WHITE)
        grid_table.pack(fill="x", expand=True, pady=(6, 0))

        # Column weights and min widths
        # Col 0: Course & Assignment (240px)
        # Col 1: Submitted File & Date (190px)
        # Col 2: Status (110px)
        # Col 3: Score / Max (110px)
        # Col 4: Faculty Feedback (fill remainder)
        grid_table.columnconfigure(0, weight=3, minsize=210)
        grid_table.columnconfigure(1, weight=2, minsize=170)
        grid_table.columnconfigure(2, weight=1, minsize=100)
        grid_table.columnconfigure(3, weight=1, minsize=100)
        grid_table.columnconfigure(4, weight=4, minsize=240)

        # Header Row
        hdr_bg = "#F8FAFC"
        h_frame = tk.Frame(grid_table, bg=hdr_bg, padx=10, pady=8, highlightbackground=COLOR_BORDER, highlightthickness=1)
        h_frame.grid(row=0, column=0, columnspan=5, sticky="ew", pady=(0, 4))
        h_frame.columnconfigure(0, weight=3, minsize=210)
        h_frame.columnconfigure(1, weight=2, minsize=170)
        h_frame.columnconfigure(2, weight=1, minsize=100)
        h_frame.columnconfigure(3, weight=1, minsize=100)
        h_frame.columnconfigure(4, weight=4, minsize=240)

        tk.Label(h_frame, text="Course & Assignment", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MUTED, bg=hdr_bg, anchor="w").grid(row=0, column=0, sticky="w", padx=6)
        tk.Label(h_frame, text="Submitted Resource", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MUTED, bg=hdr_bg, anchor="w").grid(row=0, column=1, sticky="w", padx=6)
        tk.Label(h_frame, text="Status", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MUTED, bg=hdr_bg, anchor="center").grid(row=0, column=2, sticky="ew", padx=6)
        tk.Label(h_frame, text="Score / Max", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MUTED, bg=hdr_bg, anchor="center").grid(row=0, column=3, sticky="ew", padx=6)
        tk.Label(h_frame, text="Faculty Feedback / Notes", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MUTED, bg=hdr_bg, anchor="w").grid(row=0, column=4, sticky="w", padx=6)

        # Data Rows
        for i, s in enumerate(user_subs, start=1):
            r_frame = tk.Frame(grid_table, bg=COLOR_CARD_WHITE, padx=10, pady=10, highlightbackground=COLOR_BORDER, highlightthickness=1)
            r_frame.grid(row=i, column=0, columnspan=5, sticky="ew", pady=2)
            r_frame.columnconfigure(0, weight=3, minsize=210)
            r_frame.columnconfigure(1, weight=2, minsize=170)
            r_frame.columnconfigure(2, weight=1, minsize=100)
            r_frame.columnconfigure(3, weight=1, minsize=100)
            r_frame.columnconfigure(4, weight=4, minsize=240)

            # Col 0: Course & Assignment
            c0 = tk.Frame(r_frame, bg=COLOR_CARD_WHITE)
            c0.grid(row=0, column=0, sticky="w", padx=6)
            tk.Label(c0, text=s.get("assignment_title", "Assignment"), font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE, anchor="w").pack(anchor="w")
            c_label = f"{s.get('course_name', 'Course')}"
            if role != "student":
                c_label += f" • {s.get('student_name', 'Student')}"
            tk.Label(c0, text=c_label, font=("Segoe UI", 8), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE, anchor="w").pack(anchor="w")

            # Col 1: Submitted File & Date
            c1 = tk.Frame(r_frame, bg=COLOR_CARD_WHITE)
            c1.grid(row=0, column=1, sticky="w", padx=6)
            tk.Label(c1, text=f"📄 {s.get('file_name', 'document.pdf')}", font=("Segoe UI", 8, "bold"), fg=COLOR_PRIMARY_BLUE, bg=COLOR_CARD_WHITE, anchor="w").pack(anchor="w")
            tk.Label(c1, text=s.get("submission_date", "Date"), font=("Segoe UI", 7), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE, anchor="w").pack(anchor="w")

            # Col 2: Status Badge (Centered)
            c2 = tk.Frame(r_frame, bg=COLOR_CARD_WHITE)
            c2.grid(row=0, column=2, sticky="ew", padx=6)
            st = s.get("status", "Submitted")
            BadgeLabel(c2, text=st, status_type=st).pack(anchor="center")

            # Col 3: Score / Max (Centered)
            c3 = tk.Frame(r_frame, bg=COLOR_CARD_WHITE)
            c3.grid(row=0, column=3, sticky="ew", padx=6)
            marks = s.get("marks")
            if marks is not None:
                tk.Label(c3, text=f"{marks} / 20", font=("Segoe UI", 10, "bold"), fg=COLOR_SUCCESS, bg=COLOR_CARD_WHITE, anchor="center").pack(anchor="center")
            else:
                tk.Label(c3, text="Ungraded", font=("Segoe UI", 8, "italic"), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE, anchor="center").pack(anchor="center")

            # Col 4: Faculty Feedback
            c4 = tk.Frame(r_frame, bg=COLOR_CARD_WHITE)
            c4.grid(row=0, column=4, sticky="w", padx=6)
            fb_text = s.get("feedback")
            if not fb_text:
                fb_text = "Evaluation pending." if marks is None else "No written comments."
            tk.Label(c4, text=fb_text, font=("Segoe UI", 8), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE, wraplength=280, justify="left", anchor="w").pack(anchor="w")


# ==============================================================================
# 2. MY COURSES PAGE (Role-Aware: Student vs Teacher)
# ==============================================================================
class MyCoursesPage(tk.Frame):
    def __init__(self, parent, current_user: Dict[str, Any], on_navigate: Callable[[str], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.user = current_user
        self.on_navigate = on_navigate
        self._build_ui()

    def _build_ui(self):
        for w in self.winfo_children():
            w.destroy()

        container = _create_scrollable_container(self)
        role = self.user.get("role", "student")
        mgr = CourseManager()

        if role == "teacher":
            hdr = tk.Frame(container, bg=COLOR_BG_LIGHT)
            hdr.pack(fill="x", pady=(0, 16))
            tk.Label(hdr, text="Courses Taught by You", font=("Segoe UI", 16, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(side="left")
            PrimaryButton(hdr, text="➕ Create Course", command=self._open_create_course_dialog).pack(side="right")

            teacher_courses = mgr.get_courses_by_teacher(self.user.get("id"))
            if not teacher_courses:
                empty_t = tk.Frame(container, bg=COLOR_CARD_WHITE, padx=20, pady=16, highlightbackground=COLOR_BORDER, highlightthickness=1)
                empty_t.pack(fill="x", pady=(0, 12))
                tk.Label(empty_t, text="No courses assigned yet. Click '+ Create Course' to create your first course.", font=("Segoe UI", 10, "italic"), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(anchor="w")
            else:
                enrollment_store = JSONStore("enrollments.json")
                enrollments = enrollment_store.load_all()

                for c in teacher_courses:
                    live_count = sum(1 for e in enrollments if e.get("course_id") == c.get("id"))
                    card = tk.Frame(container, bg=COLOR_CARD_WHITE, padx=20, pady=16, highlightbackground=COLOR_BORDER, highlightthickness=1)
                    card.pack(fill="x", pady=(0, 12))

                    top_r = tk.Frame(card, bg=COLOR_CARD_WHITE)
                    top_r.pack(fill="x")

                    code_badge = tk.Label(top_r, text=f" {c.get('code')} ", font=("Segoe UI", 8, "bold"), bg="#EFF6FF", fg=COLOR_PRIMARY_BLUE, padx=4, pady=2)
                    code_badge.pack(side="left", padx=(0, 8))

                    tk.Label(top_r, text=c.get("name"), font=("Segoe UI", 12, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(side="left")

                    enrolled_txt = f"👥 {live_count} Students Enrolled"
                    tk.Label(top_r, text=enrolled_txt, font=("Segoe UI", 8, "bold"), fg=COLOR_SUCCESS, bg=COLOR_CARD_WHITE).pack(side="right")

                    tk.Label(card, text=f"Instructor: {c.get('teacher_name')}", font=("Segoe UI", 8, "bold"), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(anchor="w", pady=(6, 2))
                    tk.Label(card, text=c.get("description", ""), font=("Segoe UI", 9), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE, wraplength=720, justify="left").pack(anchor="w", pady=(0, 12))

                    btn_r = tk.Frame(card, bg=COLOR_CARD_WHITE)
                    btn_r.pack(fill="x")
                    SecondaryButton(btn_r, text="⚙  Manage Course", command=lambda course=c, lc=live_count: self._open_manage_course_modal(course, lc)).pack(side="left")


        else:
            # --- SECTION 1: Enrolled Courses ---
            hdr1 = tk.Frame(container, bg=COLOR_BG_LIGHT)
            hdr1.pack(fill="x", pady=(0, 12))
            tk.Label(hdr1, text="Your Enrolled Courses", font=("Segoe UI", 16, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(anchor="w")
            tk.Label(hdr1, text="Curriculum you are currently registered for this semester", font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_BG_LIGHT).pack(anchor="w")

            enrolled_courses = mgr.get_courses_for_student(self.user.get("id"))
            if not enrolled_courses:
                empty_card = tk.Frame(container, bg=COLOR_CARD_WHITE, padx=20, pady=16, highlightbackground=COLOR_BORDER, highlightthickness=1)
                empty_card.pack(fill="x", pady=(0, 16))
                tk.Label(empty_card, text="You are not currently enrolled in any courses. Browse available courses below to enroll.", font=("Segoe UI", 10, "italic"), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(anchor="w")
            else:
                for c in enrolled_courses:
                    card = tk.Frame(container, bg=COLOR_CARD_WHITE, padx=20, pady=16, highlightbackground=COLOR_BORDER, highlightthickness=1)
                    card.pack(fill="x", pady=(0, 12))

                    top_r = tk.Frame(card, bg=COLOR_CARD_WHITE)
                    top_r.pack(fill="x")

                    code_badge = tk.Label(top_r, text=f" {c.get('code')} ", font=("Segoe UI", 8, "bold"), bg="#EFF6FF", fg=COLOR_PRIMARY_BLUE, padx=4, pady=2)
                    code_badge.pack(side="left", padx=(0, 8))

                    tk.Label(top_r, text=c.get("name"), font=("Segoe UI", 12, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(side="left")

                    enrolled_txt = f"👥 {c.get('enrolled_count', 0)} Students Enrolled"
                    tk.Label(top_r, text=enrolled_txt, font=("Segoe UI", 8, "bold"), fg=COLOR_SUCCESS, bg=COLOR_CARD_WHITE).pack(side="right")

                    tk.Label(card, text=f"Instructor: {c.get('teacher_name')}", font=("Segoe UI", 8, "bold"), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(anchor="w", pady=(6, 2))
                    tk.Label(card, text=c.get("description", ""), font=("Segoe UI", 9), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE, wraplength=720, justify="left").pack(anchor="w", pady=(0, 12))

                    btn_r = tk.Frame(card, bg=COLOR_CARD_WHITE)
                    btn_r.pack(fill="x")
                    
                    drop_btn = tk.Button(
                        btn_r, text="🚫 Drop Course", font=("Segoe UI", 9, "bold"),
                        fg="#DC2626", bg="#FEF2F2", activebackground="#FEE2E2", activeforeground="#991B1B",
                        bd=1, relief="solid", highlightthickness=0, cursor="hand2", padx=12, pady=5,
                        command=lambda cid=c.get("id"), cname=c.get("name"): self._drop_course(cid, cname)
                    )
                    drop_btn.pack(side="left")

            # --- SECTION 2: Available Courses ---
            hdr2 = tk.Frame(container, bg=COLOR_BG_LIGHT)
            hdr2.pack(fill="x", pady=(24, 12))
            tk.Label(hdr2, text="Available Courses for Enrollment", font=("Segoe UI", 16, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(anchor="w")
            tk.Label(hdr2, text="Explore new courses offered across departments and enroll instantly", font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_BG_LIGHT).pack(anchor="w")

            available_courses = mgr.get_available_courses_for_student(self.user.get("id"))
            if not available_courses:
                empty_avail = tk.Frame(container, bg=COLOR_CARD_WHITE, padx=20, pady=16, highlightbackground=COLOR_BORDER, highlightthickness=1)
                empty_avail.pack(fill="x", pady=(0, 12))
                tk.Label(empty_avail, text="No new courses available at the moment.", font=("Segoe UI", 10, "italic"), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(anchor="w")
            else:
                for c in available_courses:
                    card = tk.Frame(container, bg=COLOR_CARD_WHITE, padx=20, pady=16, highlightbackground=COLOR_BORDER, highlightthickness=1)
                    card.pack(fill="x", pady=(0, 12))

                    top_r = tk.Frame(card, bg=COLOR_CARD_WHITE)
                    top_r.pack(fill="x")

                    code_badge = tk.Label(top_r, text=f" {c.get('code')} ", font=("Segoe UI", 8, "bold"), bg="#F0FDF4", fg=COLOR_SUCCESS, padx=4, pady=2)
                    code_badge.pack(side="left", padx=(0, 8))

                    tk.Label(top_r, text=c.get("name"), font=("Segoe UI", 12, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(side="left")

                    enrolled_txt = f"👥 {c.get('enrolled_count', 0)} Enrolled"
                    tk.Label(top_r, text=enrolled_txt, font=("Segoe UI", 8, "bold"), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(side="right")

                    tk.Label(card, text=f"Instructor: {c.get('teacher_name')}", font=("Segoe UI", 8, "bold"), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(anchor="w", pady=(6, 2))
                    tk.Label(card, text=c.get("description", ""), font=("Segoe UI", 9), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE, wraplength=720, justify="left").pack(anchor="w", pady=(0, 12))

                    btn_r = tk.Frame(card, bg=COLOR_CARD_WHITE)
                    btn_r.pack(fill="x")
                    
                    PrimaryButton(btn_r, text="➕ Enroll Course", command=lambda cid=c.get("id"), cname=c.get("name"): self._enroll_course(cid, cname)).pack(side="left")

    def _drop_course(self, course_id: str, course_name: str):
        if messagebox.askyesno("Confirm Drop Course", f"Are you sure you want to drop '{course_name}'?"):
            mgr = CourseManager()
            mgr.drop_course(self.user.get("id"), course_id, self.user.get("name"))
            messagebox.showinfo("Course Dropped", f"You have dropped '{course_name}'. It is now listed under Available Courses.")
            self._build_ui()

    def _open_create_course_dialog(self):
        top = tk.Toplevel(self)
        top.title("Create New Course")
        top.geometry("460x420")
        top.configure(bg=COLOR_CARD_WHITE)
        top.transient(self)
        top.grab_set()

        pad_f = tk.Frame(top, bg=COLOR_CARD_WHITE, padx=24, pady=20)
        pad_f.pack(fill="both", expand=True)

        tk.Label(pad_f, text="➕  Create New Course", font=("Segoe UI", 13, "bold"),
                 fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(anchor="w", pady=(0, 2))
        tk.Label(pad_f, text="Publish a new academic course for your department",
                 font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(anchor="w", pady=(0, 14))

        code_var = tk.StringVar(value="CS305")
        name_var = tk.StringVar(value="")

        tk.Label(pad_f, text="Course Code *", font=("Segoe UI", 9, "bold"), bg=COLOR_CARD_WHITE, anchor="w").pack(fill="x", pady=(0, 2))
        tk.Entry(pad_f, textvariable=code_var, font=("Segoe UI", 10), relief="solid", bd=1).pack(fill="x", pady=(0, 8), ipady=3)

        tk.Label(pad_f, text="Course Title / Name *", font=("Segoe UI", 9, "bold"), bg=COLOR_CARD_WHITE, anchor="w").pack(fill="x", pady=(0, 2))
        tk.Entry(pad_f, textvariable=name_var, font=("Segoe UI", 10), relief="solid", bd=1).pack(fill="x", pady=(0, 8), ipady=3)

        tk.Label(pad_f, text="Description & Syllabus Summary", font=("Segoe UI", 9, "bold"), bg=COLOR_CARD_WHITE, anchor="w").pack(fill="x", pady=(0, 2))
        desc_text = tk.Text(pad_f, height=3, font=("Segoe UI", 9), relief="solid", bd=1)
        desc_text.pack(fill="x", pady=(0, 14))

        def save():
            code = code_var.get().strip()
            name = name_var.get().strip()
            desc = desc_text.get("1.0", "end-1c").strip()
            if not code or not name:
                messagebox.showerror("Error", "Please provide course code and name.", parent=top)
                return
            CourseManager().create_course(
                code=code.upper(),
                name=name,
                description=desc,
                teacher_id=self.user.get("id"),
                teacher_name=self.user.get("name")
            )
            top.destroy()
            self._build_ui()

        btn_f = tk.Frame(pad_f, bg=COLOR_CARD_WHITE)
        btn_f.pack(fill="x")
        SecondaryButton(btn_f, text="Cancel", command=top.destroy).pack(side="right", padx=(6, 0))
        PrimaryButton(btn_f, text="Create Course", command=save).pack(side="right")

    def _open_manage_course_modal(self, course: Dict[str, Any], live_count: int):
        top = tk.Toplevel(self)
        top.title(f"Manage Course — {course.get('name')}")
        top.geometry("500x500")
        top.configure(bg=COLOR_CARD_WHITE)
        top.transient(self)
        top.grab_set()

        pad_f = tk.Frame(top, bg=COLOR_CARD_WHITE, padx=24, pady=20)
        pad_f.pack(fill="both", expand=True)

        hdr_f = tk.Frame(pad_f, bg=COLOR_CARD_WHITE)
        hdr_f.pack(fill="x", pady=(0, 12))
        tk.Label(hdr_f, text=f"⚙  Manage Course: {course.get('name')}",
                 font=("Segoe UI", 13, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(anchor="w")
        tk.Label(hdr_f, text=f"{course.get('code', '—')}  •  Taught by {course.get('teacher_name', self.user.get('name'))}",
                 font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(anchor="w", pady=(2, 0))

        enroll_f = tk.Frame(pad_f, bg="#EFF6FF", highlightbackground="#BFDBFE", highlightthickness=1, padx=12, pady=10)
        enroll_f.pack(fill="x", pady=(0, 14))
        top_row = tk.Frame(enroll_f, bg="#EFF6FF")
        top_row.pack(fill="x")
        tk.Label(top_row, text="LIVE STUDENT ENROLLMENT", font=("Segoe UI", 8, "bold"), fg="#1D4ED8", bg="#EFF6FF").pack(side="left")
        tk.Label(top_row, text="● Live Linked", font=("Segoe UI", 8, "bold"), fg="#16A34A", bg="#EFF6FF").pack(side="right")
        tk.Label(enroll_f, text=f"{live_count} Student{'s' if live_count != 1 else ''} Currently Enrolled",
                 font=("Segoe UI", 12, "bold"), fg=COLOR_TEXT_MAIN, bg="#EFF6FF").pack(anchor="w", pady=(4, 0))

        code_var = tk.StringVar(value=course.get("code", ""))
        name_var = tk.StringVar(value=course.get("name", ""))

        tk.Label(pad_f, text="Course Code *", font=("Segoe UI", 9, "bold"), bg=COLOR_CARD_WHITE, anchor="w").pack(fill="x", pady=(0, 2))
        tk.Entry(pad_f, textvariable=code_var, font=("Segoe UI", 10), relief="solid", bd=1).pack(fill="x", pady=(0, 8), ipady=3)

        tk.Label(pad_f, text="Course Name *", font=("Segoe UI", 9, "bold"), bg=COLOR_CARD_WHITE, anchor="w").pack(fill="x", pady=(0, 2))
        tk.Entry(pad_f, textvariable=name_var, font=("Segoe UI", 10), relief="solid", bd=1).pack(fill="x", pady=(0, 8), ipady=3)

        tk.Label(pad_f, text="Description & Syllabus", font=("Segoe UI", 9, "bold"), bg=COLOR_CARD_WHITE, anchor="w").pack(fill="x", pady=(0, 2))
        desc_text = tk.Text(pad_f, height=3, font=("Segoe UI", 9), relief="solid", bd=1)
        desc_text.insert("1.0", course.get("description", ""))
        desc_text.pack(fill="x", pady=(0, 14))

        btn_f = tk.Frame(pad_f, bg=COLOR_CARD_WHITE)
        btn_f.pack(fill="x")

        def delete_course():
            if messagebox.askyesno("Delete Course", f"Are you sure you want to delete '{course.get('name')}'?", parent=top):
                CourseManager().delete_course(course_id=course.get("id"), user=self.user.get("name"))
                top.destroy()
                self._build_ui()

        tk.Button(btn_f, text="🗑  Delete Course", font=("Segoe UI", 9, "bold"), fg=COLOR_DANGER, bg=COLOR_CARD_WHITE,
                  activeforeground="#B91C1C", activebackground="#FEE2E2", relief="flat", cursor="hand2", padx=6, pady=4, command=delete_course).pack(side="left")

        def save_changes():
            new_code = code_var.get().strip().upper()
            new_name = name_var.get().strip()
            new_desc = desc_text.get("1.0", "end-1c").strip()
            if not new_code or not new_name:
                messagebox.showerror("Error", "Code and Name are required.", parent=top)
                return
            CourseManager().update_course(
                course_id=course.get("id"),
                updates={"code": new_code, "name": new_name, "description": new_desc},
                user=self.user.get("name")
            )
            top.destroy()
            self._build_ui()

        SecondaryButton(btn_f, text="Cancel", command=top.destroy).pack(side="right", padx=(6, 0))
        PrimaryButton(btn_f, text="Save Changes", command=save_changes).pack(side="right")




# ==============================================================================
# 3. CREATE ASSIGNMENT PAGE (Dedicated Teacher Form & Published List)
# ==============================================================================
class CreateAssignmentPage(tk.Frame):
    def __init__(self, parent, current_user: Dict[str, Any], on_navigate: Callable[[str], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.user = current_user
        self.on_navigate = on_navigate
        self._build_ui()

    def _build_ui(self):
        for w in self.winfo_children():
            w.destroy()

        container = _create_scrollable_container(self)

        hdr = tk.Frame(container, bg=COLOR_BG_LIGHT)
        hdr.pack(fill="x", pady=(0, 16))
        tk.Label(hdr, text="Create & Publish Assignment", font=("Segoe UI", 16, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(anchor="w")
        tk.Label(hdr, text="Design homework, coding tasks, or lab questions with automatic deadline tracking", font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_BG_LIGHT).pack(anchor="w")

        # Form Card
        form_card = ContentCard(container, title="Assignment Details Form", subtitle="Fill out the assignment parameters to dispatch to all enrolled students")
        form_card.pack(fill="x", pady=(0, 20))

        # Teacher's courses for dropdown
        my_courses = CourseManager().get_courses_by_teacher(self.user.get("id"))
        if not my_courses:
            my_courses = CourseManager().get_all_courses()

        course_names = [f"{c.get('code')} - {c.get('name')}" for c in my_courses]
        course_map = {f"{c.get('code')} - {c.get('name')}": c for c in my_courses}

        grid_form = tk.Frame(form_card, bg=COLOR_CARD_WHITE)
        grid_form.pack(fill="x", pady=(4, 10))
        grid_form.columnconfigure(0, weight=1)
        grid_form.columnconfigure(1, weight=1)

        # Course Dropdown
        tk.Label(grid_form, text="Select Course *", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).grid(row=0, column=0, sticky="w", pady=(2, 4), padx=(0, 10))
        course_var = tk.StringVar(value=course_names[0] if course_names else "Operating Systems")
        course_combo = ttk.Combobox(grid_form, textvariable=course_var, values=course_names, state="readonly", font=("Segoe UI", 9))
        course_combo.grid(row=1, column=0, sticky="ew", pady=(0, 10), padx=(0, 10))

        # Title
        tk.Label(grid_form, text="Assignment Title *", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).grid(row=0, column=1, sticky="w", pady=(2, 4), padx=(10, 0))
        title_e = tk.Entry(grid_form, font=("Segoe UI", 9), relief="solid", bd=1)
        title_e.insert(0, "Lab Exercise: Virtual Memory Simulation")
        title_e.grid(row=1, column=1, sticky="ew", pady=(0, 10), padx=(10, 0))

        # Due Date
        tk.Label(grid_form, text="Due Date (e.g. 24 Oct 2024) *", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).grid(row=2, column=0, sticky="w", pady=(2, 4), padx=(0, 10))
        due_e = tk.Entry(grid_form, font=("Segoe UI", 9), relief="solid", bd=1)
        due_e.insert(0, "25 Oct 2024")
        due_e.grid(row=3, column=0, sticky="ew", pady=(0, 10), padx=(0, 10))

        # Max Marks
        tk.Label(grid_form, text="Maximum Marks (Points) *", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).grid(row=2, column=1, sticky="w", pady=(2, 4), padx=(10, 0))
        marks_e = tk.Entry(grid_form, font=("Segoe UI", 9), relief="solid", bd=1)
        marks_e.insert(0, "20")
        marks_e.grid(row=3, column=1, sticky="ew", pady=(0, 10), padx=(10, 0))

        # Description
        tk.Label(form_card, text="Detailed Instructions & Problem Statement *", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(anchor="w", pady=(4, 4))
        desc_text = tk.Text(form_card, height=4, font=("Segoe UI", 9), relief="solid", bd=1)
        desc_text.pack(fill="x", pady=(0, 14))

        def publish():
            sel_course = course_map.get(course_var.get(), my_courses[0] if my_courses else {})
            cid = sel_course.get("id", "C101")
            cname = sel_course.get("name", "Operating Systems")
            title = title_e.get().strip()
            due = due_e.get().strip()
            desc = desc_text.get("1.0", "end-1c").strip()
            try:
                max_m = int(marks_e.get().strip())
            except ValueError:
                messagebox.showerror("Validation Error", "Maximum Marks must be a valid integer.")
                return

            if not title or not due or not desc:
                messagebox.showerror("Validation Error", "All fields are required to publish the assignment.")
                return

            AssignmentManager().create_assignment(
                course_id=cid,
                course_name=cname,
                title=title,
                description=desc,
                due_date=due,
                max_marks=max_m,
                created_by=self.user.get("id")
            )
            messagebox.showinfo("Success", f"Assignment '{title}' published successfully for {cname}!")
            self._build_ui()

        PrimaryButton(form_card, text="🚀 Publish Assignment to Students", command=publish).pack(anchor="w")

        # Below: All Published Assignments
        list_card = ContentCard(container, title="Currently Published Assignments", subtitle="Assignments dispatched to your enrolled batches")
        list_card.pack(fill="x", expand=True)

        all_assigns = AssignmentManager().get_all_assignments()
        for a in reversed(all_assigns):
            r = tk.Frame(list_card, bg=COLOR_CARD_WHITE, padx=14, pady=10, highlightbackground=COLOR_BORDER, highlightthickness=1)
            r.pack(fill="x", pady=3)

            top_line = tk.Frame(r, bg=COLOR_CARD_WHITE)
            top_line.pack(fill="x")

            tk.Label(top_line, text=a.get("title"), font=("Segoe UI", 10, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(side="left")
            BadgeLabel(top_line, text=f"{a.get('max_marks', 20)} Marks", status_type="Ready").pack(side="right")

            sub_line = tk.Frame(r, bg=COLOR_CARD_WHITE)
            sub_line.pack(fill="x", pady=(2, 4))
            tk.Label(sub_line, text=f"Course: {a.get('course_name')}", font=("Segoe UI", 8, "bold"), fg=COLOR_PRIMARY_BLUE, bg=COLOR_CARD_WHITE).pack(side="left", padx=(0, 12))
            tk.Label(sub_line, text=f"Due Date: {a.get('due_date')}", font=("Segoe UI", 8), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(side="left")

            tk.Label(r, text=a.get("description", ""), font=("Segoe UI", 8), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE, wraplength=700, justify="left").pack(anchor="w")


# ==============================================================================
# 4. VIEW & GRADE SUBMISSIONS PAGE (Dedicated Teacher Evaluation Portal)
# ==============================================================================
class ViewSubmissionsPage(tk.Frame):
    def __init__(self, parent, current_user: Dict[str, Any], on_navigate: Callable[[str], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.user = current_user
        self.on_navigate = on_navigate
        self._build_ui()

    def _build_ui(self):
        for w in self.winfo_children():
            w.destroy()

        container = _create_scrollable_container(self)

        hdr = tk.Frame(container, bg=COLOR_BG_LIGHT)
        hdr.pack(fill="x", pady=(0, 16))
        tk.Label(hdr, text="Student Submissions & Evaluation", font=("Segoe UI", 16, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(anchor="w")
        tk.Label(hdr, text="Review student work, assign marks, and provide constructive academic feedback", font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_BG_LIGHT).pack(anchor="w")

        # Load submissions (filtered by teacher if teacher role)
        sub_mgr = SubmissionManager()
        role = self.user.get("role", "student")
        if role == "teacher":
            subs = sub_mgr.get_submissions_by_teacher(self.user.get("id"))
        else:
            subs = sub_mgr.get_all_submissions()

        # Stats
        total_subs = len(subs)
        graded_count = sum(1 for s in subs if s.get("status") == "Graded")
        pending_count = total_subs - graded_count

        stats_frame = tk.Frame(container, bg=COLOR_BG_LIGHT)
        stats_frame.pack(fill="x", pady=(0, 20))
        StatCard(stats_frame, "Total Submissions", str(total_subs), "📁").pack(side="left", fill="both", expand=True, padx=(0, 8))
        StatCard(stats_frame, "Pending Evaluation", str(pending_count), "⏳", value_color=COLOR_WARNING).pack(side="left", fill="both", expand=True, padx=4)
        StatCard(stats_frame, "Evaluated & Graded", str(graded_count), "✅", value_color=COLOR_SUCCESS).pack(side="left", fill="both", expand=True, padx=(8, 0))

        # Submissions Table Card
        card = ContentCard(container, title="All Student Submissions", subtitle="Click 'Evaluate & Grade' to award marks and write feedback comments")
        card.pack(fill="x", expand=True)

        if not subs:
            tk.Label(card, text="No submissions received yet.", font=("Segoe UI", 10, "italic"), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE, pady=24).pack()
            return

        # Aligned Grid Table
        grid_table = tk.Frame(card, bg=COLOR_CARD_WHITE)
        grid_table.pack(fill="x", expand=True, pady=(6, 0))
        grid_table.columnconfigure(0, weight=3, minsize=190)
        grid_table.columnconfigure(1, weight=3, minsize=200)
        grid_table.columnconfigure(2, weight=2, minsize=160)
        grid_table.columnconfigure(3, weight=1, minsize=90)
        grid_table.columnconfigure(4, weight=1, minsize=90)
        grid_table.columnconfigure(5, weight=2, minsize=140)

        # Header Row
        hdr_bg = "#F8FAFC"
        h_frame = tk.Frame(grid_table, bg=hdr_bg, padx=10, pady=8, highlightbackground=COLOR_BORDER, highlightthickness=1)
        h_frame.grid(row=0, column=0, columnspan=6, sticky="ew", pady=(0, 4))
        h_frame.columnconfigure(0, weight=3, minsize=190)
        h_frame.columnconfigure(1, weight=3, minsize=200)
        h_frame.columnconfigure(2, weight=2, minsize=160)
        h_frame.columnconfigure(3, weight=1, minsize=90)
        h_frame.columnconfigure(4, weight=1, minsize=90)
        h_frame.columnconfigure(5, weight=2, minsize=140)

        tk.Label(h_frame, text="Student Name", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MUTED, bg=hdr_bg, anchor="w").grid(row=0, column=0, sticky="w", padx=6)
        tk.Label(h_frame, text="Course & Assignment", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MUTED, bg=hdr_bg, anchor="w").grid(row=0, column=1, sticky="w", padx=6)
        tk.Label(h_frame, text="Submitted File", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MUTED, bg=hdr_bg, anchor="w").grid(row=0, column=2, sticky="w", padx=6)
        tk.Label(h_frame, text="Status", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MUTED, bg=hdr_bg, anchor="center").grid(row=0, column=3, sticky="ew", padx=6)
        tk.Label(h_frame, text="Marks", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MUTED, bg=hdr_bg, anchor="center").grid(row=0, column=4, sticky="ew", padx=6)
        tk.Label(h_frame, text="Action", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MUTED, bg=hdr_bg, anchor="center").grid(row=0, column=5, sticky="ew", padx=6)

        for i, s in enumerate(subs, start=1):
            r_frame = tk.Frame(grid_table, bg=COLOR_CARD_WHITE, padx=10, pady=10, highlightbackground=COLOR_BORDER, highlightthickness=1)
            r_frame.grid(row=i, column=0, columnspan=6, sticky="ew", pady=2)
            r_frame.columnconfigure(0, weight=3, minsize=190)
            r_frame.columnconfigure(1, weight=3, minsize=200)
            r_frame.columnconfigure(2, weight=2, minsize=160)
            r_frame.columnconfigure(3, weight=1, minsize=90)
            r_frame.columnconfigure(4, weight=1, minsize=90)
            r_frame.columnconfigure(5, weight=2, minsize=140)

            # Col 0: Student Name & ID
            c0 = tk.Frame(r_frame, bg=COLOR_CARD_WHITE)
            c0.grid(row=0, column=0, sticky="w", padx=6)
            tk.Label(c0, text=s.get("student_name", "Student"), font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE, anchor="w").pack(anchor="w")
            tk.Label(c0, text=f"ID: {s.get('student_id')}", font=("Segoe UI", 8), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE, anchor="w").pack(anchor="w")

            # Col 1: Course & Assignment
            c1 = tk.Frame(r_frame, bg=COLOR_CARD_WHITE)
            c1.grid(row=0, column=1, sticky="w", padx=6)
            tk.Label(c1, text=s.get("assignment_title", "Assignment"), font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE, anchor="w").pack(anchor="w")
            tk.Label(c1, text=s.get("course_name", "Course"), font=("Segoe UI", 8), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE, anchor="w").pack(anchor="w")

            # Col 2: Submitted File & Date
            c2 = tk.Frame(r_frame, bg=COLOR_CARD_WHITE)
            c2.grid(row=0, column=2, sticky="w", padx=6)
            tk.Label(c2, text=f"📄 {s.get('file_name', 'submission.pdf')}", font=("Segoe UI", 8, "bold"), fg=COLOR_PRIMARY_BLUE, bg=COLOR_CARD_WHITE, anchor="w").pack(anchor="w")
            tk.Label(c2, text=s.get("submission_date", ""), font=("Segoe UI", 7), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE, anchor="w").pack(anchor="w")

            # Col 3: Status Badge
            c3 = tk.Frame(r_frame, bg=COLOR_CARD_WHITE)
            c3.grid(row=0, column=3, sticky="ew", padx=6)
            st = s.get("status", "Submitted")
            BadgeLabel(c3, text=st, status_type=st).pack(anchor="center")

            # Col 4: Marks
            c4 = tk.Frame(r_frame, bg=COLOR_CARD_WHITE)
            c4.grid(row=0, column=4, sticky="ew", padx=6)
            m = s.get("marks")
            if m is not None:
                tk.Label(c4, text=f"{m} / 20", font=("Segoe UI", 9, "bold"), fg=COLOR_SUCCESS, bg=COLOR_CARD_WHITE).pack(anchor="center")
            else:
                tk.Label(c4, text="—", font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(anchor="center")

            # Col 5: Grade Action
            c5 = tk.Frame(r_frame, bg=COLOR_CARD_WHITE)
            c5.grid(row=0, column=5, sticky="ew", padx=6)
            PrimaryButton(c5, text="📝 Grade", command=lambda sub=s: self._open_grading_modal(sub)).pack(anchor="center")

    def _open_grading_modal(self, sub: Dict[str, Any]):
        modal = tk.Toplevel(self)
        modal.title(f"Grade: {sub.get('student_name')} — {sub.get('assignment_title')}")
        modal.geometry("440x380")
        modal.configure(bg="white")
        modal.transient(self)
        modal.grab_set()

        content = tk.Frame(modal, bg="white", padx=24, pady=20)
        content.pack(fill="both", expand=True)

        tk.Label(content, text="Evaluation & Feedback", font=("Segoe UI", 14, "bold"), fg=COLOR_TEXT_MAIN, bg="white").pack(anchor="w")
        tk.Label(content, text=f"Student: {sub.get('student_name')} | Course: {sub.get('course_name')}", font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg="white").pack(anchor="w", pady=(0, 14))

        tk.Label(content, text="Marks Awarded (out of 20):", font=("Segoe UI", 9, "bold"), bg="white").pack(anchor="w")
        marks_entry = tk.Entry(content, font=("Segoe UI", 10), relief="solid", bd=1)
        curr_m = sub.get("marks")
        marks_entry.insert(0, str(curr_m) if curr_m is not None else "18")
        marks_entry.pack(fill="x", pady=(2, 10), ipady=2)

        tk.Label(content, text="Faculty Feedback / Observations:", font=("Segoe UI", 9, "bold"), bg="white").pack(anchor="w")
        feedback_entry = tk.Text(content, height=4, font=("Segoe UI", 9), relief="solid", bd=1)
        curr_fb = sub.get("feedback") or "Good technical formulation and correct calculations."
        feedback_entry.insert("1.0", curr_fb)
        feedback_entry.pack(fill="x", pady=(2, 16))

        def save():
            try:
                m_val = int(marks_entry.get().strip())
                if m_val < 0 or m_val > 100:
                    raise ValueError
            except ValueError:
                messagebox.showerror("Error", "Please enter a valid numeric mark.", parent=modal)
                return

            fb = feedback_entry.get("1.0", "end-1c").strip()
            SubmissionManager().grade_submission(
                submission_id=sub.get("id"),
                marks=m_val,
                feedback=fb,
                teacher_name=self.user.get("name")
            )
            modal.destroy()
            self._build_ui()

        btn_row = tk.Frame(content, bg="white")
        btn_row.pack(fill="x", pady=(4, 0))
        SecondaryButton(btn_row, text="Cancel", command=modal.destroy).pack(side="right", padx=(6, 0))
        PrimaryButton(btn_row, text="💾 Save Grade & Publish Feedback", command=save).pack(side="right")



# ==============================================================================
# 5. UPLOAD MATERIALS PAGE (Dedicated Teacher Resource Portal)
# ==============================================================================
class UploadMaterialsPage(tk.Frame):
    def __init__(self, parent, current_user: Dict[str, Any], on_navigate: Callable[[str], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.user = current_user
        self.on_navigate = on_navigate
        self._build_ui()

    def _build_ui(self):
        for w in self.winfo_children():
            w.destroy()

        container = _create_scrollable_container(self)

        hdr = tk.Frame(container, bg=COLOR_BG_LIGHT)
        hdr.pack(fill="x", pady=(0, 16))
        tk.Label(hdr, text="Upload Course Learning Materials", font=("Segoe UI", 16, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(anchor="w")
        tk.Label(hdr, text="Upload lecture slide decks, syllabus documents, and lab code exercises for students", font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_BG_LIGHT).pack(anchor="w")

        # Form Card
        form_card = ContentCard(container, title="Resource Upload Form", subtitle="Select file and specify course curriculum category")
        form_card.pack(fill="x", pady=(0, 20))

        my_courses = CourseManager().get_courses_by_teacher(self.user.get("id"))
        if not my_courses:
            my_courses = CourseManager().get_all_courses()

        course_names = [f"{c.get('code')} - {c.get('name')}" for c in my_courses]
        course_map = {f"{c.get('code')} - {c.get('name')}": c for c in my_courses}

        grid_form = tk.Frame(form_card, bg=COLOR_CARD_WHITE)
        grid_form.pack(fill="x", pady=(4, 10))
        grid_form.columnconfigure(0, weight=1)
        grid_form.columnconfigure(1, weight=1)

        # Select Course
        tk.Label(grid_form, text="Target Course *", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).grid(row=0, column=0, sticky="w", pady=(2, 4), padx=(0, 10))
        course_var = tk.StringVar(value=course_names[0] if course_names else "Operating Systems")
        course_combo = ttk.Combobox(grid_form, textvariable=course_var, values=course_names, state="readonly", font=("Segoe UI", 9))
        course_combo.grid(row=1, column=0, sticky="ew", pady=(0, 10), padx=(0, 10))

        # Title
        tk.Label(grid_form, text="Material Title / Topic *", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).grid(row=0, column=1, sticky="w", pady=(2, 4), padx=(10, 0))
        title_e = tk.Entry(grid_form, font=("Segoe UI", 9), relief="solid", bd=1)
        title_e.insert(0, "Lecture_05_Memory_Virtualization.pdf")
        title_e.grid(row=1, column=1, sticky="ew", pady=(0, 10), padx=(10, 0))

        # File Picker Row
        tk.Label(grid_form, text="Choose File *", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).grid(row=2, column=0, sticky="w", pady=(2, 4), padx=(0, 10))
        file_pick_f = tk.Frame(grid_form, bg=COLOR_CARD_WHITE)
        file_pick_f.grid(row=3, column=0, sticky="ew", pady=(0, 10), padx=(0, 10))

        file_path_var = tk.StringVar(value="Lecture_05_Memory_Virtualization.pdf")
        file_entry = tk.Entry(file_pick_f, textvariable=file_path_var, font=("Segoe UI", 9), relief="solid", bd=1)
        file_entry.pack(side="left", fill="x", expand=True, padx=(0, 6))

        def browse():
            fp = filedialog.askopenfilename(
                title="Select Material File",
                filetypes=[("Documents", "*.pdf *.docx *.pptx *.txt *.py *.zip"), ("All Files", "*.*")]
            )
            if fp:
                file_path_var.set(fp)

        SecondaryButton(file_pick_f, text="Browse...", command=browse).pack(side="right")

        # File Type
        tk.Label(grid_form, text="File Type *", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).grid(row=2, column=1, sticky="w", pady=(2, 4), padx=(10, 0))
        type_var = tk.StringVar(value="PDF")
        type_combo = ttk.Combobox(grid_form, textvariable=type_var, values=["PDF", "DOCX", "PPTX", "TXT", "CODE"], state="readonly", font=("Segoe UI", 9))
        type_combo.grid(row=3, column=1, sticky="ew", pady=(0, 10), padx=(10, 0))

        # Description
        tk.Label(form_card, text="Material Summary & Syllabus Notes", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(anchor="w", pady=(4, 4))
        desc_e = tk.Entry(form_card, font=("Segoe UI", 9), relief="solid", bd=1)
        desc_e.insert(0, "Comprehensive notes covering paging, page tables, TLB cache, and virtual memory protection.")
        desc_e.pack(fill="x", pady=(0, 14), ipady=2)

        def upload():
            sel_course = course_map.get(course_var.get(), my_courses[0] if my_courses else {})
            cid = sel_course.get("id", "C101")
            cname = sel_course.get("name", "Operating Systems")
            title = title_e.get().strip()
            fpath = file_path_var.get().strip()
            ftype = type_var.get().strip()
            desc = desc_e.get().strip()

            if not title or not fpath:
                messagebox.showerror("Error", "Please fill in material title and select a file.")
                return

            fname = Path(fpath).name
            dest = MATERIALS_DIR / fname
            if Path(fpath).exists() and Path(fpath) != dest:
                shutil.copy2(fpath, dest)
            elif not dest.exists():
                with open(dest, "w") as f:
                    f.write(f"Sample content for {title}")

            fsize = "2.4 MB"
            if dest.exists():
                size_kb = dest.stat().st_size / 1024
                fsize = f"{size_kb:.1f} KB" if size_kb < 1024 else f"{size_kb/1024:.1f} MB"

            MaterialManager().add_material(
                course_id=cid,
                course_name=cname,
                title=title,
                file_name=fname,
                file_type=ftype,
                file_size=fsize,
                uploaded_by=self.user.get("name"),
                uploaded_by_id=self.user.get("id"),
                description=desc
            )
            messagebox.showinfo("Upload Successful", f"Material '{title}' has been uploaded and made available for students!")
            self._build_ui()

        PrimaryButton(form_card, text="📤 Upload Resource to LMS", command=upload).pack(anchor="w")

        # Materials List
        list_card = ContentCard(container, title="Course Materials Archive", subtitle="All resources currently active for your courses")
        list_card.pack(fill="x", expand=True)

        all_mats = MaterialManager().get_all_materials()
        for m in reversed(all_mats):
            r = tk.Frame(list_card, bg=COLOR_CARD_WHITE, padx=14, pady=10, highlightbackground=COLOR_BORDER, highlightthickness=1)
            r.pack(fill="x", pady=2)

            top_line = tk.Frame(r, bg=COLOR_CARD_WHITE)
            top_line.pack(fill="x")

            ftype = m.get("file_type", "PDF")
            tk.Label(top_line, text=f" {ftype} ", font=("Segoe UI", 8, "bold"), bg="#EFF6FF", fg=COLOR_PRIMARY_BLUE, padx=4, pady=1).pack(side="left", padx=(0, 6))
            tk.Label(top_line, text=m.get("title"), font=("Segoe UI", 10, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(side="left")
            tk.Label(top_line, text=f"{m.get('file_size')} • {m.get('date')}", font=("Segoe UI", 8), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(side="right")

            tk.Label(r, text=f"Course: {m.get('course_name')} — {m.get('description', '')}", font=("Segoe UI", 8), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(anchor="w", pady=(2, 0))


# ==============================================================================
# 6. ASSIGNMENTS PAGE (For Students)
# ==============================================================================
class AssignmentsPage(tk.Frame):
    def __init__(self, parent, current_user: Dict[str, Any], on_navigate: Callable[[str], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.user = current_user
        self.on_navigate = on_navigate
        self._build_ui()

    def _build_ui(self):
        for w in self.winfo_children():
            w.destroy()

        container = _create_scrollable_container(self)

        hdr = tk.Frame(container, bg=COLOR_BG_LIGHT)
        hdr.pack(fill="x", pady=(0, 16))
        tk.Label(hdr, text="Course Assignments", font=("Segoe UI", 16, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(anchor="w")
        tk.Label(hdr, text="Complete course assignments and track deadline submissions", font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_BG_LIGHT).pack(anchor="w")

        assigns = JSONStore("assignments.json").load_all()
        subs = JSONStore("submissions.json").load_all()

        user_sub_map = {}
        for s in subs:
            if s.get("student_id") == self.user.get("id"):
                user_sub_map[s.get("assignment_id")] = s

        for a in assigns:
            card = tk.Frame(container, bg=COLOR_CARD_WHITE, padx=20, pady=16, highlightbackground=COLOR_BORDER, highlightthickness=1)
            card.pack(fill="x", pady=(0, 12))

            top_r = tk.Frame(card, bg=COLOR_CARD_WHITE)
            top_r.pack(fill="x")

            tk.Label(top_r, text=a.get("title"), font=("Segoe UI", 12, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(side="left")

            sub = user_sub_map.get(a.get("id"))
            if sub:
                BadgeLabel(top_r, text=sub.get("status", "Submitted"), status_type=sub.get("status", "Submitted")).pack(side="right")
            else:
                BadgeLabel(top_r, text="Pending", status_type="Pending").pack(side="right")

            info_r = tk.Frame(card, bg=COLOR_CARD_WHITE)
            info_r.pack(fill="x", pady=(4, 8))
            tk.Label(info_r, text=f"Course: {a.get('course_name')}", font=("Segoe UI", 9, "bold"), fg=COLOR_PRIMARY_BLUE, bg=COLOR_CARD_WHITE).pack(side="left", padx=(0, 14))
            tk.Label(info_r, text=f"Due Date: {a.get('due_date')}", font=("Segoe UI", 8), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(side="left", padx=(0, 14))
            tk.Label(info_r, text=f"Max Marks: {a.get('max_marks', 20)} pts", font=("Segoe UI", 8, "bold"), fg=COLOR_SUCCESS, bg=COLOR_CARD_WHITE).pack(side="left")

            tk.Label(card, text=a.get("description", ""), font=("Segoe UI", 9), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE, wraplength=700, justify="left").pack(anchor="w", pady=(0, 12))

            if sub:
                tk.Label(card, text=f"✓ Submitted: {sub.get('file_name')} ({sub.get('submission_date')})", font=("Segoe UI", 8, "bold"), fg=COLOR_SUCCESS, bg=COLOR_CARD_WHITE).pack(anchor="w")
            else:
                PrimaryButton(card, text="📤 Submit Solution", command=lambda aid=a.get("id"), aname=a.get("title"), cname=a.get("course_name"): self._submit_file(aid, aname, cname)).pack(anchor="w")

    def _submit_file(self, assign_id: str, assign_title: str, course_name: str):
        filepath = filedialog.askopenfilename(
            title=f"Select submission file for {assign_title}",
            filetypes=[("PDF and Documents", "*.pdf *.docx *.txt *.py"), ("All Files", "*.*")]
        )
        if not filepath:
            return

        p = Path(filepath)
        dest = SUBMISSIONS_DIR / p.name
        shutil.copy2(filepath, dest)

        sub_mgr = SubmissionManager()
        sub_mgr.submit_assignment(
            assignment_id=assign_id,
            assignment_title=assign_title,
            course_name=course_name,
            student_id=self.user.get("id"),
            student_name=self.user.get("name"),
            file_name=p.name,
            file_size="1.5 MB"
        )
        messagebox.showinfo("Submission Successful", f"Your assignment '{assign_title}' has been submitted!\nAn OS process has also been automatically dispatched into the ready queue.")
        self._build_ui()


# ==============================================================================
# 7. MATERIALS PAGE (For Students)
# ==============================================================================
class MaterialsPage(tk.Frame):
    def __init__(self, parent, current_user: Dict[str, Any], on_navigate: Callable[[str], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.user = current_user
        self.on_navigate = on_navigate
        self._build_ui()

    def _build_ui(self):
        for w in self.winfo_children():
            w.destroy()

        container = _create_scrollable_container(self)

        hdr = tk.Frame(container, bg=COLOR_BG_LIGHT)
        hdr.pack(fill="x", pady=(0, 16))
        tk.Label(hdr, text="Course Learning Materials", font=("Segoe UI", 16, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(anchor="w")
        tk.Label(hdr, text="Lecture slides, curriculum syllabus, notes, and study guides", font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_BG_LIGHT).pack(anchor="w")

        mats = JSONStore("materials.json").load_all()

        if not mats:
            empty_f = tk.Frame(container, bg=COLOR_CARD_WHITE, padx=20, pady=20, highlightbackground=COLOR_BORDER, highlightthickness=1)
            empty_f.pack(fill="x")
            tk.Label(empty_f, text="No learning materials uploaded yet.", font=("Segoe UI", 10, "italic"), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack()
            return

        for m in mats:
            card = tk.Frame(container, bg=COLOR_CARD_WHITE, padx=18, pady=14, highlightbackground=COLOR_BORDER, highlightthickness=1)
            card.pack(fill="x", pady=(0, 10))

            top_r = tk.Frame(card, bg=COLOR_CARD_WHITE)
            top_r.pack(fill="x")

            ftype = m.get("file_type", "PDF")
            type_bg = "#EFF6FF" if ftype == "PDF" else "#F0FDF4"
            type_fg = COLOR_PRIMARY_BLUE if ftype == "PDF" else COLOR_SUCCESS
            tk.Label(top_r, text=f" {ftype} ", font=("Segoe UI", 8, "bold"), bg=type_bg, fg=type_fg, padx=4, pady=2).pack(side="left", padx=(0, 8))

            tk.Label(top_r, text=m.get("title"), font=("Segoe UI", 11, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(side="left")
            tk.Label(top_r, text=m.get("date", ""), font=("Segoe UI", 8), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(side="right")

            info_r = tk.Frame(card, bg=COLOR_CARD_WHITE)
            info_r.pack(fill="x", pady=(4, 6))
            tk.Label(info_r, text=f"Course: {m.get('course_name')}", font=("Segoe UI", 8, "bold"), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(side="left", padx=(0, 12))
            tk.Label(info_r, text=f"Size: {m.get('file_size')}", font=("Segoe UI", 8), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(side="left", padx=(0, 12))
            tk.Label(info_r, text=f"Uploaded by: {m.get('uploaded_by')}", font=("Segoe UI", 8), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(side="left")

            tk.Label(card, text=m.get("description", ""), font=("Segoe UI", 8), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE, wraplength=700, justify="left").pack(anchor="w", pady=(0, 8))

            SecondaryButton(card, text="⬇️ Download Resource to System Downloads", command=lambda mat=m: self._download_material(mat)).pack(anchor="w")

    def _download_material(self, material: Dict[str, Any]):
        file_name = material.get("file_name") or f"{material.get('title', 'material').replace(' ', '_')}.pdf"
        
        # Target OS Downloads folder
        downloads_dir = Path.home() / "Downloads"
        downloads_dir.mkdir(parents=True, exist_ok=True)
        dest_file = downloads_dir / file_name

        try:
            src_file = MATERIALS_DIR / file_name
            if src_file.exists():
                shutil.copy(src_file, dest_file)
            else:
                title = material.get("title", file_name)
                course = material.get("course_name", "Course Material")
                uploader = material.get("uploaded_by", "Faculty")
                desc = material.get("description", "")
                
                content = (
                    f"========================================================================\n"
                    f"                      SMART LMS LEARNING MATERIAL                      \n"
                    f"========================================================================\n\n"
                    f"Title:       {title}\n"
                    f"Course:      {course}\n"
                    f"Uploaded By: {uploader}\n"
                    f"File Name:   {file_name}\n"
                    f"Date:        {material.get('date', '')}\n\n"
                    f"------------------------------------------------------------------------\n"
                    f"Description / Notes:\n"
                    f"{desc}\n"
                    f"------------------------------------------------------------------------\n\n"
                    f"This material was downloaded from Smart LMS into your system Downloads folder.\n"
                )
                with open(dest_file, "w", encoding="utf-8") as f:
                    f.write(content)

            ActivityLogger.log(f"Material downloaded: {file_name}", user=self.user.get("name", "Student"))
            
            messagebox.showinfo(
                "⬇️ Download Successful",
                f"Material '{material.get('title')}' downloaded successfully!\n\nSaved to Downloads folder:\n{dest_file}"
            )
            try:
                os.startfile(str(dest_file.parent))
            except Exception:
                pass
        except Exception as e:
            messagebox.showerror("Download Error", f"Could not save file to Downloads folder:\n{e}")



# ==============================================================================
# 8. USER PROFILE PAGE
# ==============================================================================
class ProfilePage(tk.Frame):
    def __init__(self, parent, current_user: Dict[str, Any], on_navigate: Callable[[str], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.user = current_user
        self.on_navigate = on_navigate
        self._build_ui()

    def _build_ui(self):
        for w in self.winfo_children():
            w.destroy()

        container = _create_scrollable_container(self)

        hdr = tk.Frame(container, bg=COLOR_BG_LIGHT)
        hdr.pack(fill="x", pady=(0, 16))
        tk.Label(hdr, text="User Account Profile", font=("Segoe UI", 16, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(anchor="w")
        tk.Label(hdr, text="Account details, role credentials, and institutional authorization", font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_BG_LIGHT).pack(anchor="w")

        card = tk.Frame(container, bg=COLOR_CARD_WHITE, padx=28, pady=24, highlightbackground=COLOR_BORDER, highlightthickness=1)
        card.pack(fill="x")

        top_f = tk.Frame(card, bg=COLOR_CARD_WHITE)
        top_f.pack(fill="x", pady=(0, 18))

        avatar = tk.Label(top_f, text="👤", font=("Segoe UI", 36), bg="#F1F5F9", width=3, height=1)
        avatar.pack(side="left", padx=(0, 16))

        info_col = tk.Frame(top_f, bg=COLOR_CARD_WHITE)
        info_col.pack(side="left", fill="both")

        tk.Label(info_col, text=self.user.get("name"), font=("Segoe UI", 16, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(anchor="w")
        tk.Label(info_col, text=f"@{self.user.get('username')}", font=("Segoe UI", 10), fg=COLOR_PRIMARY_BLUE, bg=COLOR_CARD_WHITE).pack(anchor="w")
        BadgeLabel(info_col, text=self.user.get("role", "student").upper(), status_type="Ready").pack(anchor="w", pady=(4, 0))

        grid_f = tk.Frame(card, bg="#F8FAFC", padx=16, pady=16, highlightbackground=COLOR_BORDER, highlightthickness=1)
        grid_f.pack(fill="x", pady=(0, 18))

        details = [
            ("User ID", self.user.get("id")),
            ("Email Address", self.user.get("email")),
            ("Account Role", self.user.get("role", "student").capitalize()),
            ("Account Status", "Active" if self.user.get("is_active", True) else "Inactive"),
            ("Registered Since", self.user.get("created_at", "01 Oct 2024")),
            ("Authentication Protocol", "PBKDF2-HMAC-SHA256 (600,000 iterations)")
        ]

        for i, (k, v) in enumerate(details):
            r = tk.Frame(grid_f, bg="#F8FAFC")
            r.pack(fill="x", pady=3)
            tk.Label(r, text=f"{k}:", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MUTED, bg="#F8FAFC", width=25, anchor="w").pack(side="left")
            tk.Label(r, text=str(v), font=("Segoe UI", 9), fg=COLOR_TEXT_MAIN, bg="#F8FAFC", anchor="w").pack(side="left")

        SecondaryButton(card, text="🔑 Change Password", command=lambda: messagebox.showinfo("Security", "Password modification is authenticated via Administrator.")).pack(anchor="w")


# ==============================================================================
# 9. MANAGE COURSES PAGE (Admin)
# ==============================================================================
class ManageCoursesPage(tk.Frame):
    def __init__(self, parent, current_user: Dict[str, Any], on_navigate: Callable[[str], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.user = current_user
        self.on_navigate = on_navigate
        self._build_ui()

    def _build_ui(self):
        for w in self.winfo_children():
            w.destroy()

        container = _create_scrollable_container(self)

        hdr = tk.Frame(container, bg=COLOR_BG_LIGHT)
        hdr.pack(fill="x", pady=(0, 16))
        tk.Label(hdr, text="Manage University Courses", font=("Segoe UI", 16, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(side="left")
        PrimaryButton(hdr, text="+ Add New Course", command=self._add_course_dialog).pack(side="right")

        courses = CourseManager().get_all_courses()

        for c in courses:
            card = tk.Frame(container, bg=COLOR_CARD_WHITE, padx=18, pady=12, highlightbackground=COLOR_BORDER, highlightthickness=1)
            card.pack(fill="x", pady=(0, 8))

            top_r = tk.Frame(card, bg=COLOR_CARD_WHITE)
            top_r.pack(fill="x")

            code_badge = tk.Label(top_r, text=f" {c.get('code')} ", font=("Segoe UI", 8, "bold"), bg="#EFF6FF", fg=COLOR_PRIMARY_BLUE, padx=4, pady=2)
            code_badge.pack(side="left", padx=(0, 8))

            tk.Label(top_r, text=c.get('name'), font=("Segoe UI", 11, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(side="left")
            tk.Label(top_r, text=f"Faculty: {c.get('teacher_name')}", font=("Segoe UI", 9, "bold"), fg=COLOR_PRIMARY_BLUE, bg=COLOR_CARD_WHITE).pack(side="right")

            tk.Label(card, text=c.get("description", ""), font=("Segoe UI", 8), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(anchor="w", pady=(4, 0))

    def _add_course_dialog(self):
        d = tk.Toplevel(self)
        d.title("Add Course")
        d.geometry("380x320")
        d.configure(bg="white")
        f = tk.Frame(d, bg="white", padx=20, pady=16)
        f.pack(fill="both", expand=True)

        tk.Label(f, text="Course Code (e.g. CS305):", font=("Segoe UI", 9, "bold"), bg="white").pack(anchor="w")
        code_e = tk.Entry(f, font=("Segoe UI", 10), relief="solid", bd=1)
        code_e.pack(fill="x", pady=(2, 8), ipady=2)

        tk.Label(f, text="Course Name:", font=("Segoe UI", 9, "bold"), bg="white").pack(anchor="w")
        name_e = tk.Entry(f, font=("Segoe UI", 10), relief="solid", bd=1)
        name_e.pack(fill="x", pady=(2, 8), ipady=2)

        tk.Label(f, text="Description:", font=("Segoe UI", 9, "bold"), bg="white").pack(anchor="w")
        desc_e = tk.Entry(f, font=("Segoe UI", 10), relief="solid", bd=1)
        desc_e.pack(fill="x", pady=(2, 14), ipady=2)

        def save():
            c, n, desc = code_e.get().strip(), name_e.get().strip(), desc_e.get().strip()
            if not c or not n:
                messagebox.showerror("Error", "Please fill in code and name.", parent=d)
                return
            CourseManager().create_course(c, n, desc, self.user.get("id"), self.user.get("name"))
            d.destroy()
            self._build_ui()

        PrimaryButton(f, text="Save Course", command=save).pack(fill="x", ipady=3)


# ==============================================================================
# 10. MANAGE USERS PAGE (Admin)
# ==============================================================================
class ManageUsersPage(tk.Frame):
    def __init__(self, parent, current_user: Dict[str, Any], on_navigate: Callable[[str], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.user = current_user
        self.on_navigate = on_navigate
        self._build_ui()

    def _build_ui(self):
        for w in self.winfo_children():
            w.destroy()

        container = _create_scrollable_container(self)

        hdr = tk.Frame(container, bg=COLOR_BG_LIGHT)
        hdr.pack(fill="x", pady=(0, 16))
        tk.Label(hdr, text="Manage System Users", font=("Segoe UI", 16, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(side="left")
        PrimaryButton(hdr, text="+ Register New User", command=self._add_user_dialog).pack(side="right")

        users_store = JSONStore("users.json")
        users = users_store.load_all()

        card = ContentCard(container, title=f"All Registered Users ({len(users)})", subtitle="Student, Teacher, and Administrator accounts")
        card.pack(fill="x", expand=True)

        for u in users:
            r = tk.Frame(card, bg=COLOR_CARD_WHITE, padx=12, pady=10, highlightbackground=COLOR_BORDER, highlightthickness=1)
            r.pack(fill="x", pady=2)

            tk.Label(r, text="👤", font=("Segoe UI", 12), bg=COLOR_CARD_WHITE).pack(side="left", padx=(0, 8))

            info_f = tk.Frame(r, bg=COLOR_CARD_WHITE)
            info_f.pack(side="left", fill="both", expand=True)
            tk.Label(info_f, text=f"{u.get('name')}  (@{u.get('username')})", font=("Segoe UI", 10, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(anchor="w")
            tk.Label(info_f, text=f"ID: {u.get('id')} • Email: {u.get('email')} • Joined: {u.get('created_at', '2024')}", font=("Segoe UI", 8), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(anchor="w")

            BadgeLabel(r, text=u.get("role", "student").upper(), status_type="Running" if u.get("role") == "admin" else ("Ready" if u.get("role") == "teacher" else "Terminated")).pack(side="right", padx=6)
            status_txt = "Active" if u.get("is_active", True) else "Inactive"
            BadgeLabel(r, text=status_txt, status_type="Ready" if status_txt == "Active" else "Late").pack(side="right")

    def _add_user_dialog(self):
        d = tk.Toplevel(self)
        d.title("Add New User")
        d.geometry("380x360")
        d.configure(bg="white")
        f = tk.Frame(d, bg="white", padx=20, pady=16)
        f.pack(fill="both", expand=True)

        tk.Label(f, text="Full Name:", font=("Segoe UI", 9, "bold"), bg="white").pack(anchor="w")
        name_e = tk.Entry(f, font=("Segoe UI", 10), relief="solid", bd=1)
        name_e.pack(fill="x", pady=(2, 6), ipady=2)

        tk.Label(f, text="Username:", font=("Segoe UI", 9, "bold"), bg="white").pack(anchor="w")
        user_e = tk.Entry(f, font=("Segoe UI", 10), relief="solid", bd=1)
        user_e.pack(fill="x", pady=(2, 6), ipady=2)

        tk.Label(f, text="Password:", font=("Segoe UI", 9, "bold"), bg="white").pack(anchor="w")
        pass_e = tk.Entry(f, show="•", font=("Segoe UI", 10), relief="solid", bd=1)
        pass_e.pack(fill="x", pady=(2, 6), ipady=2)

        role_var = tk.StringVar(value="student")
        rf = tk.Frame(f, bg="white")
        rf.pack(fill="x", pady=(4, 12))
        tk.Radiobutton(rf, text="Student", variable=role_var, value="student", bg="white").pack(side="left")
        tk.Radiobutton(rf, text="Teacher", variable=role_var, value="teacher", bg="white").pack(side="left", padx=10)

        def save():
            from auth.authentication import Authenticator
            n, u, p = name_e.get().strip(), user_e.get().strip().lower(), pass_e.get().strip()
            if not n or not u or not p:
                messagebox.showerror("Error", "Please fill in all fields.", parent=d)
                return
            Authenticator.register_user(n, u, p, role_var.get())
            d.destroy()
            self._build_ui()

        PrimaryButton(f, text="Register User", command=save).pack(fill="x", ipady=3)


# ==============================================================================
# 11. SYSTEM ACTIVITY LOG PAGE (Admin)
# ==============================================================================
class SystemActivityPage(tk.Frame):
    def __init__(self, parent, current_user: Dict[str, Any], on_navigate: Callable[[str], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.user = current_user
        self.on_navigate = on_navigate
        self._build_ui()

    def _build_ui(self):
        for w in self.winfo_children():
            w.destroy()

        container = _create_scrollable_container(self)

        hdr = tk.Frame(container, bg=COLOR_BG_LIGHT)
        hdr.pack(fill="x", pady=(0, 16))
        tk.Label(hdr, text="Complete System Activity Log", font=("Segoe UI", 16, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(side="left")
        SecondaryButton(hdr, text="🔄 Refresh Log", command=self._build_ui).pack(side="right")

        act_store = JSONStore("activity_log.json")
        acts = list(reversed(act_store.load_all()))

        card = ContentCard(container, title=f"Audit Trail ({len(acts)} events)", subtitle="Real-time security and operational events logged across Smart LMS and OS Simulator")
        card.pack(fill="x", expand=True)

        for a in acts:
            r = tk.Frame(card, bg=COLOR_CARD_WHITE, padx=12, pady=8, highlightbackground=COLOR_BORDER, highlightthickness=1)
            r.pack(fill="x", pady=2)

            tk.Label(r, text=a.get("timestamp", ""), font=("Segoe UI", 8), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE, width=22, anchor="w").pack(side="left")
            tk.Label(r, text=a.get("activity", ""), font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE, anchor="w").pack(side="left", fill="x", expand=True)
            tk.Label(r, text=f"by {a.get('user', 'System')}", font=("Segoe UI", 8, "bold"), fg=COLOR_PRIMARY_BLUE, bg=COLOR_CARD_WHITE).pack(side="right")
