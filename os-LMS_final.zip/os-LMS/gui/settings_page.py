"""
Settings Page View for Smart LMS (Python Tkinter).
Allows Administrator to configure OS Simulator parameters, inspect security protocols,
and perform system data maintenance.
"""
import tkinter as tk
from tkinter import ttk, messagebox
from typing import Dict, Any, Callable

try:
    from config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_SUCCESS, COLOR_DANGER
    )
    from storage.json_store import ActivityLogger
    from gui.components import ContentCard, PrimaryButton, SecondaryButton
except ImportError:
    from SmartLMS.config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_SUCCESS, COLOR_DANGER
    )
    from SmartLMS.storage.json_store import ActivityLogger
    from SmartLMS.gui.components import ContentCard, PrimaryButton, SecondaryButton

class SettingsPage(tk.Frame):
    def __init__(self, parent, current_user: Dict[str, Any], on_navigate: Callable[[str], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.user = current_user
        self.on_navigate = on_navigate
        self._build_ui()

    def _build_ui(self):
        for widget in self.winfo_children():
            widget.destroy()

        container = tk.Frame(self, bg=COLOR_BG_LIGHT, padx=24, pady=20)
        container.pack(fill="both", expand=True)

        # Header
        header_frame = tk.Frame(container, bg=COLOR_BG_LIGHT)
        header_frame.pack(fill="x", pady=(0, 16))

        tk.Label(
            header_frame, text="System Settings",
            font=("Segoe UI", 16, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT
        ).pack(anchor="w")

        tk.Label(
            header_frame, text="Configure OS Simulator parameters, security controls, and storage maintenance",
            font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_BG_LIGHT
        ).pack(anchor="w")

        # Card 1: OS Simulator Tuning
        card1 = ContentCard(container, title="OS Simulator Configuration")
        card1.pack(fill="x", pady=(0, 14))

        f1 = tk.Frame(card1, bg=COLOR_CARD_WHITE)
        f1.pack(fill="x")

        # Default Quantum
        tk.Label(f1, text="Default Round Robin Quantum (ms):", font=("Segoe UI", 9, "bold"), bg=COLOR_CARD_WHITE).grid(row=0, column=0, sticky="w", pady=4)
        self.q_entry = tk.Entry(f1, font=("Segoe UI", 9), width=10, relief="solid", bd=1)
        self.q_entry.insert(0, "2")
        self.q_entry.grid(row=0, column=1, sticky="w", padx=10, pady=4)

        # Default Memory Pool
        tk.Label(f1, text="Simulated Memory Pool Size (MB):", font=("Segoe UI", 9, "bold"), bg=COLOR_CARD_WHITE).grid(row=1, column=0, sticky="w", pady=4)
        self.m_entry = tk.Entry(f1, font=("Segoe UI", 9), width=10, relief="solid", bd=1)
        self.m_entry.insert(0, "1000")
        self.m_entry.grid(row=1, column=1, sticky="w", padx=10, pady=4)

        # Buffer Capacity
        tk.Label(f1, text="Producer-Consumer Buffer Capacity:", font=("Segoe UI", 9, "bold"), bg=COLOR_CARD_WHITE).grid(row=2, column=0, sticky="w", pady=4)
        self.b_entry = tk.Entry(f1, font=("Segoe UI", 9), width=10, relief="solid", bd=1)
        self.b_entry.insert(0, "5")
        self.b_entry.grid(row=2, column=1, sticky="w", padx=10, pady=4)

        # Card 2: Security & Password Architecture
        card2 = ContentCard(container, title="Security & Authentication Protocol")
        card2.pack(fill="x", pady=(0, 14))

        sec_text = (
            "• Password Storage: Salted PBKDF2-HMAC-SHA256 (100,000 hash iterations)\n"
            "• Role-Based Access Control: Student, Teacher, and Administrator access guards\n"
            "• Process Boundary: All simulated OS operations run in memory without host OS privilege elevation"
        )
        tk.Label(card2, text=sec_text, font=("Segoe UI", 9), justify="left", fg="#1E293B", bg=COLOR_CARD_WHITE).pack(anchor="w")

        # Card 3: Storage Maintenance
        card3 = ContentCard(container, title="Database Maintenance")
        card3.pack(fill="x", pady=(0, 16))

        btn_row = tk.Frame(card3, bg=COLOR_CARD_WHITE)
        btn_row.pack(fill="x", pady=4)

        PrimaryButton(btn_row, text="Save Settings", command=self._save_settings).pack(side="left", padx=(0, 8))
        SecondaryButton(btn_row, text="Clear Activity Log", command=self._clear_logs).pack(side="left", padx=8)

    def _save_settings(self):
        q = self.q_entry.get().strip()
        m = self.m_entry.get().strip()
        b = self.b_entry.get().strip()
        ActivityLogger.log(f"System settings updated (Quantum={q}ms, Pool={m}MB, Buffer={b})", user=self.user.get("name"))
        messagebox.showinfo("Settings Saved", "System settings successfully updated and saved to configuration.")

    def _clear_logs(self):
        if messagebox.askyesno("Confirm", "Clear all recorded activity entries?"):
            from storage.json_store import JSONStore
            JSONStore("activity_log.json").save_all([])
            messagebox.showinfo("Cleared", "Activity log cleared.")
