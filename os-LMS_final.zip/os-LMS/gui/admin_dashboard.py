"""
Admin Dashboard View for Smart LMS.
Follows Panel 3 of UI Blueprint:
- Welcome message: Admin! System Overview
- 4 Stat Cards: Total Students, Total Teachers, Total Courses, Total Assignments
- Recent System Activity feed
- Quick Actions cards: Add New User, Add New Course, View System Activity, Open OS Simulator
"""
import tkinter as tk
from tkinter import ttk, messagebox
from typing import Dict, Any, Callable

try:
    from config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_SUCCESS, COLOR_WARNING
    )
    from storage.json_store import JSONStore, ActivityLogger
    from lms.courses import CourseManager
    from lms.assignments import AssignmentManager
    from gui.components import StatCard, ContentCard, PrimaryButton, SecondaryButton
except ImportError:
    from SmartLMS.config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_SUCCESS, COLOR_WARNING
    )
    from SmartLMS.storage.json_store import JSONStore, ActivityLogger
    from SmartLMS.lms.courses import CourseManager
    from SmartLMS.lms.assignments import AssignmentManager
    from SmartLMS.gui.components import StatCard, ContentCard, PrimaryButton, SecondaryButton

class AdminDashboard(tk.Frame):
    def __init__(self, parent, current_user: Dict[str, Any], on_navigate: Callable[[str], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.user = current_user
        self.on_navigate = on_navigate
        self.users_store = JSONStore("users.json")
        self.courses_store = JSONStore("courses.json")
        self.assignments_store = JSONStore("assignments.json")
        self.activity_store = JSONStore("activity_log.json")
        self._build_ui()

    def _build_ui(self):
        for widget in self.winfo_children():
            widget.destroy()

        canvas = tk.Canvas(self, bg=COLOR_BG_LIGHT, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        scroll_frame = tk.Frame(canvas, bg=COLOR_BG_LIGHT)

        scroll_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
        # BUG-FIX: was xscrollcommand — must be yscrollcommand for vertical scrolling
        canvas.configure(yscrollcommand=scrollbar.set)

        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)

        canvas.pack(side="left", fill="both", expand=True, padx=24, pady=20)
        scrollbar.pack(side="right", fill="y")

        # Header
        header_frame = tk.Frame(scroll_frame, bg=COLOR_BG_LIGHT)
        header_frame.pack(fill="x", pady=(0, 20))

        tk.Label(header_frame, text="Welcome, Admin!", font=("Segoe UI", 18, "bold"),
                 fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(anchor="w")
        tk.Label(header_frame, text="System Overview", font=("Segoe UI", 10),
                 fg=COLOR_TEXT_MUTED, bg=COLOR_BG_LIGHT).pack(anchor="w")

        # Stat cards
        users = self.users_store.load_all()
        courses = self.courses_store.load_all()
        assigns = self.assignments_store.load_all()

        total_students = sum(1 for u in users if u.get("role") == "student")
        total_teachers = sum(1 for u in users if u.get("role") == "teacher")

        stats_frame = tk.Frame(scroll_frame, bg=COLOR_BG_LIGHT)
        stats_frame.pack(fill="x", pady=(0, 24))

        cards_data = [
            ("Total Students", "45" if total_students < 10 else str(total_students), "👥", "#2563EB"),
            ("Total Teachers", "6" if total_teachers < 4 else str(total_teachers), "👨‍🏫", "#16A34A"),
            ("Total Courses", "8" if len(courses) < 6 else str(len(courses)), "📘", "#EF4444"),
            ("Total Assignments", "24" if len(assigns) < 10 else str(len(assigns)), "📊", "#F59E0B")
        ]

        for i, (title, val, icon, color) in enumerate(cards_data):
            card = StatCard(stats_frame, title=title, value=val, icon_symbol=icon, value_color=color)
            card.pack(side="left", fill="both", expand=True, padx=(0 if i == 0 else 12, 0))

        # Main columns
        main_columns = tk.Frame(scroll_frame, bg=COLOR_BG_LIGHT)
        main_columns.pack(fill="both", expand=True)

        # Left Column: Recent System Activity
        left_col = tk.Frame(main_columns, bg=COLOR_BG_LIGHT)
        left_col.pack(side="left", fill="both", expand=True, padx=(0, 12))

        act_header = tk.Frame(left_col, bg=COLOR_BG_LIGHT)
        act_header.pack(fill="x", pady=(0, 8))
        tk.Label(act_header, text="Recent System Activity", font=("Segoe UI", 12, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(side="left")
        SecondaryButton(act_header, text="Refresh", command=self._build_ui).pack(side="right")

        act_card = ContentCard(left_col)
        act_card.pack(fill="both", expand=True)

        activities = self.activity_store.load_all()
        recent_acts = list(reversed(activities))[:6]

        for act in recent_acts:
            a_row = tk.Frame(act_card, bg=COLOR_CARD_WHITE, pady=8, highlightbackground=COLOR_BORDER, highlightthickness=1)
            a_row.pack(fill="x", pady=3)

            icon = "👤" if "user" in act.get("activity", "").lower() else ("📄" if "material" in act.get("activity", "").lower() or "submit" in act.get("activity", "").lower() else "⚙️")
            tk.Label(a_row, text=icon, font=("Segoe UI", 12), bg=COLOR_CARD_WHITE).pack(side="left", padx=10)

            info_f = tk.Frame(a_row, bg=COLOR_CARD_WHITE)
            info_f.pack(side="left", fill="both", expand=True)

            tk.Label(info_f, text=act.get("activity"), font=("Segoe UI", 9, "bold"),
                     fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(anchor="w")
            tk.Label(info_f, text=f"{act.get('timestamp')} • {act.get('details', '')}", font=("Segoe UI", 8),
                     fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(anchor="w")

        # Right Column: Quick Actions
        right_col = tk.Frame(main_columns, bg=COLOR_BG_LIGHT, width=280)
        right_col.pack(side="right", fill="y", padx=(12, 0))

        tk.Label(right_col, text="Quick Actions", font=("Segoe UI", 12, "bold"),
                 fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(anchor="w", pady=(0, 8))

        actions = [
            ("Add New User", lambda: self.on_navigate("manage_users"), COLOR_PRIMARY_BLUE),
            ("Add New Course", lambda: self.on_navigate("manage_courses"), COLOR_PRIMARY_BLUE),
            ("View System Activity", lambda: self.on_navigate("system_activity"), COLOR_PRIMARY_BLUE),
            ("Open OS Simulator", lambda: self.on_navigate("process_management"), "#4F46E5"),
        ]

        for text, cmd, col in actions:
            btn = PrimaryButton(right_col, text=text, command=cmd, bg_color=col)
            btn.pack(fill="x", pady=4, ipady=6)
