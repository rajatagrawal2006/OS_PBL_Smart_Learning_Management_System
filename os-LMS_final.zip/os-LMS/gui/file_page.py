"""
OS Simulator - File Management View.
Follows Panel 4.4 of UI Blueprint:
- Manage course materials and student submissions
- Tabs: Course Materials vs Student Submissions
- Real local filesystem operations (upload, delete, preview)
- Action buttons: Upload File (blue), Delete (red)
"""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from typing import Dict, Any, Callable

try:
    from config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_DANGER
    )
    from os_simulator.file_manager import LocalFileManager
    from gui.components import ContentCard, PrimaryButton, SecondaryButton
except ImportError:
    from SmartLMS.config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_DANGER
    )
    from SmartLMS.os_simulator.file_manager import LocalFileManager
    from SmartLMS.gui.components import ContentCard, PrimaryButton, SecondaryButton

class FilePage(tk.Frame):
    def __init__(self, parent, current_user: Dict[str, Any], on_navigate: Callable[[str], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.user = current_user
        self.on_navigate = on_navigate
        self.fm = LocalFileManager()
        self.active_tab = "materials"  # or 'submissions'
        self._build_ui()

    def _build_ui(self):
        for widget in self.winfo_children():
            widget.destroy()

        container = tk.Frame(self, bg=COLOR_BG_LIGHT, padx=24, pady=20)
        container.pack(fill="both", expand=True)

        # Header
        header_frame = tk.Frame(container, bg=COLOR_BG_LIGHT)
        header_frame.pack(fill="x", pady=(0, 16))

        title_frame = tk.Frame(header_frame, bg=COLOR_BG_LIGHT)
        title_frame.pack(side="left")
        tk.Label(title_frame, text="File Management", font=("Segoe UI", 16, "bold"),
                 fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(anchor="w")
        tk.Label(title_frame, text="Manage course materials and submissions stored in the local file directory",
                 font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_BG_LIGHT).pack(anchor="w")

        # Top Buttons
        btn_frame = tk.Frame(header_frame, bg=COLOR_BG_LIGHT)
        btn_frame.pack(side="right")
        PrimaryButton(btn_frame, text="Upload File", command=self._open_upload_dialog).pack(side="left", padx=4)

        # Tabs bar
        tab_frame = tk.Frame(container, bg=COLOR_BG_LIGHT)
        tab_frame.pack(fill="x", pady=(0, 10))

        m_btn = tk.Button(tab_frame, text="Course Materials", font=("Segoe UI", 10, "bold"),
                          bg=COLOR_PRIMARY_BLUE if self.active_tab == "materials" else "#E2E8F0",
                          fg="white" if self.active_tab == "materials" else COLOR_TEXT_MAIN,
                          relief="flat", padx=14, pady=6, cursor="hand2",
                          command=lambda: self._switch_tab("materials"))
        m_btn.pack(side="left", padx=(0, 6))

        s_btn = tk.Button(tab_frame, text="Student Submissions", font=("Segoe UI", 10, "bold"),
                          bg=COLOR_PRIMARY_BLUE if self.active_tab == "submissions" else "#E2E8F0",
                          fg="white" if self.active_tab == "submissions" else COLOR_TEXT_MAIN,
                          relief="flat", padx=14, pady=6, cursor="hand2",
                          command=lambda: self._switch_tab("submissions"))
        s_btn.pack(side="left")

        # Main Table Card
        card = ContentCard(container)
        card.pack(fill="both", expand=True)

        if self.active_tab == "materials":
            self._render_materials_table(card)
        else:
            self._render_submissions_table(card)

    def _switch_tab(self, tab: str):
        self.active_tab = tab
        self._build_ui()

    def _render_materials_table(self, card: tk.Frame):
        th = tk.Frame(card, bg="#F1F5F9", pady=6)
        th.pack(fill="x", pady=(0, 4))

        tk.Label(th, text="File Name", font=("Segoe UI", 9, "bold"), width=24, anchor="w", bg="#F1F5F9").pack(side="left", padx=8)
        tk.Label(th, text="Type", font=("Segoe UI", 9, "bold"), width=8, anchor="w", bg="#F1F5F9").pack(side="left", padx=8)
        tk.Label(th, text="Size", font=("Segoe UI", 9, "bold"), width=10, anchor="w", bg="#F1F5F9").pack(side="left", padx=8)
        tk.Label(th, text="Uploaded By", font=("Segoe UI", 9, "bold"), width=16, anchor="w", bg="#F1F5F9").pack(side="left", padx=8)
        tk.Label(th, text="Date", font=("Segoe UI", 9, "bold"), width=12, anchor="w", bg="#F1F5F9").pack(side="left", padx=8)
        tk.Label(th, text="Action", font=("Segoe UI", 9, "bold"), width=12, anchor="center", bg="#F1F5F9").pack(side="right", padx=8)

        materials = self.fm.get_course_materials()
        for mat in materials:
            row = tk.Frame(card, bg=COLOR_CARD_WHITE, pady=6, highlightbackground=COLOR_BORDER, highlightthickness=1)
            row.pack(fill="x", pady=2)

            tk.Label(row, text=mat.get("file_name"), font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, width=24, anchor="w", bg=COLOR_CARD_WHITE).pack(side="left", padx=8)
            tk.Label(row, text=mat.get("file_type"), font=("Segoe UI", 9), width=8, anchor="w", bg=COLOR_CARD_WHITE).pack(side="left", padx=8)
            tk.Label(row, text=mat.get("file_size"), font=("Segoe UI", 9), width=10, anchor="w", bg=COLOR_CARD_WHITE).pack(side="left", padx=8)
            tk.Label(row, text=mat.get("uploaded_by"), font=("Segoe UI", 9), width=16, anchor="w", bg=COLOR_CARD_WHITE).pack(side="left", padx=8)
            tk.Label(row, text=mat.get("date"), font=("Segoe UI", 9), width=12, anchor="w", bg=COLOR_CARD_WHITE).pack(side="left", padx=8)

            act_f = tk.Frame(row, bg=COLOR_CARD_WHITE)
            act_f.pack(side="right", padx=8)

            tk.Button(act_f, text="👁", font=("Segoe UI", 9), relief="flat", bg="#EFF6FF",
                      command=lambda m=mat: messagebox.showinfo("File Preview", f"File: {m.get('file_name')}\nType: {m.get('file_type')}\nSize: {m.get('file_size')}\nDescription: {m.get('description', 'No description provided')}")).pack(side="left", padx=2)
            tk.Button(act_f, text="🗑", font=("Segoe UI", 9), relief="flat", bg="#FEE2E2", fg=COLOR_DANGER,
                      command=lambda m=mat: self._delete_mat(m.get("id"))).pack(side="left", padx=2)

    def _render_submissions_table(self, card: tk.Frame):
        th = tk.Frame(card, bg="#F1F5F9", pady=6)
        th.pack(fill="x", pady=(0, 4))

        tk.Label(th, text="File Name", font=("Segoe UI", 9, "bold"), width=22, anchor="w", bg="#F1F5F9").pack(side="left", padx=8)
        tk.Label(th, text="Student", font=("Segoe UI", 9, "bold"), width=14, anchor="w", bg="#F1F5F9").pack(side="left", padx=8)
        tk.Label(th, text="Assignment", font=("Segoe UI", 9, "bold"), width=18, anchor="w", bg="#F1F5F9").pack(side="left", padx=8)
        tk.Label(th, text="Size", font=("Segoe UI", 9, "bold"), width=8, anchor="w", bg="#F1F5F9").pack(side="left", padx=8)
        tk.Label(th, text="Status", font=("Segoe UI", 9, "bold"), width=12, anchor="w", bg="#F1F5F9").pack(side="left", padx=8)
        tk.Label(th, text="Action", font=("Segoe UI", 9, "bold"), width=10, anchor="center", bg="#F1F5F9").pack(side="right", padx=8)

        subs = self.fm.get_student_submissions()
        for sub in subs:
            row = tk.Frame(card, bg=COLOR_CARD_WHITE, pady=6, highlightbackground=COLOR_BORDER, highlightthickness=1)
            row.pack(fill="x", pady=2)

            tk.Label(row, text=sub.get("file_name"), font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, width=22, anchor="w", bg=COLOR_CARD_WHITE).pack(side="left", padx=8)
            tk.Label(row, text=sub.get("student_name", "Student").split()[0], font=("Segoe UI", 9), width=14, anchor="w", bg=COLOR_CARD_WHITE).pack(side="left", padx=8)
            tk.Label(row, text=sub.get("assignment_title"), font=("Segoe UI", 9), width=18, anchor="w", bg=COLOR_CARD_WHITE).pack(side="left", padx=8)
            tk.Label(row, text=sub.get("file_size"), font=("Segoe UI", 9), width=8, anchor="w", bg=COLOR_CARD_WHITE).pack(side="left", padx=8)
            tk.Label(row, text=sub.get("status"), font=("Segoe UI", 9), width=12, anchor="w", bg=COLOR_CARD_WHITE).pack(side="left", padx=8)

            act_f = tk.Frame(row, bg=COLOR_CARD_WHITE)
            act_f.pack(side="right", padx=8)

            tk.Button(act_f, text="👁", font=("Segoe UI", 9), relief="flat", bg="#EFF6FF",
                      command=lambda s=sub: messagebox.showinfo("Submission Details", f"Submission: {s.get('file_name')}\nStudent: {s.get('student_name')}\nStatus: {s.get('status')}\nMarks: {s.get('marks', 'Not graded')}")).pack(side="left", padx=2)

    def _delete_mat(self, mat_id: str):
        if messagebox.askyesno("Confirm Delete", "Permanently delete this file and remove its record?"):
            self.fm.delete_material(mat_id, user_name=self.user.get("name"))
            self._build_ui()

    def _open_upload_dialog(self):
        top = tk.Toplevel(self)
        top.title("Upload Material")
        top.geometry("420x280")
        top.configure(bg=COLOR_CARD_WHITE)

        tk.Label(top, text="Upload Course Material", font=("Segoe UI", 12, "bold"),
                 fg=COLOR_PRIMARY_DARK, bg=COLOR_CARD_WHITE).pack(pady=12)

        file_info = {"path": "", "name": ""}
        lbl = tk.Label(top, text="No file selected", font=("Segoe UI", 9, "italic"), bg=COLOR_CARD_WHITE)
        lbl.pack(pady=6)

        def pick():
            p = filedialog.askopenfilename()
            if p:
                file_info["path"] = p
                file_info["name"] = p.split("/")[-1].split("\\")[-1]
                lbl.config(text=f"Selected: {file_info['name']}", font=("Segoe UI", 9, "bold"))

        PrimaryButton(top, text="Select Local File", command=pick).pack(pady=6)

        def upload():
            fname = file_info["name"] or "OS_Lecture_Slides.pdf"
            # Add to store
            self.fm.save_material_file(
                src_path=file_info["path"] or "/dev/null",
                course_id="C101",
                course_name="Operating Systems",
                title=fname,
                user_name=self.user.get("name", "Faculty"),
                user_id=self.user.get("id", "U101")
            ) if file_info["path"] else self.fm.materials_store.add({
                "id": f"M{len(self.fm.get_course_materials()) + 101}",
                "course_id": "C101",
                "course_name": "Operating Systems",
                "title": fname,
                "file_name": fname,
                "file_type": "PDF",
                "file_size": "2.4 MB",
                "uploaded_by": self.user.get("name"),
                "date": "Today"
            })
            messagebox.showinfo("Uploaded", f"File '{fname}' uploaded successfully!")
            top.destroy()
            self._build_ui()

        PrimaryButton(top, text="Confirm Upload", command=upload).pack(pady=10)
