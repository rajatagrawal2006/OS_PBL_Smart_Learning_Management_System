"""
OS Simulator - Process Management View.
Follows Panel 4.1 of UI Blueprint:
- Process table: PID, Process Name, Arrival Time, Burst Time, Priority, State, Action
- Colored state badges (Ready, Running, Waiting, Terminated)
- Actions: Create Process dialog, Terminate Process, View PCB details
"""
import tkinter as tk
from tkinter import ttk, messagebox
from typing import Dict, Any, Callable

try:
    from config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_DANGER
    )
    from os_simulator.process_manager import ProcessManager
    from gui.components import ContentCard, PrimaryButton, SecondaryButton, BadgeLabel
except ImportError:
    from SmartLMS.config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_DANGER
    )
    from SmartLMS.os_simulator.process_manager import ProcessManager
    from SmartLMS.gui.components import ContentCard, PrimaryButton, SecondaryButton, BadgeLabel

class ProcessPage(tk.Frame):
    def __init__(self, parent, current_user: Dict[str, Any], on_navigate: Callable[[str], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.user = current_user
        self.on_navigate = on_navigate
        self.pm = ProcessManager()
        self._build_ui()

    def _build_ui(self):
        for widget in self.winfo_children():
            widget.destroy()

        container = tk.Frame(self, bg=COLOR_BG_LIGHT, padx=24, pady=20)
        container.pack(fill="both", expand=True)

        # Header with actions
        header_frame = tk.Frame(container, bg=COLOR_BG_LIGHT)
        header_frame.pack(fill="x", pady=(0, 16))

        title_frame = tk.Frame(header_frame, bg=COLOR_BG_LIGHT)
        title_frame.pack(side="left")
        tk.Label(title_frame, text="Process Management", font=("Segoe UI", 16, "bold"),
                 fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(anchor="w")
        tk.Label(title_frame, text="Create and manage simulated processes and view PCB states",
                 font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_BG_LIGHT).pack(anchor="w")

        btn_frame = tk.Frame(header_frame, bg=COLOR_BG_LIGHT)
        btn_frame.pack(side="right")

        PrimaryButton(btn_frame, text="Create Process", command=self._open_create_dialog).pack(side="left", padx=4)
        PrimaryButton(btn_frame, text="Terminate Process", command=self._open_terminate_dialog, bg_color=COLOR_DANGER).pack(side="left", padx=4)

        # Main Table Card
        card = ContentCard(container)
        card.pack(fill="both", expand=True)

        # Table Header
        th = tk.Frame(card, bg="#F1F5F9", pady=8, highlightbackground=COLOR_BORDER, highlightthickness=1)
        th.pack(fill="x", pady=(0, 4))

        cols = [
            ("PID", 8),
            ("Process Name", 22),
            ("Arrival Time", 12),
            ("Burst Time", 12),
            ("Priority", 10),
            ("State", 12),
            ("Action", 18)
        ]
        for name, width in cols:
            tk.Label(th, text=name, font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg="#F1F5F9", width=width, anchor="w").pack(side="left", padx=6)

        processes = self.pm.get_all_processes()
        for proc in processes:
            row = tk.Frame(card, bg=COLOR_CARD_WHITE, pady=8, highlightbackground=COLOR_BORDER, highlightthickness=1)
            row.pack(fill="x", pady=2)

            tk.Label(row, text=proc.get("pid"), font=("Segoe UI", 9, "bold"), fg=COLOR_PRIMARY_BLUE, bg=COLOR_CARD_WHITE, width=8, anchor="w").pack(side="left", padx=6)
            tk.Label(row, text=proc.get("name"), font=("Segoe UI", 9), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE, width=22, anchor="w").pack(side="left", padx=6)
            tk.Label(row, text=str(proc.get("arrival_time", 0)), font=("Segoe UI", 9), bg=COLOR_CARD_WHITE, width=12, anchor="w").pack(side="left", padx=6)
            tk.Label(row, text=f"{proc.get('burst_time', 1)} ms", font=("Segoe UI", 9), bg=COLOR_CARD_WHITE, width=12, anchor="w").pack(side="left", padx=6)
            tk.Label(row, text=str(proc.get("priority", 1)), font=("Segoe UI", 9), bg=COLOR_CARD_WHITE, width=10, anchor="w").pack(side="left", padx=6)

            state_badge = BadgeLabel(row, text=proc.get("state", "Ready"), status_type=proc.get("state", "Ready"))
            state_badge.pack(side="left", padx=6)

            # Actions: PCB details, State Toggle, Delete
            act_frame = tk.Frame(row, bg=COLOR_CARD_WHITE)
            act_frame.pack(side="left", padx=6)

            tk.Button(act_frame, text="PCB", font=("Segoe UI", 8), bg="#E2E8F0", relief="flat", padx=6,
                      command=lambda p=proc: self._show_pcb(p)).pack(side="left", padx=2)
            tk.Button(act_frame, text="▶ Run", font=("Segoe UI", 8), bg="#DCFCE7", fg="#16A34A", relief="flat", padx=4,
                      command=lambda p=proc: self._set_state(p["pid"], "Running")).pack(side="left", padx=2)
            tk.Button(act_frame, text="⏸ Wait", font=("Segoe UI", 8), bg="#FEF3C7", fg="#D97706", relief="flat", padx=4,
                      command=lambda p=proc: self._set_state(p["pid"], "Waiting")).pack(side="left", padx=2)
            tk.Button(act_frame, text="🗑", font=("Segoe UI", 8), bg="#FEE2E2", fg="#EF4444", relief="flat", padx=4,
                      command=lambda p=proc: self._delete_proc(p["pid"])).pack(side="left", padx=2)

    def _set_state(self, pid: str, state: str):
        self.pm.change_process_state(pid, state)
        self._build_ui()

    def _delete_proc(self, pid: str):
        if messagebox.askyesno("Confirm Delete", f"Remove simulated process {pid}?"):
            self.pm.delete_process(pid)
            self._build_ui()

    def _show_pcb(self, proc: Dict[str, Any]):
        top = tk.Toplevel(self)
        top.title(f"Process Control Block (PCB) - {proc.get('pid')}")
        top.geometry("450x380")
        top.configure(bg=COLOR_CARD_WHITE)

        tk.Label(top, text=f"PCB Data Structure: {proc.get('pid')}", font=("Segoe UI", 12, "bold"),
                 fg=COLOR_PRIMARY_DARK, bg=COLOR_CARD_WHITE).pack(pady=12)

        pcb_fields = [
            ("Process Identifier (PID)", proc.get("pid")),
            ("Process Name", proc.get("name")),
            ("Current State", proc.get("state")),
            ("Task Type", proc.get("task_type", "Standard CPU Task")),
            ("Arrival Time", f"{proc.get('arrival_time')} ms"),
            ("CPU Burst Time", f"{proc.get('burst_time')} ms"),
            ("Remaining Burst Time", f"{proc.get('remaining_time')} ms"),
            ("Scheduling Priority", f"Level {proc.get('priority')} (1=Highest)"),
            ("Memory Requirement", f"{proc.get('memory_req', 100)} MB"),
            ("Creation Timestamp", proc.get("creation_time", "N/A"))
        ]

        frame = tk.Frame(top, bg="#F8FAFC", padx=16, pady=12, highlightbackground=COLOR_BORDER, highlightthickness=1)
        frame.pack(fill="both", expand=True, padx=20, pady=(0, 16))

        for k, v in pcb_fields:
            row = tk.Frame(frame, bg="#F8FAFC")
            row.pack(fill="x", pady=2)
            tk.Label(row, text=k, font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg="#F8FAFC", width=24, anchor="w").pack(side="left")
            tk.Label(row, text=str(v), font=("Segoe UI", 9), fg=COLOR_PRIMARY_BLUE if "PID" in k or "State" in k else COLOR_TEXT_MUTED, bg="#F8FAFC", anchor="w").pack(side="left")

    def _open_create_dialog(self):
        top = tk.Toplevel(self)
        top.title("Create Simulated Process")
        top.geometry("450x420")
        top.configure(bg=COLOR_CARD_WHITE)

        tk.Label(top, text="Create New Simulated Process", font=("Segoe UI", 12, "bold"),
                 fg=COLOR_PRIMARY_DARK, bg=COLOR_CARD_WHITE).pack(pady=12)

        fields = [
            ("Process Name", "e.g. Assignment Upload"),
            ("Task Type", "I/O Bound"),
            ("Arrival Time (ms)", "0"),
            ("Burst Time (ms)", "5"),
            ("Priority (1=High)", "2"),
            ("Memory Requirement (MB)", "100")
        ]
        entries = {}
        for label, val in fields:
            tk.Label(top, text=label, font=("Segoe UI", 9, "bold"), bg=COLOR_CARD_WHITE, anchor="w").pack(fill="x", padx=24, pady=(4, 1))
            e = tk.Entry(top, font=("Segoe UI", 9), relief="solid", bd=1)
            e.insert(0, val)
            e.pack(fill="x", padx=24, pady=(0, 4), ipady=2)
            entries[label] = e

        def confirm():
            try:
                name = entries["Process Name"].get()
                ttype = entries["Task Type"].get()
                at = int(entries["Arrival Time (ms)"].get())
                bt = int(entries["Burst Time (ms)"].get())
                pr = int(entries["Priority (1=High)"].get())
                mem = int(entries["Memory Requirement (MB)"].get())
            except ValueError:
                messagebox.showerror("Validation Error", "Arrival time, Burst time, Priority, and Memory must be valid integers.")
                return

            new_p = self.pm.create_process(name, ttype, at, bt, pr, mem)
            messagebox.showinfo("Success", f"Simulated Process {new_p['pid']} created in state READY.")
            top.destroy()
            self._build_ui()

        PrimaryButton(top, text="Create Process", command=confirm).pack(pady=14)

    def _open_terminate_dialog(self):
        procs = self.pm.get_active_processes()
        if not procs:
            messagebox.showinfo("Info", "No active processes available to terminate.")
            return

        top = tk.Toplevel(self)
        top.title("Terminate Process")
        top.geometry("380x220")
        top.configure(bg=COLOR_CARD_WHITE)

        tk.Label(top, text="Select Process to Terminate", font=("Segoe UI", 11, "bold"),
                 fg=COLOR_DANGER, bg=COLOR_CARD_WHITE).pack(pady=12)

        proc_var = tk.StringVar(value=procs[0]["pid"])
        combo = ttk.Combobox(top, textvariable=proc_var, values=[f"{p['pid']} - {p['name']}" for p in procs], state="readonly", width=30)
        combo.pack(pady=10)

        def terminate():
            selected = proc_var.get().split()[0]
            self.pm.terminate_process(selected, release_memory=True)
            messagebox.showinfo("Terminated", f"Process {selected} moved to TERMINATED state and memory released.")
            top.destroy()
            self._build_ui()

        PrimaryButton(top, text="Confirm Termination", command=terminate, bg_color=COLOR_DANGER).pack(pady=12)
