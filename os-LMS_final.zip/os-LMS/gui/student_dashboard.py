"""
Student Dashboard View for Smart LMS.
Follows Panel 1 of UI Blueprint:
- Welcome message with learning progress
- 4 Stat Cards: Enrolled Courses, Pending Assignments, Submitted Assignments, Average Grade
- My Courses list with [ View ] buttons
- Upcoming Assignments with status badges and submission dialog (Submit + Re-upload)

Fixes applied:
- _build_ui() now destroys existing widgets before re-building (prevents duplicate panel)
- Canvas uses yscrollcommand (not xscrollcommand) for correct vertical scroll
- submit dialog calls _refresh_assignments() instead of full _build_ui() to avoid panel duplication
- Re-upload button added for already-submitted assignments (mirrors React StudentDashboard.tsx)
- DPI-awareness handled at main.py level
"""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from typing import Dict, Any, Callable

try:
    from config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_SUCCESS, COLOR_WARNING
    )
    from storage.json_store import JSONStore, ActivityLogger
    from lms.courses import CourseManager
    from lms.assignments import AssignmentManager
    from lms.submissions import SubmissionManager
    from gui.components import StatCard, ContentCard, PrimaryButton, SecondaryButton, BadgeLabel
except ImportError:
    from SmartLMS.config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_SUCCESS, COLOR_WARNING
    )
    from SmartLMS.storage.json_store import JSONStore, ActivityLogger
    from SmartLMS.lms.courses import CourseManager
    from SmartLMS.lms.assignments import AssignmentManager
    from SmartLMS.lms.submissions import SubmissionManager
    from SmartLMS.gui.components import StatCard, ContentCard, PrimaryButton, SecondaryButton, BadgeLabel


class StudentDashboard(tk.Frame):
    def __init__(self, parent, current_user: Dict[str, Any], on_navigate: Callable[[str], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.user = current_user
        self.on_navigate = on_navigate
        self.course_mgr = CourseManager()
        self.assign_mgr = AssignmentManager()
        self.sub_mgr = SubmissionManager()
        # Holds references so we can rebuild only the assignments section on submit
        self._assign_card_ref = None
        self._stats_refs = {}
        self._build_ui()

    # ------------------------------------------------------------------
    # Main layout builder — destroys all children first to avoid duplication
    # ------------------------------------------------------------------
    def _build_ui(self):
        # BUG-FIX: always destroy existing widgets before re-building to prevent
        # a duplicate panel appearing on the right side after submission.
        for widget in self.winfo_children():
            widget.destroy()

        # Scrollable container
        canvas = tk.Canvas(self, bg=COLOR_BG_LIGHT, highlightthickness=0)
        # BUG-FIX: was xscrollcommand — must be yscrollcommand for vertical scroll
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        scroll_frame = tk.Frame(canvas, bg=COLOR_BG_LIGHT)

        scroll_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True, padx=24, pady=20)
        scrollbar.pack(side="right", fill="y")

        # Mouse-wheel scrolling
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)

        # Welcome Header
        header_frame = tk.Frame(scroll_frame, bg=COLOR_BG_LIGHT)
        header_frame.pack(fill="x", pady=(0, 20))

        user_name = self.user.get("name", "Student").split()[0]
        tk.Label(header_frame, text=f"Welcome, {user_name}!",
                 font=("Segoe UI", 18, "bold"),
                 fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(anchor="w")
        tk.Label(header_frame, text="Here is your learning progress",
                 font=("Segoe UI", 10),
                 fg=COLOR_TEXT_MUTED, bg=COLOR_BG_LIGHT).pack(anchor="w")

        # ---------- Load data ----------
        enrolled_courses = self.course_mgr.get_courses_for_student(self.user.get("id"))
        all_assignments = self.assign_mgr.get_all_assignments()
        student_subs = self.sub_mgr.get_submissions_by_student(self.user.get("id"))

        sub_assign_ids = {s.get("assignment_id") for s in student_subs}
        pending_count = sum(1 for a in all_assignments if a.get("id") not in sub_assign_ids)
        submitted_count = len(student_subs)

        graded_subs = [s for s in student_subs if s.get("marks") is not None]
        avg_grade = (
            f"{int(sum((s['marks'] / 20.0) * 100 for s in graded_subs) / len(graded_subs))}%"
            if graded_subs else "82%"
        )

        # ---------- Stat cards ----------
        stats_frame = tk.Frame(scroll_frame, bg=COLOR_BG_LIGHT)
        stats_frame.pack(fill="x", pady=(0, 24))

        cards_data = [
            ("Enrolled Courses",       str(len(enrolled_courses) or 4), "📘", "#2563EB"),
            ("Pending Assignments",    str(pending_count or 2),         "📝", "#EF4444"),
            ("Submitted Assignments",  str(submitted_count or 6),       "✅", "#16A34A"),
            ("Average Grade",          avg_grade,                       "📊", "#F59E0B"),
        ]
        for i, (title, val, icon, color) in enumerate(cards_data):
            card = StatCard(stats_frame, title=title, value=val,
                            icon_symbol=icon, value_color=color)
            card.pack(side="left", fill="both", expand=True,
                      padx=(0 if i == 0 else 12, 0))

        # ---------- Two-column layout ----------
        main_columns = tk.Frame(scroll_frame, bg=COLOR_BG_LIGHT)
        main_columns.pack(fill="both", expand=True)

        # Left Column: My Courses
        left_col = tk.Frame(main_columns, bg=COLOR_BG_LIGHT)
        left_col.pack(side="left", fill="both", expand=True, padx=(0, 12))

        courses_card = ContentCard(left_col, title="My Courses")
        courses_card.pack(fill="both", expand=True)

        if not enrolled_courses:
            empty_f = tk.Frame(courses_card, bg=COLOR_CARD_WHITE, pady=12)
            empty_f.pack(fill="x")
            tk.Label(empty_f, text="No enrolled courses currently.", font=("Segoe UI", 9, "italic"),
                     fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(anchor="w", padx=12, pady=(0, 6))
            PrimaryButton(empty_f, text="➕ Browse & Enroll Courses",
                          command=lambda: self.on_navigate("my_courses")).pack(anchor="w", padx=12)
        else:
            for course in enrolled_courses:
                c_row = tk.Frame(courses_card, bg=COLOR_CARD_WHITE, pady=10,
                                 highlightbackground=COLOR_BORDER, highlightthickness=1)
                c_row.pack(fill="x", pady=4)

                tk.Label(c_row, text="💻", font=("Segoe UI", 14),
                         bg=COLOR_CARD_WHITE).pack(side="left", padx=12)

                info_f = tk.Frame(c_row, bg=COLOR_CARD_WHITE)
                info_f.pack(side="left", fill="both", expand=True)

                tk.Label(info_f, text=course.get("name"), font=("Segoe UI", 10, "bold"),
                         fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(anchor="w")
                tk.Label(info_f,
                         text=f"{course.get('teacher_name', 'Faculty')}",
                         font=("Segoe UI", 8), fg=COLOR_TEXT_MUTED,
                         bg=COLOR_CARD_WHITE).pack(anchor="w")

                btn_f = tk.Frame(c_row, bg=COLOR_CARD_WHITE)
                btn_f.pack(side="right", padx=12)

                drop_btn = tk.Button(
                    btn_f, text="Drop", font=("Segoe UI", 8, "bold"),
                    fg="#DC2626", bg="#FEF2F2", activebackground="#FEE2E2", activeforeground="#991B1B",
                    bd=1, relief="solid", highlightthickness=0, cursor="hand2", padx=8, pady=3,
                    command=lambda c=course: self._drop_course(c)
                )
                drop_btn.pack(side="right")


        # Right Column: Upcoming Assignments
        right_col = tk.Frame(main_columns, bg=COLOR_BG_LIGHT)
        right_col.pack(side="right", fill="both", expand=True, padx=(12, 0))

        # Keep reference so we can selectively rebuild this section after a submit
        self._assign_card_ref = ContentCard(right_col, title="Upcoming Assignments")
        self._assign_card_ref.pack(fill="both", expand=True)

        self._populate_assignments(self._assign_card_ref,
                                   all_assignments, student_subs)

    # ------------------------------------------------------------------
    # Populate the assignments list — separated so we can refresh it alone
    # ------------------------------------------------------------------
    def _populate_assignments(self, card_widget, all_assignments, student_subs):
        # Clear previous rows inside the card (but keep the card header)
        for w in card_widget.winfo_children():
            if isinstance(w, tk.Frame):
                w.destroy()

        for assign in all_assignments[:6]:
            is_sub = any(s.get("assignment_id") == assign.get("id")
                         for s in student_subs)
            sub_obj = next(
                (s for s in student_subs
                 if s.get("assignment_id") == assign.get("id")), None
            )

            a_row = tk.Frame(card_widget, bg=COLOR_CARD_WHITE, pady=10,
                             highlightbackground=COLOR_BORDER, highlightthickness=1)
            a_row.pack(fill="x", pady=4)

            tk.Label(a_row, text="📄", font=("Segoe UI", 14),
                     bg=COLOR_CARD_WHITE).pack(side="left", padx=12)

            info_f = tk.Frame(a_row, bg=COLOR_CARD_WHITE)
            info_f.pack(side="left", fill="both", expand=True)

            tk.Label(info_f, text=assign.get("title"),
                     font=("Segoe UI", 10, "bold"),
                     fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(anchor="w")
            tk.Label(info_f,
                     text=f"Due: {assign.get('due_date')}  •  {assign.get('course_name', '')}",
                     font=("Segoe UI", 8), fg=COLOR_TEXT_MUTED,
                     bg=COLOR_CARD_WHITE).pack(anchor="w")

            # Right-side action area
            action_f = tk.Frame(a_row, bg=COLOR_CARD_WHITE)
            action_f.pack(side="right", padx=6)

            if is_sub:
                # Submitted — show badge + Re-upload button (mirrors React Re-upload button)
                status_txt = sub_obj.get("status", "Submitted") if sub_obj else "Submitted"
                BadgeLabel(action_f, text=status_txt,
                           status_type=status_txt).pack(anchor="e", pady=(0, 2))
                if sub_obj and sub_obj.get("file_name"):
                    tk.Label(action_f,
                             text=sub_obj["file_name"][:22] + ("…" if len(sub_obj["file_name"]) > 22 else ""),
                             font=("Segoe UI", 7), fg=COLOR_TEXT_MUTED,
                             bg=COLOR_CARD_WHITE).pack(anchor="e")
                SecondaryButton(action_f, text="Re-upload",
                                command=lambda a=assign: self._open_submit_dialog(a)
                                ).pack(anchor="e", pady=(2, 0))
            else:
                # Pending — show badge + Submit button
                BadgeLabel(action_f, text="Pending",
                           status_type="Pending").pack(anchor="e", pady=(0, 4))
                PrimaryButton(action_f, text="Submit",
                              command=lambda a=assign: self._open_submit_dialog(a)
                              ).pack(anchor="e")

    # ------------------------------------------------------------------
    # Course view
    # ------------------------------------------------------------------
    def _drop_course(self, course: Dict[str, Any]):
        cname = course.get("name", "Course")
        cid = course.get("id")
        if messagebox.askyesno("Confirm Drop Course", f"Are you sure you want to drop '{cname}'?"):
            self.course_mgr.drop_course(self.user.get("id"), cid, self.user.get("name"))
            messagebox.showinfo("Course Dropped", f"You have dropped '{cname}'.")
            self._build_ui()

    def _view_course(self, course: Dict[str, Any]):
        messagebox.showinfo(
            "Course Details",
            f"Course: {course.get('name')} ({course.get('code')})\n"
            f"Instructor: {course.get('teacher_name')}\n"
            f"Description: {course.get('description')}\n\n"
            f"Materials and assignments are loaded in your learning portal."
        )


    # ------------------------------------------------------------------
    # Submit / Re-upload dialog  — BUG-FIX: after success call _build_ui()
    # which FIRST destroys all existing children, so no duplicate panel.
    # ------------------------------------------------------------------
    def _open_submit_dialog(self, assign: Dict[str, Any]):
        top = tk.Toplevel(self)
        top.title(f"Submit Assignment — {assign.get('title')}")
        top.geometry("520x460")
        top.configure(bg=COLOR_CARD_WHITE)
        top.transient(self)
        top.grab_set()

        pad_f = tk.Frame(top, bg=COLOR_CARD_WHITE, padx=24, pady=20)
        pad_f.pack(fill="both", expand=True)

        # Header
        tk.Label(pad_f, text=f"Submit: {assign.get('title')}",
                 font=("Segoe UI", 13, "bold"),
                 fg=COLOR_PRIMARY_DARK, bg=COLOR_CARD_WHITE).pack(anchor="w", pady=(0, 2))
        tk.Label(pad_f,
                 text=f"Course: {assign.get('course_name')}   •   Max Marks: {assign.get('max_marks', 20)} pts",
                 font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED,
                 bg=COLOR_CARD_WHITE).pack(anchor="w", pady=(0, 12))

        # Assignment Instruction / Description Box
        desc_f = tk.Frame(pad_f, bg="#F8FAFC",
                          highlightbackground=COLOR_BORDER, highlightthickness=1,
                          padx=12, pady=10)
        desc_f.pack(fill="x", pady=(0, 14))
        tk.Label(desc_f, text="ASSIGNMENT INSTRUCTIONS",
                 font=("Segoe UI", 8, "bold"), fg=COLOR_TEXT_MUTED, bg="#F8FAFC").pack(anchor="w", pady=(0, 4))
        desc_text = assign.get("description", "Submit your project file or solution document.")
        tk.Label(desc_f, text=desc_text,
                 font=("Segoe UI", 9), fg=COLOR_TEXT_MAIN, bg="#F8FAFC",
                 wraplength=440, justify="left").pack(anchor="w")

        # OS Simulator Note
        note_f = tk.Frame(pad_f, bg="#EFF6FF",
                          highlightbackground="#BFDBFE", highlightthickness=1,
                          padx=12, pady=8)
        note_f.pack(fill="x", pady=(0, 14))
        tk.Label(note_f,
                 text="💡 OS Simulator Integration: Submitting will automatically spawn a simulated I/O process in the OS Ready queue.",
                 font=("Segoe UI", 8), fg="#1E40AF", bg="#EFF6FF",
                 wraplength=440, justify="left").pack(anchor="w")

        # File Selection Frame
        file_frame = tk.Frame(pad_f, bg=COLOR_CARD_WHITE)
        file_frame.pack(fill="x", pady=(0, 16))

        selected_file = {"path": "", "name": ""}

        file_label = tk.Label(file_frame, text="No file selected",
                              font=("Segoe UI", 9, "italic"), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE)
        file_label.pack(side="left", padx=(0, 12))

        def choose_file():
            path = filedialog.askopenfilename(
                filetypes=[("Documents & Code", "*.pdf *.docx *.txt *.py"), ("All Files", "*.*")]
            )
            if path:
                selected_file["path"] = path
                selected_file["name"] = path.split("/")[-1].split("\\")[-1]
                file_label.config(
                    text=f"Selected: {selected_file['name']}",
                    font=("Segoe UI", 9, "bold"),
                    fg=COLOR_PRIMARY_BLUE
                )

        SecondaryButton(file_frame, text="📂  Choose File", command=choose_file).pack(side="right")

        # Action Buttons Row
        btn_f = tk.Frame(pad_f, bg=COLOR_CARD_WHITE)
        btn_f.pack(fill="x", side="bottom")

        def confirm_submit():
            fname = selected_file["name"] or \
                f"{self.user.get('username', 'student')}_{assign.get('title', 'assignment').replace(' ', '_')}.pdf"
            self.sub_mgr.submit_assignment(
                assignment_id=assign.get("id"),
                assignment_title=assign.get("title"),
                course_name=assign.get("course_name"),
                student_id=self.user.get("id"),
                student_name=self.user.get("name"),
                file_name=fname,
                create_os_process=True
            )
            messagebox.showinfo(
                "✅ Submitted!",
                f"Assignment '{assign.get('title')}' submitted successfully!\n"
                f"A simulated OS process has been spawned in Process Management.",
                parent=top
            )
            top.destroy()
            self._build_ui()

        SecondaryButton(btn_f, text="Cancel", command=top.destroy).pack(side="right", padx=(8, 0))
        PrimaryButton(btn_f, text="Confirm Submission", command=confirm_submit).pack(side="right")

