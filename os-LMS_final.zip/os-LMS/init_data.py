"""
Database initializer for Smart LMS.
Generates all demo JSON files matching the blueprint and prompt requirements.
"""
import sys
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from auth.authentication import Authenticator
from storage.json_store import JSONStore

def initialize_demo_database():
    # 1. Users
    users_store = JSONStore("users.json")
    demo_users = [
        {
            "id": "U101",
            "name": "System Administrator",
            "username": "admin",
            "password_hash": Authenticator.hash_password("admin123", salt="adminsalt1234567"),
            "role": "admin",
            "email": "admin@smartlms.edu",
            "is_active": True,
            "created_at": "01 Oct 2024"
        },
        {
            "id": "U102",
            "name": "Dr. Sharma",
            "username": "drsharma",
            "password_hash": Authenticator.hash_password("teacher123", salt="teachersalt12345"),
            "role": "teacher",
            "email": "dr.sharma@smartlms.edu",
            "is_active": True,
            "created_at": "02 Oct 2024"
        },
        {
            "id": "U103",
            "name": "Prof. Mehta",
            "username": "profmehta",
            "password_hash": Authenticator.hash_password("teacher123", salt="mehtasalt1234567"),
            "role": "teacher",
            "email": "mehta@smartlms.edu",
            "is_active": True,
            "created_at": "02 Oct 2024"
        },
        {
            "id": "U108",
            "name": "Prof. Singh",
            "username": "profsingh",
            "password_hash": Authenticator.hash_password("teacher123", salt="teachersalt12345"),
            "role": "teacher",
            "email": "prof.singh@smartlms.edu",
            "is_active": True,
            "created_at": "02 Oct 2024"
        },
        {
            "id": "U104",
            "name": "Rohan Verma",
            "username": "rohan",
            "password_hash": Authenticator.hash_password("student123", salt="studentsalt12345"),
            "role": "student",
            "email": "rohan@smartlms.edu",
            "is_active": True,
            "created_at": "03 Oct 2024"
        },
        {
            "id": "U105",
            "name": "Neha Patel",
            "username": "neha",
            "password_hash": Authenticator.hash_password("student123", salt="nehasalt12345678"),
            "role": "student",
            "email": "neha@smartlms.edu",
            "is_active": True,
            "created_at": "03 Oct 2024"
        },
        {
            "id": "U106",
            "name": "Priya Sharma",
            "username": "priya",
            "password_hash": Authenticator.hash_password("student123", salt="priyasalt1234567"),
            "role": "student",
            "email": "priya@smartlms.edu",
            "is_active": True,
            "created_at": "03 Oct 2024"
        },
        {
            "id": "U107",
            "name": "Aman Gupta",
            "username": "aman",
            "password_hash": Authenticator.hash_password("student123", salt="amansalt12345678"),
            "role": "student",
            "email": "aman@smartlms.edu",
            "is_active": True,
            "created_at": "03 Oct 2024"
        }
    ]
    users_store.save_all(demo_users)

    # 2. Courses
    courses_store = JSONStore("courses.json")
    demo_courses = [
        {
            "id": "C101",
            "code": "CS301",
            "name": "Operating Systems",
            "teacher_id": "U102",
            "teacher_name": "Dr. Sharma",
            "description": "Core concepts of process scheduling, synchronization, virtual memory, and file systems.",
            "enrolled_count": 30,
            "is_active": True,
            "created_at": "01 Oct 2024"
        },
        {
            "id": "C102",
            "code": "CS302",
            "name": "Computer Networks",
            "teacher_id": "U103",
            "teacher_name": "Prof. Mehta",
            "description": "OSI model, TCP/IP protocol suite, socket programming and network routing algorithms.",
            "enrolled_count": 25,
            "is_active": True,
            "created_at": "01 Oct 2024"
        },
        {
            "id": "C103",
            "code": "CS303",
            "name": "Database Management",
            "teacher_id": "U102",
            "teacher_name": "Dr. Sharma",
            "description": "Relational schemas, SQL queries, normalization, transactions, and indexing.",
            "enrolled_count": 28,
            "is_active": True,
            "created_at": "01 Oct 2024"
        },
        {
            "id": "C104",
            "code": "CS304",
            "name": "Artificial Intelligence",
            "teacher_id": "U103",
            "teacher_name": "Prof. Mehta",
            "description": "Heuristic search, logic programming, neural architectures, and intelligent agents.",
            "enrolled_count": 22,
            "is_active": True,
            "created_at": "01 Oct 2024"
        }
    ]
    courses_store.save_all(demo_courses)

    # 3. Enrollments
    enrollments_store = JSONStore("enrollments.json")
    demo_enrollments = [
        {"id": "E101", "student_id": "U104", "course_id": "C101", "enrolled_at": "03 Oct 2024"},
        {"id": "E102", "student_id": "U104", "course_id": "C102", "enrolled_at": "03 Oct 2024"},
        {"id": "E103", "student_id": "U104", "course_id": "C103", "enrolled_at": "03 Oct 2024"},
        {"id": "E104", "student_id": "U104", "course_id": "C104", "enrolled_at": "03 Oct 2024"},
        {"id": "E105", "student_id": "U105", "course_id": "C101", "enrolled_at": "03 Oct 2024"},
        {"id": "E106", "student_id": "U106", "course_id": "C103", "enrolled_at": "03 Oct 2024"},
        {"id": "E107", "student_id": "U107", "course_id": "C102", "enrolled_at": "03 Oct 2024"},
    ]
    enrollments_store.save_all(demo_enrollments)

    # 4. Materials
    materials_store = JSONStore("materials.json")
    demo_materials = [
        {
            "id": "M101",
            "course_id": "C101",
            "course_name": "Operating Systems",
            "title": "Process_Management.pdf",
            "file_name": "Process_Management.pdf",
            "file_type": "PDF",
            "file_size": "2.1 MB",
            "uploaded_by": "Dr. Sharma",
            "uploaded_by_id": "U102",
            "date": "9 Oct 2024",
            "description": "Complete lecture slides on PCB, context switching, and ready queue operations."
        },
        {
            "id": "M102",
            "course_id": "C101",
            "course_name": "Operating Systems",
            "title": "OS_Notes.docx",
            "file_name": "OS_Notes.docx",
            "file_type": "DOCX",
            "file_size": "1.5 MB",
            "uploaded_by": "Dr. Sharma",
            "uploaded_by_id": "U102",
            "date": "8 Oct 2024",
            "description": "Summary notes on CPU scheduling algorithms: FCFS, SJF, and Round Robin."
        },
        {
            "id": "M103",
            "course_id": "C102",
            "course_name": "Computer Networks",
            "title": "CN_Syllabus.pdf",
            "file_name": "CN_Syllabus.pdf",
            "file_type": "PDF",
            "file_size": "1.2 MB",
            "uploaded_by": "Prof. Mehta",
            "uploaded_by_id": "U103",
            "date": "6 Oct 2024",
            "description": "Semester curriculum and lab exercises guide."
        },
        {
            "id": "M104",
            "course_id": "C103",
            "course_name": "Database Management",
            "title": "DBMS_Questions.pdf",
            "file_name": "DBMS_Questions.pdf",
            "file_type": "PDF",
            "file_size": "3.0 MB",
            "uploaded_by": "Dr. Sharma",
            "uploaded_by_id": "U102",
            "date": "5 Oct 2024",
            "description": "Practice set for SQL queries and B-tree indexing."
        }
    ]
    materials_store.save_all(demo_materials)

    # 5. Assignments
    assignments_store = JSONStore("assignments.json")
    demo_assignments = [
        {
            "id": "A101",
            "course_id": "C101",
            "course_name": "Operating Systems",
            "title": "OS Assignment 1",
            "description": "Implement FCFS and SJF scheduling algorithms and calculate average waiting time.",
            "due_date": "10 Oct 2024",
            "max_marks": 20,
            "created_by": "U102"
        },
        {
            "id": "A102",
            "course_id": "C102",
            "course_name": "Computer Networks",
            "title": "CN Quiz",
            "description": "Subnetting and IP addressing calculations assignment.",
            "due_date": "12 Oct 2024",
            "max_marks": 25,
            "created_by": "U103"
        },
        {
            "id": "A103",
            "course_id": "C103",
            "course_name": "Database Management",
            "title": "DBMS Project Report",
            "description": "Submit initial schema design and normalization up to 3NF.",
            "due_date": "15 Oct 2024",
            "max_marks": 50,
            "created_by": "U102"
        },
        {
            "id": "A104",
            "course_id": "C104",
            "course_name": "Artificial Intelligence",
            "title": "AI Search Algorithms",
            "description": "A* search implementation and comparison with BFS/DFS.",
            "due_date": "18 Oct 2024",
            "max_marks": 30,
            "created_by": "U103"
        }
    ]
    assignments_store.save_all(demo_assignments)

    # 6. Submissions
    submissions_store = JSONStore("submissions.json")
    demo_submissions = [
        {
            "id": "S101",
            "assignment_id": "A101",
            "assignment_title": "OS Assignment 1",
            "course_name": "Operating Systems",
            "student_id": "U104",
            "student_name": "Rohan Verma",
            "file_name": "Rohan_OS_Assign1.pdf",
            "file_path": "uploads/submissions/Rohan_OS_Assign1.pdf",
            "file_size": "1.4 MB",
            "submission_date": "09 Oct 2024, 04:20 PM",
            "status": "Graded",
            "marks": 18,
            "feedback": "Excellent Gantt chart trace and correct average waiting time calculation."
        },
        {
            "id": "S102",
            "assignment_id": "A101",
            "assignment_title": "OS Assignment 1",
            "course_name": "Operating Systems",
            "student_id": "U105",
            "student_name": "Neha Patel",
            "file_name": "Neha_OS_Assign1.pdf",
            "file_path": "uploads/submissions/Neha_OS_Assign1.pdf",
            "file_size": "1.1 MB",
            "submission_date": "09 Oct 2024, 05:15 PM",
            "status": "Submitted",
            "marks": None,
            "feedback": ""
        },
        {
            "id": "S103",
            "assignment_id": "A102",
            "assignment_title": "CN Quiz",
            "course_name": "Computer Networks",
            "student_id": "U107",
            "student_name": "Aman Gupta",
            "file_name": "Aman_CN_Quiz.pdf",
            "file_path": "uploads/submissions/Aman_CN_Quiz.pdf",
            "file_size": "0.9 MB",
            "submission_date": "08 Oct 2024, 11:30 AM",
            "status": "Pending",
            "marks": None,
            "feedback": ""
        },
        {
            "id": "S104",
            "assignment_id": "A103",
            "assignment_title": "DBMS Project Report",
            "course_name": "Database Management",
            "student_id": "U106",
            "student_name": "Priya Sharma",
            "file_name": "Priya_DBMS_Report.pdf",
            "file_path": "uploads/submissions/Priya_DBMS_Report.pdf",
            "file_size": "2.4 MB",
            "submission_date": "09 Oct 2024, 02:40 PM",
            "status": "Submitted",
            "marks": None,
            "feedback": ""
        }
    ]
    submissions_store.save_all(demo_submissions)

    # 7. Processes (OS Simulator)
    processes_store = JSONStore("processes.json")
    demo_processes = [
        {
            "pid": "P101",
            "name": "Assignment Upload",
            "task_type": "I/O Bound",
            "arrival_time": 0,
            "burst_time": 5,
            "remaining_time": 5,
            "priority": 2,
            "memory_req": 100,
            "state": "Ready",
            "creation_time": "09 Oct 2024, 04:20 PM"
        },
        {
            "pid": "P102",
            "name": "File Processing",
            "task_type": "CPU Bound",
            "arrival_time": 1,
            "burst_time": 3,
            "remaining_time": 3,
            "priority": 1,
            "memory_req": 250,
            "state": "Running",
            "creation_time": "09 Oct 2024, 04:21 PM"
        },
        {
            "pid": "P103",
            "name": "Report Generation",
            "task_type": "I/O Bound",
            "arrival_time": 2,
            "burst_time": 4,
            "remaining_time": 4,
            "priority": 3,
            "memory_req": 150,
            "state": "Waiting",
            "creation_time": "09 Oct 2024, 04:22 PM"
        },
        {
            "pid": "P104",
            "name": "Grade Calculation",
            "task_type": "CPU Bound",
            "arrival_time": 3,
            "burst_time": 6,
            "remaining_time": 6,
            "priority": 2,
            "memory_req": 80,
            "state": "Ready",
            "creation_time": "09 Oct 2024, 04:23 PM"
        }
    ]
    processes_store.save_all(demo_processes)

    # 8. Memory pool (1000 MB)
    memory_store = JSONStore("memory.json")
    demo_memory = [
        {"start": 0, "size": 100, "status": "Allocated", "process": "P1"},
        {"start": 100, "size": 250, "status": "Allocated", "process": "P2"},
        {"start": 350, "size": 150, "status": "Allocated", "process": "P3"},
        {"start": 500, "size": 500, "status": "Free", "process": "-"}
    ]
    memory_store.save_all(demo_memory)

    # 9. Activity Log
    activity_store = JSONStore("activity_log.json")
    demo_activity = [
        {
            "id": "act_1",
            "timestamp": "10 Oct 2024, 10:30 AM",
            "user": "Rohan Verma",
            "activity": "Rohan submitted OS Assignment 1",
            "details": "Uploaded Rohan_OS_Assign1.pdf (1.4 MB)"
        },
        {
            "id": "act_2",
            "timestamp": "10 Oct 2024, 09:15 AM",
            "user": "Admin",
            "activity": "New user (Neha) registered",
            "details": "Role: Student, ID: U105"
        },
        {
            "id": "act_3",
            "timestamp": "9 Oct 2024, 04:20 PM",
            "user": "Dr. Sharma",
            "activity": "Dr. Sharma uploaded a new material",
            "details": "Process_Management.pdf for Operating Systems"
        },
        {
            "id": "act_4",
            "timestamp": "9 Oct 2024, 04:20 PM",
            "user": "OS Simulator",
            "activity": "Process P105 created (Assignment Submission)",
            "details": "Burst Time: 5, Priority: 2, State: Ready"
        }
    ]
    activity_store.save_all(demo_activity)
    print("Demo database successfully initialized!")

if __name__ == "__main__":
    initialize_demo_database()
