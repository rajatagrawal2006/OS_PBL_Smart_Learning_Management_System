import { GanttSegment, SchedulingResult, MemoryBlock } from '../types';

export interface ProcessInput {
  pid: string;
  arrivalTime: number;
  burstTime: number;
  priority: number;
}

// 1. FCFS Scheduling
export function calculateFCFS(processes: ProcessInput[]): SchedulingResult {
  if (processes.length === 0) {
    return { algorithm: 'FCFS', timeline: [], executionOrder: '', avgWaitingTime: 0, avgTurnaroundTime: 0, details: [] };
  }

  const sorted = [...processes].sort((a, b) => a.arrivalTime - b.arrivalTime);
  let currentTime = 0;
  const timeline: GanttSegment[] = [];
  const details = [];

  for (const p of sorted) {
    if (currentTime < p.arrivalTime) {
      timeline.push({ pid: 'IDLE', start: currentTime, end: p.arrivalTime, isIdle: true });
      currentTime = p.arrivalTime;
    }

    const start = currentTime;
    const end = start + p.burstTime;
    currentTime = end;

    timeline.push({ pid: p.pid, start, end, isIdle: false });

    const completionTime = end;
    const turnaroundTime = completionTime - p.arrivalTime;
    const waitingTime = turnaroundTime - p.burstTime;

    details.push({
      pid: p.pid,
      arrivalTime: p.arrivalTime,
      burstTime: p.burstTime,
      completionTime,
      turnaroundTime,
      waitingTime
    });
  }

  const avgWaitingTime = Number((details.reduce((acc, d) => acc + d.waitingTime, 0) / details.length).toFixed(2));
  const avgTurnaroundTime = Number((details.reduce((acc, d) => acc + d.turnaroundTime, 0) / details.length).toFixed(2));
  const executionOrder = timeline.filter(t => !t.isIdle).map(t => t.pid).join(' → ');

  return {
    algorithm: 'FCFS (First Come First Served)',
    timeline,
    executionOrder,
    avgWaitingTime,
    avgTurnaroundTime,
    details
  };
}

// 2. SJF (Non-preemptive)
export function calculateSJF(processes: ProcessInput[]): SchedulingResult {
  if (processes.length === 0) {
    return { algorithm: 'SJF', timeline: [], executionOrder: '', avgWaitingTime: 0, avgTurnaroundTime: 0, details: [] };
  }

  const pool = processes.map(p => ({ ...p }));
  const completed: any[] = [];
  const timeline: GanttSegment[] = [];
  let currentTime = 0;
  const n = pool.length;

  while (completed.length < n) {
    const available = pool.filter(p => p.arrivalTime <= currentTime && !completed.some(c => c.pid === p.pid));

    if (available.length === 0) {
      const remaining = pool.filter(p => !completed.some(c => c.pid === p.pid));
      const nextArrival = Math.min(...remaining.map(p => p.arrivalTime));
      timeline.push({ pid: 'IDLE', start: currentTime, end: nextArrival, isIdle: true });
      currentTime = nextArrival;
      continue;
    }

    // Smallest burst time, tie break with arrival time
    available.sort((a, b) => a.burstTime - b.burstTime || a.arrivalTime - b.arrivalTime);
    const chosen = available[0];

    const start = currentTime;
    const end = start + chosen.burstTime;
    currentTime = end;

    timeline.push({ pid: chosen.pid, start, end, isIdle: false });

    const completionTime = end;
    const turnaroundTime = completionTime - chosen.arrivalTime;
    const waitingTime = turnaroundTime - chosen.burstTime;

    completed.push({
      pid: chosen.pid,
      arrivalTime: chosen.arrivalTime,
      burstTime: chosen.burstTime,
      completionTime,
      turnaroundTime,
      waitingTime
    });
  }

  const avgWaitingTime = Number((completed.reduce((acc, d) => acc + d.waitingTime, 0) / completed.length).toFixed(2));
  const avgTurnaroundTime = Number((completed.reduce((acc, d) => acc + d.turnaroundTime, 0) / completed.length).toFixed(2));
  const executionOrder = timeline.filter(t => !t.isIdle).map(t => t.pid).join(' → ');

  return {
    algorithm: 'SJF (Shortest Job First - Non Preemptive)',
    timeline,
    executionOrder,
    avgWaitingTime,
    avgTurnaroundTime,
    details: completed
  };
}

// 2b. SJF (Preemptive) / Shortest Remaining Time First (SRTF)
export function calculateSJFPreemptive(processes: ProcessInput[]): SchedulingResult {
  if (processes.length === 0) {
    return { algorithm: 'SJF Preemptive (SRTF)', timeline: [], executionOrder: '', avgWaitingTime: 0, avgTurnaroundTime: 0, details: [] };
  }

  const n = processes.length;
  const remTime: Record<string, number> = {};
  const procMap: Record<string, ProcessInput> = {};
  processes.forEach(p => {
    remTime[p.pid] = p.burstTime;
    procMap[p.pid] = p;
  });

  let completedCount = 0;
  let currentTime = 0;
  const completionTimeMap: Record<string, number> = {};
  const rawTimeline: { pid: string; time: number }[] = [];

  const maxSimTime = 10000;
  let loopCount = 0;

  while (completedCount < n && loopCount < maxSimTime) {
    loopCount++;
    // Find arrived processes with remaining time > 0
    const available = processes.filter(p => p.arrivalTime <= currentTime && remTime[p.pid] > 0);

    if (available.length === 0) {
      const future = processes.filter(p => remTime[p.pid] > 0);
      if (future.length === 0) break;
      const nextArrival = Math.min(...future.map(p => p.arrivalTime));
      for (let t = currentTime; t < nextArrival; t++) {
        rawTimeline.push({ pid: 'IDLE', time: t });
      }
      currentTime = nextArrival;
      continue;
    }

    // Pick process with shortest remaining time; tie-break on arrival time
    available.sort((a, b) => remTime[a.pid] - remTime[b.pid] || a.arrivalTime - b.arrivalTime);
    const chosen = available[0];

    rawTimeline.push({ pid: chosen.pid, time: currentTime });
    remTime[chosen.pid] -= 1;
    currentTime += 1;

    if (remTime[chosen.pid] === 0) {
      completedCount++;
      completionTimeMap[chosen.pid] = currentTime;
    }
  }

  // Compress raw 1ms slices into Gantt segments
  const timeline: GanttSegment[] = [];
  if (rawTimeline.length > 0) {
    let currPid = rawTimeline[0].pid;
    let segStart = rawTimeline[0].time;

    for (let i = 1; i < rawTimeline.length; i++) {
      if (rawTimeline[i].pid !== currPid) {
        timeline.push({
          pid: currPid,
          start: segStart,
          end: rawTimeline[i].time,
          isIdle: currPid === 'IDLE'
        });
        currPid = rawTimeline[i].pid;
        segStart = rawTimeline[i].time;
      }
    }
    timeline.push({
      pid: currPid,
      start: segStart,
      end: currentTime,
      isIdle: currPid === 'IDLE'
    });
  }

  const details = processes.map(p => {
    const ct = completionTimeMap[p.pid] || 0;
    const tat = ct - p.arrivalTime;
    const wt = tat - p.burstTime;
    return {
      pid: p.pid,
      arrivalTime: p.arrivalTime,
      burstTime: p.burstTime,
      completionTime: ct,
      turnaroundTime: tat,
      waitingTime: wt
    };
  });

  const avgWaitingTime = Number((details.reduce((acc, d) => acc + d.waitingTime, 0) / details.length).toFixed(2));
  const avgTurnaroundTime = Number((details.reduce((acc, d) => acc + d.turnaroundTime, 0) / details.length).toFixed(2));
  const executionOrder = timeline.filter(t => !t.isIdle).map(t => t.pid).join(' → ');

  return {
    algorithm: 'SJF Preemptive (Shortest Remaining Time First)',
    timeline,
    executionOrder,
    avgWaitingTime,
    avgTurnaroundTime,
    details
  };
}

// 3. Priority Scheduling (Non-preemptive, Smaller number = Higher priority)
export function calculatePriority(processes: ProcessInput[]): SchedulingResult {
  if (processes.length === 0) {
    return { algorithm: 'Priority', timeline: [], executionOrder: '', avgWaitingTime: 0, avgTurnaroundTime: 0, details: [] };
  }

  const pool = processes.map(p => ({ ...p }));
  const completed: any[] = [];
  const timeline: GanttSegment[] = [];
  let currentTime = 0;
  const n = pool.length;

  while (completed.length < n) {
    const available = pool.filter(p => p.arrivalTime <= currentTime && !completed.some(c => c.pid === p.pid));

    if (available.length === 0) {
      const remaining = pool.filter(p => !completed.some(c => c.pid === p.pid));
      const nextArrival = Math.min(...remaining.map(p => p.arrivalTime));
      timeline.push({ pid: 'IDLE', start: currentTime, end: nextArrival, isIdle: true });
      currentTime = nextArrival;
      continue;
    }

    // Smallest priority number = Highest priority
    available.sort((a, b) => a.priority - b.priority || a.arrivalTime - b.arrivalTime);
    const chosen = available[0];

    const start = currentTime;
    const end = start + chosen.burstTime;
    currentTime = end;

    timeline.push({ pid: chosen.pid, start, end, isIdle: false });

    const completionTime = end;
    const turnaroundTime = completionTime - chosen.arrivalTime;
    const waitingTime = turnaroundTime - chosen.burstTime;

    completed.push({
      pid: chosen.pid,
      arrivalTime: chosen.arrivalTime,
      burstTime: chosen.burstTime,
      completionTime,
      turnaroundTime,
      waitingTime
    });
  }

  const avgWaitingTime = Number((completed.reduce((acc, d) => acc + d.waitingTime, 0) / completed.length).toFixed(2));
  const avgTurnaroundTime = Number((completed.reduce((acc, d) => acc + d.turnaroundTime, 0) / completed.length).toFixed(2));
  const executionOrder = timeline.filter(t => !t.isIdle).map(t => t.pid).join(' → ');

  return {
    algorithm: 'Priority Scheduling',
    timeline,
    executionOrder,
    avgWaitingTime,
    avgTurnaroundTime,
    details: completed
  };
}

// 4. Round Robin
export function calculateRoundRobin(processes: ProcessInput[], quantum: number = 2): SchedulingResult {
  if (processes.length === 0 || quantum <= 0) {
    return { algorithm: 'Round Robin', timeline: [], executionOrder: '', avgWaitingTime: 0, avgTurnaroundTime: 0, details: [] };
  }

  const sorted = [...processes].sort((a, b) => a.arrivalTime - b.arrivalTime);
  const remainingBt: Record<string, number> = {};
  const completionTimeMap: Record<string, number> = {};

  sorted.forEach(p => { remainingBt[p.pid] = p.burstTime; });

  let currentTime = 0;
  const readyQueue: string[] = [];
  const visited = new Set<string>();
  const timeline: GanttSegment[] = [];

  const minAt = sorted[0].arrivalTime;
  if (minAt > 0) {
    timeline.push({ pid: 'IDLE', start: 0, end: minAt, isIdle: true });
    currentTime = minAt;
  }

  sorted.forEach(p => {
    if (p.arrivalTime <= currentTime && !visited.has(p.pid)) {
      readyQueue.push(p.pid);
      visited.add(p.pid);
    }
  });

  while (readyQueue.length > 0 || visited.size < sorted.length || Object.values(remainingBt).some(v => v > 0)) {
    if (readyQueue.length === 0) {
      const unvisited = sorted.filter(p => !visited.has(p.pid));
      if (unvisited.length > 0) {
        const nextP = unvisited[0];
        timeline.push({ pid: 'IDLE', start: currentTime, end: nextP.arrivalTime, isIdle: true });
        currentTime = nextP.arrivalTime;
        readyQueue.push(nextP.pid);
        visited.add(nextP.pid);
      } else {
        break;
      }
    }

    const currentPid = readyQueue.shift()!;
    const execTime = Math.min(quantum, remainingBt[currentPid]);
    const start = currentTime;
    const end = start + execTime;
    currentTime = end;
    remainingBt[currentPid] -= execTime;

    timeline.push({ pid: currentPid, start, end, isIdle: false });

    // Check newly arrived processes during this quantum
    sorted.forEach(p => {
      if (!visited.has(p.pid) && p.arrivalTime <= currentTime) {
        readyQueue.push(p.pid);
        visited.add(p.pid);
      }
    });

    if (remainingBt[currentPid] > 0) {
      readyQueue.push(currentPid);
    } else {
      completionTimeMap[currentPid] = currentTime;
    }
  }

  const details = sorted.map(p => {
    const ct = completionTimeMap[p.pid] || 0;
    const tat = ct - p.arrivalTime;
    const wt = tat - p.burstTime;
    return {
      pid: p.pid,
      arrivalTime: p.arrivalTime,
      burstTime: p.burstTime,
      completionTime: ct,
      turnaroundTime: tat,
      waitingTime: wt
    };
  });

  const avgWaitingTime = Number((details.reduce((acc, d) => acc + d.waitingTime, 0) / details.length).toFixed(2));
  const avgTurnaroundTime = Number((details.reduce((acc, d) => acc + d.turnaroundTime, 0) / details.length).toFixed(2));
  const executionOrder = timeline.filter(t => !t.isIdle).map(t => t.pid).join(' → ');

  return {
    algorithm: `Round Robin (Quantum = ${quantum})`,
    timeline,
    executionOrder,
    avgWaitingTime,
    avgTurnaroundTime,
    details
  };
}

// 5. Memory Allocation Algorithms
export function allocateMemory(
  blocks: MemoryBlock[],
  processId: string,
  size: number,
  algorithm: 'First Fit' | 'Best Fit'
): { success: boolean; message: string; updatedBlocks: MemoryBlock[] } {
  if (size <= 0) {
    return { success: false, message: 'Requested size must be greater than zero.', updatedBlocks: blocks };
  }

  // Check for duplicate allocation
  if (blocks.some(b => b.status === 'Allocated' && b.process.toUpperCase() === processId.toUpperCase())) {
    return { success: false, message: `Process ${processId} already has an active memory block.`, updatedBlocks: blocks };
  }

  const freeIndices = blocks
    .map((b, idx) => ({ ...b, idx }))
    .filter(b => b.status === 'Free' && b.size >= size);

  if (freeIndices.length === 0) {
    return { success: false, message: `Memory allocation failed: No suitable free block available for ${size} MB.`, updatedBlocks: blocks };
  }

  let targetIdx = -1;
  if (algorithm === 'First Fit') {
    targetIdx = freeIndices[0].idx;
  } else {
    // Best fit: smallest free block >= size
    freeIndices.sort((a, b) => a.size - b.size);
    targetIdx = freeIndices[0].idx;
  }

  const targetBlock = blocks[targetIdx];
  const remainingSize = targetBlock.size - size;

  const newBlocks = [...blocks];
  const allocatedBlock: MemoryBlock = {
    start: targetBlock.start,
    size,
    status: 'Allocated',
    process: processId
  };

  if (remainingSize > 0) {
    const freeBlock: MemoryBlock = {
      start: targetBlock.start + size,
      size: remainingSize,
      status: 'Free',
      process: '-'
    };
    newBlocks.splice(targetIdx, 1, allocatedBlock, freeBlock);
  } else {
    newBlocks[targetIdx] = allocatedBlock;
  }

  return {
    success: true,
    message: `Allocated ${size} MB to process ${processId} at starting address ${allocatedBlock.start} MB.`,
    updatedBlocks: newBlocks
  };
}

export function releaseMemory(
  blocks: MemoryBlock[],
  processId: string
): { success: boolean; message: string; updatedBlocks: MemoryBlock[] } {
  const targetIdx = blocks.findIndex(b => b.status === 'Allocated' && b.process.toUpperCase() === processId.toUpperCase());
  if (targetIdx === -1) {
    return { success: false, message: `No allocated memory block found for process ${processId}.`, updatedBlocks: blocks };
  }

  const releasedSize = blocks[targetIdx].size;
  const newBlocks = blocks.map((b, idx) => {
    if (idx === targetIdx) {
      return { ...b, status: 'Free' as const, process: '-' };
    }
    return b;
  });

  // Coalesce adjacent free blocks
  const coalesced: MemoryBlock[] = [];
  for (const b of newBlocks) {
    if (coalesced.length === 0) {
      coalesced.push({ ...b });
    } else {
      const last = coalesced[coalesced.length - 1];
      if (last.status === 'Free' && b.status === 'Free') {
        last.size += b.size;
      } else {
        coalesced.push({ ...b });
      }
    }
  }

  return {
    success: true,
    message: `Released ${releasedSize} MB from process ${processId}. Free blocks merged.`,
    updatedBlocks: coalesced
  };
}

// 6. Deadlock Cycle Detection & Banker's Algorithm
export function detectDeadlockInGraph(
  processes: string[],
  resources: string[],
  allocation: Record<string, Record<string, number>>,
  request: Record<string, Record<string, number>>,
  available?: Record<string, number>
): {
  hasDeadlock: boolean;
  cycleString: string;
  cycleNodes: string[];
  deadlockedProcesses: string[];
  isSafe: boolean;
  safeSequence: string[];
  simulationSteps: string[];
} {
  const graph: Record<string, string[]> = {};
  processes.forEach(p => { graph[p] = []; });
  resources.forEach(r => { graph[r] = []; });

  // R -> P (Allocation: resource held by process)
  for (const p of processes) {
    for (const r of resources) {
      if ((allocation[p]?.[r] || 0) > 0) {
        graph[r].push(p);
      }
    }
  }

  // P -> R (Request: process requesting resource)
  for (const p of processes) {
    for (const r of resources) {
      if ((request[p]?.[r] || 0) > 0) {
        graph[p].push(r);
      }
    }
  }

  const visited = new Set<string>();
  const recStack: string[] = [];

  function dfs(node: string): string[] | null {
    visited.add(node);
    recStack.push(node);

    for (const neighbor of graph[node] || []) {
      if (!visited.has(neighbor)) {
        const cycle = dfs(neighbor);
        if (cycle) return cycle;
      } else if (recStack.includes(neighbor)) {
        const idx = recStack.indexOf(neighbor);
        return [...recStack.slice(idx), neighbor];
      }
    }

    recStack.pop();
    return null;
  }

  let detectedCycle: string[] | null = null;
  for (const node of Object.keys(graph)) {
    if (!visited.has(node)) {
      const cycle = dfs(node);
      if (cycle) {
        detectedCycle = cycle;
        break;
      }
    }
  }

  // Banker's Algorithm safety simulation
  const avail: Record<string, number> = available ? { ...available } : { R1: 0, R2: 0, R3: 0 };
  const work: Record<string, number> = { ...avail };
  const finish: Record<string, boolean> = {};
  processes.forEach(p => { finish[p] = false; });
  const safeSequence: string[] = [];
  const simulationSteps: string[] = [];

  simulationSteps.push(`Initial Available (Work): [${resources.map(r => `${r}:${work[r] || 0}`).join(', ')}]`);

  let stepNum = 1;
  while (safeSequence.length < processes.length) {
    let candidateFound = false;
    for (const p of processes) {
      if (!finish[p]) {
        const canSatisfy = resources.every(r => (request[p]?.[r] || 0) <= (work[r] || 0));
        if (canSatisfy) {
          resources.forEach(r => {
            work[r] = (work[r] || 0) + (allocation[p]?.[r] || 0);
          });
          finish[p] = true;
          safeSequence.push(p);
          const reqStr = `[${resources.map(r => `${r}:${request[p]?.[r] || 0}`).join(', ')}]`;
          const allocStr = `[${resources.map(r => `${r}:${allocation[p]?.[r] || 0}`).join(', ')}]`;
          const workStr = `[${resources.map(r => `${r}:${work[r] || 0}`).join(', ')}]`;
          simulationSteps.push(`Step ${stepNum}: Process ${p} needs ${reqStr} <= Available. Completes & releases ${allocStr}. New Available: ${workStr}`);
          stepNum += 1;
          candidateFound = true;
          break;
        }
      }
    }
    if (!candidateFound) {
      const stuck = processes.filter(p => !finish[p]);
      simulationSteps.push(`Deadlock/Unsafe: Cannot satisfy requests for remaining processes [${stuck.join(', ')}] with current Available.`);
      break;
    }
  }

  const isSafe = safeSequence.length === processes.length;
  if (isSafe) {
    simulationSteps.push(`Safe sequence verified: ${safeSequence.join(' → ')}. All processes safely terminate!`);
  }

  if (detectedCycle) {
    return {
      hasDeadlock: true,
      cycleString: detectedCycle.join(' → '),
      cycleNodes: detectedCycle,
      deadlockedProcesses: detectedCycle.filter(n => n.startsWith('P')),
      isSafe: false,
      safeSequence: [],
      simulationSteps
    };
  }

  return {
    hasDeadlock: !isSafe && safeSequence.length < processes.length,
    cycleString: '',
    cycleNodes: [],
    deadlockedProcesses: processes.filter(p => !finish[p]),
    isSafe,
    safeSequence,
    simulationSteps
  };
}
