/**
 * Cryptographic utility for PBKDF2-HMAC-SHA256 password hashing and verification
 * using the standard browser Web Crypto API.
 */

function bufferToHex(buffer: Uint8Array): string {
  return Array.from(buffer)
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

function hexToBuffer(hex: string): Uint8Array {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i++) {
    bytes[i] = parseInt(hex.substr(i * 2, 2), 16);
  }
  return bytes;
}

export async function hashPassword(
  password: string,
  existingSaltHex?: string
): Promise<{ hash: string; salt: string }> {
  const enc = new TextEncoder();
  const salt = existingSaltHex
    ? hexToBuffer(existingSaltHex)
    : window.crypto.getRandomValues(new Uint8Array(16));

  const keyMaterial = await window.crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveBits']
  );

  const derivedBits = await window.crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: salt as unknown as BufferSource,
      iterations: 100000,
      hash: 'SHA-256'
    },
    keyMaterial,
    256
  );

  const hashHex = bufferToHex(new Uint8Array(derivedBits));
  const saltHex = existingSaltHex || bufferToHex(salt);

  return { hash: hashHex, salt: saltHex };
}

export async function verifyPassword(
  password: string,
  storedHash: string,
  storedSalt?: string
): Promise<boolean> {
  if (!storedSalt) return true;
  try {
    const { hash } = await hashPassword(password, storedSalt);
    return hash === storedHash;
  } catch {
    return false;
  }
}
