/**
 * IndexedDB + In-Memory Blob Storage for Smart LMS.
 * Allows storing, retrieving, and preserving actual uploaded student and teacher files
 * (PDFs, DOCX, TXT) across role switches and page reloads without localStorage size limits.
 */

const DB_NAME = 'SmartLMS_FilesDB';
const DB_VERSION = 1;
const STORE_NAME = 'user_uploaded_files';

// Fast in-memory cache
const memoryCache = new Map<string, Blob>();

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB not supported in this environment'));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Save an actual file (Blob / File) associated with a submission or material ID.
 */
export async function saveStoredFile(id: string, file: Blob | File): Promise<void> {
  memoryCache.set(id, file);
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    store.put(file, id);
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('Could not persist file to IndexedDB, stored in memory cache:', err);
  }
}

/**
 * Retrieve the original file (Blob / File) for a given ID.
 */
export async function getStoredFile(id: string): Promise<Blob | null> {
  if (memoryCache.has(id)) {
    return memoryCache.get(id) || null;
  }
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const request = store.get(id);
    return new Promise(resolve => {
      request.onsuccess = () => {
        const result = request.result as Blob | undefined;
        if (result) {
          memoryCache.set(id, result);
          resolve(result);
        } else {
          resolve(null);
        }
      };
      request.onerror = () => resolve(null);
    });
  } catch (err) {
    return null;
  }
}
