/**
 * Pure TypeScript PDF-1.4 Document Generator.
 * Generates genuine, byte-exact compliant PDF documents with fonts, headers,
 * metadata, and formatted text for course materials and student submissions.
 * Guaranteed to open in Adobe Acrobat, Chrome, Firefox, and Edge without errors.
 */

export interface AcademicDocDetails {
  title: string;
  course: string;
  author: string;
  isSubmission?: boolean;
  date?: string;
  fileSize?: string;
  description?: string;
  grade?: number;
  marksAwarded?: string;
  feedback?: string;
}

export function generateAcademicPdfBlob(details: AcademicDocDetails): Blob {
  const escapePdfText = (str: string): string => {
    return (str || '')
      .replace(/\\/g, '\\\\')
      .replace(/\(/g, '\\(')
      .replace(/\)/g, '\\)');
  };

  const title = escapePdfText(details.title);
  const course = escapePdfText(details.course || 'Operating Systems (CS301)');
  const author = escapePdfText(details.author || 'Dr. Sharma');
  const dateStr = escapePdfText(details.date || new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }));
  const sizeStr = escapePdfText(details.fileSize || '2.4 MB');
  const desc = escapePdfText(
    details.description ||
    'Comprehensive lecture handouts, algorithmic diagrams, and operational specifications for academic study under the Smart LMS learning platform.'
  );

  // Construct PDF graphics and text stream
  const streamLines: string[] = [
    'BT',
    // Header Banner
    '/F2 18 Tf',
    '50 780 Td',
    '(SMART LMS - ACADEMIC DOCUMENT REPOSITORY) Tj',
    'ET',
    'BT',
    '/F1 10 Tf',
    '50 760 Td',
    '(Standard Learning Management System & OS Simulator Environment) Tj',
    'ET',
    // Decorative line (simulated by underscores or rule)
    'BT',
    '/F1 9 Tf',
    '50 745 Td',
    '(_________________________________________________________________________________) Tj',
    'ET',
    // Main Document Title
    'BT',
    '/F2 15 Tf',
    '50 715 Td',
    `(${details.isSubmission ? 'Student Submission File: ' : 'Course Material: '}${title}) Tj`,
    'ET',
    // Metadata Block
    'BT',
    '/F1 11 Tf',
    '50 680 Td',
    `(Course Name: ${course}) Tj`,
    'ET',
    'BT',
    '/F1 11 Tf',
    '50 660 Td',
    `(${details.isSubmission ? 'Student Author: ' : 'Faculty / Instructor: '}${author}) Tj`,
    'ET',
    'BT',
    '/F1 11 Tf',
    '50 640 Td',
    `(Upload Date: ${dateStr}   |   Simulated File Size: ${sizeStr}) Tj`,
    'ET'
  ];

  if (details.grade !== undefined) {
    streamLines.push(
      'BT',
      '/F2 12 Tf',
      '50 615 Td',
      `(Grade Awarded: ${details.grade} / 20) Tj`,
      'ET'
    );
  }

  // Section Header: Overview
  streamLines.push(
    'BT',
    '/F2 13 Tf',
    '50 580 Td',
    '(1. Document Overview & Abstract:) Tj',
    'ET',
    'BT',
    '/F1 10 Tf',
    '50 555 Td',
    `(${desc}) Tj`,
    'ET',
    // Key Learning Topics
    'BT',
    '/F2 13 Tf',
    '50 515 Td',
    '(2. Operating System Concepts Covered:) Tj',
    'ET',
    'BT',
    '/F1 10 Tf',
    '65 490 Td',
    '(- Process Lifecycle Management: New, Ready, Running, Waiting, Terminated) Tj',
    'ET',
    'BT',
    '/F1 10 Tf',
    '65 470 Td',
    '(- CPU Scheduling: FCFS, SJF (Preemptive & Non-Preemptive), Priority, Round Robin) Tj',
    'ET',
    'BT',
    '/F1 10 Tf',
    '65 450 Td',
    '(- Dynamic Memory Partitioning: 1000 MB Simulated RAM, First Fit & Best Fit) Tj',
    'ET',
    'BT',
    '/F1 10 Tf',
    '65 430 Td',
    '(- Concurrency & Bounded Buffer: Semaphore and Mutex Synchronized Operations) Tj',
    'ET',
    'BT',
    '/F1 10 Tf',
    '65 410 Td',
    '(- Deadlock Avoidance: Resource Allocation Graph Analysis and Cycle Detection) Tj',
    'ET',
    // Verification Seal Footer
    'BT',
    '/F1 9 Tf',
    '50 80 Td',
    '(_________________________________________________________________________________) Tj',
    'ET',
    'BT',
    '/F2 9 Tf',
    '50 60 Td',
    '(Verified Smart LMS Document Asset  *  Local Storage  *  PBKDF2 Secured Authentication) Tj',
    'ET'
  );

  const streamContent = streamLines.join('\n') + '\n';
  const encoder = new TextEncoder();
  const streamBytes = encoder.encode(streamContent);
  const streamLength = streamBytes.length;

  // Build PDF Objects
  const header = encoder.encode('%PDF-1.4\n');
  const obj1 = encoder.encode('1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n');
  const obj2 = encoder.encode('2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n');
  const obj3 = encoder.encode(
    '3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>\nendobj\n'
  );
  const obj4 = encoder.encode('4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n');
  const obj5 = encoder.encode('5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>\nendobj\n');
  
  const obj6Header = encoder.encode(`6 0 obj\n<< /Length ${streamLength} >>\nstream\n`);
  const obj6Footer = encoder.encode('\nendstream\nendobj\n');

  // Calculate byte offsets for XREF table
  const offsets: number[] = [];
  let currentOffset = header.length;

  offsets.push(currentOffset);
  currentOffset += obj1.length;

  offsets.push(currentOffset);
  currentOffset += obj2.length;

  offsets.push(currentOffset);
  currentOffset += obj3.length;

  offsets.push(currentOffset);
  currentOffset += obj4.length;

  offsets.push(currentOffset);
  currentOffset += obj5.length;

  offsets.push(currentOffset);
  currentOffset += obj6Header.length + streamBytes.length + obj6Footer.length;

  const xrefOffset = currentOffset;
  let xrefStr = 'xref\n0 7\n0000000000 65535 f \n';
  for (const off of offsets) {
    xrefStr += `${off.toString().padStart(10, '0')} 00000 n \n`;
  }
  const trailerStr = `trailer\n<< /Size 7 /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`;

  const xrefBytes = encoder.encode(xrefStr);
  const trailerBytes = encoder.encode(trailerStr);

  // Concatenate parts into Uint8Array
  const totalLength =
    header.length +
    obj1.length +
    obj2.length +
    obj3.length +
    obj4.length +
    obj5.length +
    obj6Header.length +
    streamBytes.length +
    obj6Footer.length +
    xrefBytes.length +
    trailerBytes.length;

  const pdfArray = new Uint8Array(totalLength);
  let pos = 0;

  const appendChunk = (chunk: Uint8Array) => {
    pdfArray.set(chunk, pos);
    pos += chunk.length;
  };

  appendChunk(header);
  appendChunk(obj1);
  appendChunk(obj2);
  appendChunk(obj3);
  appendChunk(obj4);
  appendChunk(obj5);
  appendChunk(obj6Header);
  appendChunk(streamBytes);
  appendChunk(obj6Footer);
  appendChunk(xrefBytes);
  appendChunk(trailerBytes);

  return new Blob([pdfArray], { type: 'application/pdf' });
}
