import { User, Course, Assignment, Submission, Material, SimulatedProcess, MemoryBlock, ActivityEntry, Enrollment } from '../types';

export const INITIAL_USERS: User[] = [
  {
    id: 'U101',
    name: 'Admin',
    username: 'admin',
    role: 'admin',
    email: 'admin@smartlms.edu',
    isActive: true,
    createdAt: '01 Oct 2024'
  },
  {
    id: 'U102',
    name: 'Dr. Sharma',
    username: 'drsharma',
    role: 'teacher',
    email: 'dr.sharma@smartlms.edu',
    isActive: true,
    createdAt: '02 Oct 2024'
  },
  {
    id: 'U103',
    name: 'Prof. Mehta',
    username: 'profmehta',
    role: 'teacher',
    email: 'prof.mehta@smartlms.edu',
    isActive: true,
    createdAt: '02 Oct 2024'
  },
  {
    id: 'U108',
    name: 'Prof. Singh',
    username: 'profsingh',
    role: 'teacher',
    email: 'prof.singh@smartlms.edu',
    isActive: true,
    createdAt: '02 Oct 2024'
  },
  {
    id: 'U104',
    name: 'Rohan',
    username: 'rohan',
    role: 'student',
    email: 'rohan@smartlms.edu',
    isActive: true,
    createdAt: '03 Oct 2024'
  },
  {
    id: 'U105',
    name: 'Neha',
    username: 'neha',
    role: 'student',
    email: 'neha@smartlms.edu',
    isActive: true,
    createdAt: '03 Oct 2024'
  },
  {
    id: 'U106',
    name: 'Priya',
    username: 'priya',
    role: 'student',
    email: 'priya@smartlms.edu',
    isActive: true,
    createdAt: '03 Oct 2024'
  },
  {
    id: 'U107',
    name: 'Aman',
    username: 'aman',
    role: 'student',
    email: 'aman@smartlms.edu',
    isActive: true,
    createdAt: '03 Oct 2024'
  }
];

export const INITIAL_COURSES: Course[] = [
  {
    id: 'C101',
    code: 'CS301',
    name: 'Operating Systems',
    teacherId: 'U102',
    teacherName: 'Prof. Sharma',
    description: 'Process scheduling, synchronization, deadlocks, and virtual memory allocation.',
    enrolledCount: 30,
    materialsCount: 12,
    assignmentsCount: 5,
    isActive: true
  },
  {
    id: 'C102',
    code: 'CS302',
    name: 'Computer Networks',
    teacherId: 'U103',
    teacherName: 'Prof. Mehta',
    description: 'TCP/IP stack, packet routing, transport layer congestion control and sockets.',
    enrolledCount: 25,
    materialsCount: 8,
    assignmentsCount: 4,
    isActive: true
  },
  {
    id: 'C103',
    code: 'CS303',
    name: 'Database Management',
    teacherId: 'U102',
    teacherName: 'Prof. Singh',
    description: 'Relational algebra, SQL queries, normal forms, transactions, and indexing.',
    enrolledCount: 28,
    materialsCount: 10,
    assignmentsCount: 3,
    isActive: true
  },
  {
    id: 'C104',
    code: 'CS304',
    name: 'Artificial Intelligence',
    teacherId: 'U103',
    teacherName: 'Prof. Gupta',
    description: 'Heuristic search algorithms, neural networks, knowledge representation.',
    enrolledCount: 22,
    materialsCount: 6,
    assignmentsCount: 3,
    isActive: true
  }
];

export const INITIAL_ASSIGNMENTS: Assignment[] = [
  {
    id: 'A101',
    courseId: 'C101',
    courseName: 'Operating Systems',
    title: 'OS Assignment 1',
    description: 'Implement FCFS and SJF scheduling algorithms and calculate average waiting time.',
    dueDate: '10 Oct 2024',
    maxMarks: 20,
    createdBy: 'Dr. Sharma'
  },
  {
    id: 'A102',
    courseId: 'C102',
    courseName: 'Computer Networks',
    title: 'CN Quiz',
    description: 'Subnetting, CIDR prefix masks, and routing table exercises.',
    dueDate: '12 Oct 2024',
    maxMarks: 25,
    createdBy: 'Prof. Mehta'
  },
  {
    id: 'A103',
    courseId: 'C103',
    courseName: 'Database Management',
    title: 'DBMS Project Report',
    description: 'Design normalized schema up to BCNF with entity-relationship diagram.',
    dueDate: '15 Oct 2024',
    maxMarks: 50,
    createdBy: 'Dr. Sharma'
  },
  {
    id: 'A104',
    courseId: 'C104',
    courseName: 'Artificial Intelligence',
    title: 'A* Search Implementation',
    description: 'Write Python script comparing A* search heuristic against Dijkstra on grid.',
    dueDate: '20 Oct 2024',
    maxMarks: 30,
    createdBy: 'Prof. Gupta'
  }
];

export const INITIAL_SUBMISSIONS: Submission[] = [
  {
    id: 'S101',
    assignmentId: 'A101',
    assignmentTitle: 'OS Assignment 1',
    courseName: 'Operating Systems',
    studentId: 'U104',
    studentName: 'Rohan',
    fileName: 'Rohan_OS_Assign1.pdf',
    fileSize: '1.4 MB',
    submissionDate: '10 Oct 2024, 10:30 AM',
    status: 'Submitted',
    marks: 18,
    feedback: 'Excellent Gantt chart trace and correct metrics.'
  },
  {
    id: 'S102',
    assignmentId: 'A101',
    assignmentTitle: 'OS Assignment 1',
    courseName: 'Operating Systems',
    studentId: 'U105',
    studentName: 'Neha',
    fileName: 'Neha_OS_Assign1.pdf',
    fileSize: '1.1 MB',
    submissionDate: '10 Oct 2024, 09:15 AM',
    status: 'Submitted',
    marks: null,
    feedback: ''
  },
  {
    id: 'S103',
    assignmentId: 'A102',
    assignmentTitle: 'CN Quiz',
    courseName: 'Computer Networks',
    studentId: 'U107',
    studentName: 'Aman',
    fileName: 'Aman_CN_Quiz.pdf',
    fileSize: '0.9 MB',
    submissionDate: '09 Oct 2024, 02:00 PM',
    status: 'Pending',
    marks: null,
    feedback: ''
  },
  {
    id: 'S104',
    assignmentId: 'A103',
    assignmentTitle: 'DBMS Project Report',
    courseName: 'Database Management',
    studentId: 'U106',
    studentName: 'Priya',
    fileName: 'Priya_DBMS_Report.pdf',
    fileSize: '2.4 MB',
    submissionDate: '09 Oct 2024, 04:20 PM',
    status: 'Submitted',
    marks: null,
    feedback: ''
  }
];

export const INITIAL_MATERIALS: Material[] = [
  {
    id: 'M101',
    courseId: 'C101',
    courseName: 'Operating Systems',
    title: 'Process_Management.pdf',
    fileName: 'Process_Management.pdf',
    fileType: 'PDF',
    fileSize: '2.1 MB',
    uploadedBy: 'Dr. Sharma',
    date: '9 Oct 2024',
    description: 'Lecture slides on process state transitions, PCB fields, and scheduling queues.'
  },
  {
    id: 'M102',
    courseId: 'C101',
    courseName: 'Operating Systems',
    title: 'OS_Notes.docx',
    fileName: 'OS_Notes.docx',
    fileType: 'DOCX',
    fileSize: '1.5 MB',
    uploadedBy: 'Dr. Sharma',
    date: '8 Oct 2024',
    description: 'Comprehensive study guide on synchronization primitives and semaphores.'
  },
  {
    id: 'M103',
    courseId: 'C102',
    courseName: 'Computer Networks',
    title: 'CN_Syllabus.pdf',
    fileName: 'CN_Syllabus.pdf',
    fileType: 'PDF',
    fileSize: '1.2 MB',
    uploadedBy: 'Dr. Mehta',
    date: '6 Oct 2024',
    description: 'Complete course schedule and lab grading criteria.'
  },
  {
    id: 'M104',
    courseId: 'C103',
    courseName: 'Database Management',
    title: 'DBMS_Questions.pdf',
    fileName: 'DBMS_Questions.pdf',
    fileType: 'PDF',
    fileSize: '3.0 MB',
    uploadedBy: 'Dr. Singh',
    date: '5 Oct 2024',
    description: 'Midterm review exercises on relational algebra queries and B+ trees.'
  }
];

export const INITIAL_PROCESSES: SimulatedProcess[] = [
  {
    pid: 'P101',
    name: 'Assignment Upload',
    taskType: 'I/O Bound',
    arrivalTime: 0,
    burstTime: 5,
    remainingTime: 5,
    priority: 2,
    memoryReq: 100,
    state: 'Ready',
    creationTime: '09 Oct 2024, 04:20 PM'
  },
  {
    pid: 'P102',
    name: 'File Processing',
    taskType: 'CPU Bound',
    arrivalTime: 1,
    burstTime: 3,
    remainingTime: 3,
    priority: 1,
    memoryReq: 250,
    state: 'Running',
    creationTime: '09 Oct 2024, 04:21 PM'
  },
  {
    pid: 'P103',
    name: 'Report Generation',
    taskType: 'I/O Bound',
    arrivalTime: 2,
    burstTime: 4,
    remainingTime: 4,
    priority: 3,
    memoryReq: 150,
    state: 'Waiting',
    creationTime: '09 Oct 2024, 04:22 PM'
  },
  {
    pid: 'P104',
    name: 'Grade Calculation',
    taskType: 'CPU Bound',
    arrivalTime: 3,
    burstTime: 6,
    remainingTime: 6,
    priority: 2,
    memoryReq: 80,
    state: 'Ready',
    creationTime: '09 Oct 2024, 04:23 PM'
  }
];

export const INITIAL_MEMORY_BLOCKS: MemoryBlock[] = [
  { start: 0, size: 100, status: 'Allocated', process: 'P1' },
  { start: 100, size: 250, status: 'Allocated', process: 'P2' },
  { start: 350, size: 150, status: 'Allocated', process: 'P3' },
  { start: 500, size: 500, status: 'Free', process: '-' }
];

export const INITIAL_ACTIVITY_LOG: ActivityEntry[] = [
  {
    id: 'act-1',
    timestamp: '10 Oct 2024, 10:30 AM',
    user: 'Rohan',
    activity: 'Rohan submitted OS Assignment 1',
    details: 'File: Rohan_OS_Assign1.pdf'
  },
  {
    id: 'act-2',
    timestamp: '10 Oct 2024, 09:15 AM',
    user: 'Admin',
    activity: 'New user (Neha) registered',
    details: 'Role: Student, ID: U105'
  },
  {
    id: 'act-3',
    timestamp: '9 Oct 2024, 04:20 PM',
    user: 'Dr. Sharma',
    activity: 'Dr. Sharma uploaded a new material',
    details: 'Process_Management.pdf for Operating Systems'
  },
  {
    id: 'act-4',
    timestamp: '9 Oct 2024, 04:20 PM',
    user: 'OS Simulator',
    activity: 'Process P105 created (Assignment Submission)',
    details: 'Triggered from student submission event'
  }
];

export const INITIAL_ENROLLMENTS: Enrollment[] = [
  { id: 'E101', studentId: 'U104', courseId: 'C101', enrolledAt: '03 Oct 2024' },
  { id: 'E102', studentId: 'U104', courseId: 'C102', enrolledAt: '03 Oct 2024' },
  { id: 'E103', studentId: 'U104', courseId: 'C103', enrolledAt: '03 Oct 2024' },
  { id: 'E104', studentId: 'U104', courseId: 'C104', enrolledAt: '03 Oct 2024' },
  { id: 'E105', studentId: 'U105', courseId: 'C101', enrolledAt: '03 Oct 2024' },
  { id: 'E106', studentId: 'U106', courseId: 'C103', enrolledAt: '03 Oct 2024' },
  { id: 'E107', studentId: 'U107', courseId: 'C102', enrolledAt: '03 Oct 2024' }
];
