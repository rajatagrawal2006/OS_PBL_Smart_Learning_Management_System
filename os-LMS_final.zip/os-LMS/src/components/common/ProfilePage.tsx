import React, { useState } from 'react';
import { User, Mail, Shield, KeyRound, CheckCircle2, AlertCircle, Building, BookOpen, Clock, Check, Plus, MinusCircle } from 'lucide-react';
import { User as UserType, Course, Enrollment } from '../../types';
import { hashPassword, verifyPassword } from '../../utils/crypto';

interface ProfilePageProps {
  currentUser: UserType;
  courses?: Course[];
  enrollments?: Enrollment[];
  onToggleEnrollment?: (courseId: string) => void;
  onUpdateUser: (updatedUser: UserType) => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({
  currentUser,
  courses = [],
  enrollments = [],
  onToggleEnrollment,
  onUpdateUser
}) => {
  const [name, setName] = useState(currentUser.name);
  const [email, setEmail] = useState(`${currentUser.username.toLowerCase()}@university.edu`);
  const [department, setDepartment] = useState(
    currentUser.role === 'teacher' ? 'Computer Science & Engineering' :
    currentUser.role === 'admin' ? 'Academic Information Systems' : 'Information Technology'
  );
  const [bio, setBio] = useState(
    currentUser.role === 'teacher'
      ? 'Specializing in Operating Systems, Distributed Kernels, and Real-Time CPU Architecture.'
      : currentUser.role === 'admin'
      ? 'Lead Administrator for Smart LMS and Operating Systems Laboratory Infrastructure.'
      : 'Undergraduate Computer Science student focusing on Systems Programming and Algorithms.'
  );

  // Password fields
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordNotice, setPasswordNotice] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);
  const [profileNotice, setProfileNotice] = useState<string>('');

  const handleUpdateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const updated = {
      ...currentUser,
      name: name.trim()
    };
    onUpdateUser(updated);
    setProfileNotice('✓ Profile details saved successfully.');
    setTimeout(() => setProfileNotice(''), 3500);
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordNotice(null);

    if (newPassword.length < 6) {
      setPasswordNotice({ type: 'error', msg: 'New password must be at least 6 characters long.' });
      return;
    }

    if (newPassword !== confirmPassword) {
      setPasswordNotice({ type: 'error', msg: 'New password and confirmation do not match.' });
      return;
    }

    const isCurrentValid = !currentUser.passwordHash || (await verifyPassword(currentPassword, currentUser.passwordHash, currentUser.salt));
    if (!isCurrentValid) {
      setPasswordNotice({ type: 'error', msg: 'Current password entered is incorrect.' });
      return;
    }

    const { hash, salt } = await hashPassword(newPassword);
    const updated = {
      ...currentUser,
      passwordHash: hash,
      salt
    };
    onUpdateUser(updated);
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    setPasswordNotice({ type: 'success', msg: '✓ Password changed successfully! PBKDF2 hash updated.' });
    setTimeout(() => setPasswordNotice(null), 4000);
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div className="flex items-center gap-5">
          <div className="w-16 h-16 rounded-2xl bg-[#173B63] text-white font-extrabold text-2xl flex items-center justify-center shadow-md ring-4 ring-slate-100">
            {currentUser.name.charAt(0)}
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h1 className="text-2xl font-bold text-[#172033]">{currentUser.name}</h1>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-blue-50 text-blue-700 border border-blue-200">
                {currentUser.role}
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium mt-1">
              Username: <span className="font-mono font-semibold text-slate-700">@{currentUser.username}</span> • ID: <span className="font-mono text-slate-700">{currentUser.id}</span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-right">
            <span className="text-[10px] text-slate-400 uppercase font-bold block">Status</span>
            <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 justify-end">
              <span className="w-2 h-2 rounded-full bg-emerald-500" /> Active Session
            </span>
          </div>
        </div>
      </div>

      {profileNotice && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
          <span>{profileNotice}</span>
        </div>
      )}

      {/* Two Columns: Profile Form + Security */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column: Personal Information */}
        <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs p-6">
          <h2 className="text-base font-bold text-[#172033] mb-4 flex items-center gap-2">
            <User size={18} className="text-blue-600" />
            <span>Personal & Academic Information</span>
          </h2>

          <form onSubmit={handleUpdateProfile} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Full Legal Name
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Institutional Email Address
              </label>
              <div className="relative">
                <Mail size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600 font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Department / Academic Division
              </label>
              <div className="relative">
                <Building size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={department}
                  onChange={e => setDepartment(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Bio & Academic Interests
              </label>
              <textarea
                rows={3}
                value={bio}
                onChange={e => setBio(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600 resize-none"
              />
            </div>

            <button
              type="submit"
              className="py-2.5 px-5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer"
            >
              Save Profile Details
            </button>
          </form>
        </div>

        {/* Right Column: Password & Account Security */}
        <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs p-6 flex flex-col justify-between">
          <div>
            <h2 className="text-base font-bold text-[#172033] mb-4 flex items-center gap-2">
              <Shield size={18} className="text-blue-600" />
              <span>Password & Authentication Security</span>
            </h2>

            {passwordNotice && (
              <div className={`p-3.5 rounded-xl text-xs font-bold flex items-center gap-2 mb-4 ${
                passwordNotice.type === 'success'
                  ? 'bg-emerald-50 text-emerald-900 border border-emerald-200'
                  : 'bg-rose-50 text-rose-900 border border-rose-200'
              }`}>
                {passwordNotice.type === 'success' ? <CheckCircle2 size={16} /> : <AlertCircle size={16} />}
                <span>{passwordNotice.msg}</span>
              </div>
            )}

            <form onSubmit={handlePasswordChange} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Current Password
                </label>
                <div className="relative">
                  <KeyRound size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="password"
                    required
                    placeholder="Enter current password..."
                    value={currentPassword}
                    onChange={e => setCurrentPassword(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  New Password
                </label>
                <div className="relative">
                  <KeyRound size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="password"
                    required
                    placeholder="Min 6 characters..."
                    value={newPassword}
                    onChange={e => setNewPassword(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Confirm New Password
                </label>
                <div className="relative">
                  <KeyRound size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="password"
                    required
                    placeholder="Confirm new password..."
                    value={confirmPassword}
                    onChange={e => setConfirmPassword(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600 font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="py-2.5 px-5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer"
              >
                Update Password
              </button>
            </form>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Cryptographic Standard: PBKDF2-HMAC-SHA256</span>
            <span className="font-mono">100,000 Iterations</span>
          </div>
        </div>
      </div>

      {/* Student Academic Course Registrations */}
      {currentUser.role === 'student' && courses.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4 pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-[#172033] flex items-center gap-2">
                <BookOpen size={18} className="text-blue-600" />
                <span>My Academic Course Registrations (Live Enrollment)</span>
              </h2>
              <p className="text-xs text-slate-500 font-medium">
                Enroll or withdraw from university courses in real time. Changes directly sync with faculty gradebooks and instructor rosters.
              </p>
            </div>
            <span className="text-xs font-bold px-2.5 py-1 bg-blue-50 text-blue-700 rounded-lg shrink-0">
              {enrollments.filter(e => e.studentId === currentUser.id).length} Active Enrollments
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {courses.map(course => {
              const isEnrolled = enrollments.some(e => e.courseId === course.id && e.studentId === currentUser.id);
              const courseEnrolledCount = enrollments.filter(e => e.courseId === course.id).length;

              return (
                <div
                  key={course.id}
                  className={`p-4 rounded-xl border transition-all flex items-center justify-between gap-3 ${
                    isEnrolled
                      ? 'border-emerald-200 bg-emerald-50/30'
                      : 'border-slate-200 bg-slate-50/50 hover:border-slate-300'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-bold text-[10px]">
                        {course.code}
                      </span>
                      <span className="font-bold text-xs text-slate-900">{course.name}</span>
                    </div>
                    <p className="text-[11px] text-slate-500">
                      Instructor: {course.teacherName} • <span className="font-medium text-slate-600">{courseEnrolledCount} Students Enrolled</span>
                    </p>
                  </div>

                  <div>
                    {isEnrolled ? (
                      <button
                        type="button"
                        onClick={() => onToggleEnrollment?.(course.id)}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-lg border border-rose-200 text-rose-700 hover:bg-rose-50 text-xs font-semibold transition-colors cursor-pointer"
                        title="Withdraw from this course"
                      >
                        <MinusCircle size={13} />
                        <span>Drop</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => onToggleEnrollment?.(course.id)}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
                        title="Enroll in this course"
                      >
                        <Plus size={13} />
                        <span>Enroll</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
