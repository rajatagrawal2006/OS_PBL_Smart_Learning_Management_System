import React, { useState } from 'react';
import { Award, CheckCircle2, BookOpen, Download, UserCheck, TrendingUp, Filter } from 'lucide-react';
import { Course, Assignment, Submission, User } from '../../types';

interface GradesPageProps {
  currentUser: User;
  courses: Course[];
  assignments: Assignment[];
  submissions: Submission[];
}

export const GradesPage: React.FC<GradesPageProps> = ({
  currentUser,
  courses,
  assignments,
  submissions
}) => {
  const [selectedCourseFilter, setSelectedCourseFilter] = useState('All');

  const isTeacher = currentUser.role === 'teacher' || currentUser.role === 'admin';

  // Filter submissions
  const relevantSubmissions = isTeacher
    ? submissions
    : submissions.filter(s => s.studentId === currentUser.id);

  const gradedSubmissions = relevantSubmissions.filter(
    s => s.marks !== null && s.marks !== undefined && (selectedCourseFilter === 'All' || s.courseName === selectedCourseFilter)
  );

  // Computations
  const totalSubmissionsCount = relevantSubmissions.length;
  const gradedCount = relevantSubmissions.filter(s => s.marks !== null && s.marks !== undefined).length;
  const pendingCount = totalSubmissionsCount - gradedCount;

  const averagePercentage = gradedSubmissions.length > 0
    ? Math.round(gradedSubmissions.reduce((acc, s) => acc + ((s.marks || 0) / 20) * 100, 0) / gradedSubmissions.length)
    : 85;

  const highestScore = gradedSubmissions.length > 0
    ? Math.max(...gradedSubmissions.map(s => s.marks || 0))
    : 20;

  const getLetterGrade = (marks: number, max: number = 20) => {
    const pct = (marks / max) * 100;
    if (pct >= 90) return { letter: 'A+', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' };
    if (pct >= 80) return { letter: 'A', color: 'bg-blue-50 text-blue-700 border-blue-200' };
    if (pct >= 70) return { letter: 'B', color: 'bg-indigo-50 text-indigo-700 border-indigo-200' };
    if (pct >= 60) return { letter: 'C', color: 'bg-amber-50 text-amber-700 border-amber-200' };
    return { letter: 'D', color: 'bg-rose-50 text-rose-700 border-rose-200' };
  };

  const exportGradebookCsv = () => {
    const rows = [
      ['Student Name', 'Course', 'Assignment', 'Marks', 'Max Marks', 'Percentage', 'Letter Grade', 'Feedback'],
      ...gradedSubmissions.map(s => [
        s.studentName,
        s.courseName,
        s.assignmentTitle,
        s.marks || 0,
        20,
        `${Math.round(((s.marks || 0) / 20) * 100)}%`,
        getLetterGrade(s.marks || 0).letter,
        `"${(s.feedback || '').replace(/"/g, '""')}"`
      ])
    ];

    const csvContent = 'data:text/csv;charset=utf-8,' + rows.map(e => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `SmartLMS_Gradebook_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#172033] flex items-center gap-2">
            <Award size={24} className="text-blue-600" />
            <span>{isTeacher ? 'Gradebook & Academic Evaluations' : 'My Grades & Performance'}</span>
          </h1>
          <p className="text-sm text-slate-500 font-medium">
            {isTeacher
              ? 'Complete record of student assignment scores, rubric evaluations, and feedback'
              : 'Detailed breakdown of your evaluated assignments, marks, and faculty comments'}
          </p>
        </div>

        {isTeacher && (
          <button
            type="button"
            onClick={exportGradebookCsv}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer"
          >
            <Download size={14} />
            <span>Export Gradebook (CSV)</span>
          </button>
        )}
      </div>

      {/* 4 Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-xl">
            <TrendingUp size={24} />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900">{averagePercentage}%</div>
            <div className="text-xs font-medium text-slate-500">{isTeacher ? 'Class Average Score' : 'Average Grade'}</div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-xl">
            <CheckCircle2 size={24} />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900">{gradedCount}</div>
            <div className="text-xs font-medium text-slate-500">Graded Submissions</div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold text-xl">
            <BookOpen size={24} />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900">{pendingCount}</div>
            <div className="text-xs font-medium text-slate-500">Pending Evaluation</div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center font-bold text-xl">
            <Award size={24} />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900">{highestScore} / 20</div>
            <div className="text-xs font-medium text-slate-500">Top Evaluation</div>
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
            <Filter size={14} />
            <span>Course Filter:</span>
          </div>

          <select
            value={selectedCourseFilter}
            onChange={e => setSelectedCourseFilter(e.target.value)}
            className="px-3 py-1.5 rounded-lg border border-slate-300 text-xs focus:outline-blue-600 bg-white font-medium"
          >
            <option value="All">All Enrolled Courses</option>
            {courses.map(c => (
              <option key={c.id} value={c.name}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        <span className="text-xs text-slate-500 font-medium">
          Showing {gradedSubmissions.length} graded records
        </span>
      </div>

      {/* Grade Table */}
      <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 font-bold uppercase tracking-wider text-[11px]">
                {isTeacher && <th className="py-3 px-5">Student</th>}
                <th className="py-3 px-4">Course</th>
                <th className="py-3 px-4">Assignment</th>
                <th className="py-3 px-4">Submitted File</th>
                <th className="py-3 px-4">Score</th>
                <th className="py-3 px-4">Grade</th>
                <th className="py-3 px-5">Faculty Feedback</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {gradedSubmissions.length === 0 ? (
                <tr>
                  <td colSpan={isTeacher ? 7 : 6} className="py-10 text-center text-slate-400 text-xs">
                    No graded assignments found yet. Submissions will appear here once reviewed and scored.
                  </td>
                </tr>
              ) : (
                gradedSubmissions.map(sub => {
                  const gradeInfo = getLetterGrade(sub.marks || 0);

                  return (
                    <tr key={sub.id} className="hover:bg-slate-50/60 transition-colors">
                      {isTeacher && (
                        <td className="py-3.5 px-5 font-bold text-slate-900">
                          <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-[11px]">
                              {sub.studentName.charAt(0)}
                            </div>
                            <span>{sub.studentName}</span>
                          </div>
                        </td>
                      )}

                      <td className="py-3.5 px-4 font-semibold text-slate-800">
                        {sub.courseName}
                      </td>

                      <td className="py-3.5 px-4 text-slate-700 font-medium">
                        {sub.assignmentTitle}
                      </td>

                      <td className="py-3.5 px-4 font-mono text-[11px] text-slate-600">
                        {sub.fileName}
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="font-extrabold text-slate-900 text-sm">{sub.marks}</span>
                        <span className="text-slate-400 text-xs"> / 20</span>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold border ${gradeInfo.color}`}>
                          {gradeInfo.letter} ({Math.round(((sub.marks || 0) / 20) * 100)}%)
                        </span>
                      </td>

                      <td className="py-3.5 px-5 text-slate-600 max-w-xs truncate" title={sub.feedback}>
                        {sub.feedback || <span className="text-slate-400 italic">No written comments</span>}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
