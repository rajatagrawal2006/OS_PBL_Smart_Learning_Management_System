import React from 'react';
import {
  LayoutDashboard,
  BookOpen,
  FileText,
  FolderOpen,
  Award,
  User as UserIcon,
  LogOut,
  Users,
  Layers,
  Activity,
  Cpu,
  HardDrive,
  RefreshCw,
  AlertTriangle,
  Settings,
  ChevronDown,
  ChevronRight,
  Code
} from 'lucide-react';
import { Role } from '../../types';

interface SidebarProps {
  currentRole: Role;
  currentPage: string;
  onNavigate: (page: string) => void;
  onLogout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentRole,
  currentPage,
  onNavigate,
  onLogout,
}) => {
  const [osOpen, setOsOpen] = React.useState(true);

  return (
    <aside className="w-64 bg-[#173B63] text-slate-200 flex flex-col h-screen shrink-0 border-r border-[#0f2744] shadow-xl z-20 select-none">
      {/* Brand Header */}
      <div className="p-5 border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold shadow-md">
            🎓
          </div>
          <div>
            <h1 className="font-bold text-lg text-white tracking-wide">Smart LMS</h1>
            <p className="text-[11px] text-blue-200/80 font-medium">OS Concepts Lab</p>
          </div>
        </div>
      </div>

      {/* Nav Links */}
      <div className="flex-1 overflow-y-auto py-4 px-3 space-y-1 scrollbar-thin scrollbar-thumb-white/10">
        {/* STUDENT NAVIGATION */}
        {currentRole === 'student' && (
          <>
            <NavItem
              label="Dashboard"
              icon={<LayoutDashboard size={18} />}
              active={currentPage === 'dashboard'}
              onClick={() => onNavigate('dashboard')}
            />
            <NavItem
              label="My Courses"
              icon={<BookOpen size={18} />}
              active={currentPage === 'my_courses'}
              onClick={() => onNavigate('my_courses')}
            />
            <NavItem
              label="Assignments"
              icon={<FileText size={18} />}
              active={currentPage === 'assignments'}
              onClick={() => onNavigate('assignments')}
            />
            <NavItem
              label="Materials"
              icon={<FolderOpen size={18} />}
              active={currentPage === 'materials'}
              onClick={() => onNavigate('materials')}
            />
            <NavItem
              label="Grades"
              icon={<Award size={18} />}
              active={currentPage === 'grades'}
              onClick={() => onNavigate('grades')}
            />
            <NavItem
              label="Profile"
              icon={<UserIcon size={18} />}
              active={currentPage === 'profile'}
              onClick={() => onNavigate('profile')}
            />
          </>
        )}

        {/* TEACHER NAVIGATION */}
        {currentRole === 'teacher' && (
          <>
            <NavItem
              label="Dashboard"
              icon={<LayoutDashboard size={18} />}
              active={currentPage === 'dashboard'}
              onClick={() => onNavigate('dashboard')}
            />
            <NavItem
              label="My Courses"
              icon={<BookOpen size={18} />}
              active={currentPage === 'my_courses'}
              onClick={() => onNavigate('my_courses')}
            />
            <NavItem
              label="Create Assignment"
              icon={<FileText size={18} />}
              active={currentPage === 'create_assignment'}
              onClick={() => onNavigate('create_assignment')}
            />
            <NavItem
              label="View Submissions"
              icon={<Layers size={18} />}
              active={currentPage === 'view_submissions'}
              onClick={() => onNavigate('view_submissions')}
            />
            <NavItem
              label="Upload Materials"
              icon={<FolderOpen size={18} />}
              active={currentPage === 'upload_materials'}
              onClick={() => onNavigate('upload_materials')}
            />
            <NavItem
              label="Grades"
              icon={<Award size={18} />}
              active={currentPage === 'grades'}
              onClick={() => onNavigate('grades')}
            />
            <NavItem
              label="Profile"
              icon={<UserIcon size={18} />}
              active={currentPage === 'profile'}
              onClick={() => onNavigate('profile')}
            />
          </>
        )}

        {/* ADMIN NAVIGATION */}
        {currentRole === 'admin' && (
          <>
            <NavItem
              label="Dashboard"
              icon={<LayoutDashboard size={18} />}
              active={currentPage === 'dashboard'}
              onClick={() => onNavigate('dashboard')}
            />
            <NavItem
              label="Manage Users"
              icon={<Users size={18} />}
              active={currentPage === 'manage_users'}
              onClick={() => onNavigate('manage_users')}
            />
            <NavItem
              label="Manage Courses"
              icon={<BookOpen size={18} />}
              active={currentPage === 'manage_courses'}
              onClick={() => onNavigate('manage_courses')}
            />
            <NavItem
              label="System Activity"
              icon={<Activity size={18} />}
              active={currentPage === 'system_activity'}
              onClick={() => onNavigate('system_activity')}
            />

            {/* OS Simulator Group */}
            <div className="pt-3 pb-1">
              <button
                type="button"
                onClick={() => setOsOpen(!osOpen)}
                className="w-full flex items-center justify-between px-3 py-2 text-xs font-bold uppercase tracking-wider text-blue-200 hover:text-white rounded-md transition-colors"
              >
                <span className="flex items-center gap-2">
                  <Cpu size={16} className="text-blue-400" />
                  OS Simulator
                </span>
                {osOpen ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
              </button>

              {osOpen && (
                <div className="mt-1 pl-2 space-y-1">
                  <NavItem
                    label="Process Management"
                    icon={<Layers size={16} />}
                    active={currentPage === 'process_management'}
                    onClick={() => onNavigate('process_management')}
                    indent
                  />
                  <NavItem
                    label="CPU Scheduling"
                    icon={<Cpu size={16} />}
                    active={currentPage === 'cpu_scheduling'}
                    onClick={() => onNavigate('cpu_scheduling')}
                    indent
                  />
                  <NavItem
                    label="Memory Management"
                    icon={<HardDrive size={16} />}
                    active={currentPage === 'memory_management'}
                    onClick={() => onNavigate('memory_management')}
                    indent
                  />
                  <NavItem
                    label="File Management"
                    icon={<FolderOpen size={16} />}
                    active={currentPage === 'file_management'}
                    onClick={() => onNavigate('file_management')}
                    indent
                  />
                  <NavItem
                    label="Synchronization"
                    icon={<RefreshCw size={16} />}
                    active={currentPage === 'synchronization'}
                    onClick={() => onNavigate('synchronization')}
                    indent
                  />
                  <NavItem
                    label="Deadlock Simulation"
                    icon={<AlertTriangle size={16} />}
                    active={currentPage === 'deadlock'}
                    onClick={() => onNavigate('deadlock')}
                    indent
                  />
                </div>
              )}
            </div>

            <NavItem
              label="Settings"
              icon={<Settings size={18} />}
              active={currentPage === 'settings'}
              onClick={() => onNavigate('settings')}
            />
          </>
        )}
      </div>

      {/* Footer Controls: Logout */}
      <div className="p-3 border-t border-white/10 bg-[#122e4d]/70">
        <button
          type="button"
          onClick={onLogout}
          className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-rose-300 hover:text-white hover:bg-rose-600/30 rounded-lg transition-colors cursor-pointer"
        >
          <LogOut size={15} />
          <span>Log out</span>
        </button>
      </div>
    </aside>
  );
};

interface NavItemProps {
  label: string;
  icon: React.ReactNode;
  active: boolean;
  onClick: () => void;
  indent?: boolean;
}

const NavItem: React.FC<NavItemProps> = ({ label, icon, active, onClick, indent }) => {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 ${
        indent ? 'text-xs py-2' : ''
      } ${
        active
          ? 'bg-[#2563EB] text-white shadow-sm font-semibold'
          : 'text-slate-300 hover:bg-white/10 hover:text-white'
      }`}
    >
      <span className={active ? 'text-white' : 'text-slate-400'}>{icon}</span>
      <span className="truncate">{label}</span>
    </button>
  );
};
