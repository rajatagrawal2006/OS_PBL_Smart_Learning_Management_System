import React from 'react';
import { Bell } from 'lucide-react';
import { User } from '../../types';

interface HeaderProps {
  currentUser: User;
  pageTitle: string;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  pageTitle
}) => {
  return (
    <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between shadow-xs shrink-0 z-10 select-none">
      {/* Page Title */}
      <div>
        <h2 className="text-xl font-bold text-[#172033] tracking-tight">{pageTitle}</h2>
      </div>

      {/* Right controls: Notification Bell & Profile Circle only */}
      <div className="flex items-center gap-4">
        {/* Notification Bell */}
        <button
          type="button"
          className="relative p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-full transition-colors cursor-pointer"
          aria-label="Notifications"
          title="Notifications"
        >
          <Bell size={19} />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full animate-pulse" />
        </button>

        <div className="h-6 w-px bg-slate-200" />

        {/* User Profile Circle & Details */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#173B63] text-white font-bold flex items-center justify-center text-sm shadow-sm ring-2 ring-slate-100">
            {currentUser.name.charAt(0)}
          </div>
          <div className="hidden sm:block text-left">
            <div className="text-sm font-bold text-slate-900 leading-none">
              {currentUser.name}
            </div>
            <div className="text-xs font-semibold text-blue-600 uppercase tracking-wider mt-1">
              {currentUser.role}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
