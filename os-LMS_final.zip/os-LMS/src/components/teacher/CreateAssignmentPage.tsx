import React, { useState } from 'react';
import { FilePlus, Calendar, Award, BookOpen, Trash2, CheckCircle2, FileText, Clock, Users } from 'lucide-react';
import { Course, Assignment, Submission, User } from '../../types';

interface CreateAssignmentPageProps {
  currentUser: User;
  courses: Course[];
  assignments: Assignment[];
  submissions: Submission[];
  onCreateAssignment: (assignmentData: Omit<Assignment, 'id'>) => void;
  onDeleteAssignment: (id: string) => void;
}

export const CreateAssignmentPage: React.FC<CreateAssignmentPageProps> = ({
  currentUser,
  courses,
  assignments,
  submissions,
  onCreateAssignment,
  onDeleteAssignment
}) => {
  const [title, setTitle] = useState('');
  const [courseId, setCourseId] = useState(courses[0]?.id || 'C101');
  const [dueDate, setDueDate] = useState('');
  const [maxMarks, setMaxMarks] = useState<number>(20);
  const [description, setDescription] = useState('');
  const [notice, setNotice] = useState('');

  const showNotification = (msg: string) => {
    setNotice(msg);
    setTimeout(() => setNotice(''), 3500);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const selectedCourse = courses.find(c => c.id === courseId) || courses[0];
    const formattedDueDate = dueDate
      ? new Date(dueDate).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
      : '25 Oct 2024';

    onCreateAssignment({
      courseId: selectedCourse?.id || 'C101',
      courseName: selectedCourse?.name || 'Operating Systems',
      title: title.trim(),
      description: description.trim() || 'Complete the assignment questions and upload your solution report in PDF format.',
      dueDate: formattedDueDate,
      maxMarks: Number(maxMarks) || 20,
      createdBy: currentUser.name
    });

    setTitle('');
    setDescription('');
    setDueDate('');
    setMaxMarks(20);
    showNotification(`✓ Assignment "${title}" created and published to students!`);
  };

  // Filter assignments created by or relevant to this teacher
  const teacherCourses = new Set(courses.filter(c => c.teacherId === currentUser.id || c.teacherName === currentUser.name).map(c => c.name));
  const displayAssignments = assignments.filter(a => teacherCourses.size === 0 || teacherCourses.has(a.courseName));

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-[#172033] flex items-center gap-2">
          <FilePlus size={24} className="text-blue-600" />
          <span>Create & Manage Assignments</span>
        </h1>
        <p className="text-sm text-slate-500 font-medium">
          Draft problem statements, establish due dates, and track student submissions
        </p>
      </div>

      {notice && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
          <span>{notice}</span>
        </div>
      )}

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (1 col): Creation Form */}
        <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs p-6 h-fit">
          <h2 className="text-base font-bold text-[#172033] mb-4 flex items-center gap-2">
            <FilePlus size={18} className="text-blue-600" />
            <span>New Assignment Form</span>
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Target Course *
              </label>
              <select
                value={courseId}
                onChange={e => setCourseId(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600 bg-white font-medium"
              >
                {courses.map(c => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.code})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Assignment Title *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Lab 3: Page Replacement Algorithms"
                value={title}
                onChange={e => setTitle(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Due Date
                </label>
                <input
                  type="date"
                  value={dueDate}
                  onChange={e => setDueDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Maximum Marks
                </label>
                <input
                  type="number"
                  min="5"
                  max="100"
                  value={maxMarks}
                  onChange={e => setMaxMarks(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Instructions & Problem Statement
              </label>
              <textarea
                rows={4}
                placeholder="Describe algorithmic constraints, submission format requirements (PDF/code), and grading rubric..."
                value={description}
                onChange={e => setDescription(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600 resize-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 px-4 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              <FilePlus size={15} />
              <span>Publish Assignment</span>
            </button>
          </form>
        </div>

        {/* Right Column (2 cols): Published Assignments List */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-[#172033]">Active Course Assignments</h2>
              <p className="text-xs text-slate-500">Live assignments currently visible to enrolled students</p>
            </div>
            <span className="text-xs font-bold px-2.5 py-1 bg-blue-50 text-blue-700 rounded-md">
              {displayAssignments.length} Published
            </span>
          </div>

          <div className="divide-y divide-slate-100">
            {displayAssignments.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs">
                No assignments published yet. Use the form on the left to create your first assignment.
              </div>
            ) : (
              displayAssignments.map(assign => {
                const subCount = submissions.filter(s => s.assignmentId === assign.id).length;
                const gradedCount = submissions.filter(s => s.assignmentId === assign.id && s.status === 'Graded').length;

                return (
                  <div key={assign.id} className="p-5 hover:bg-slate-50/60 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="space-y-1.5 flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-bold text-[10px]">
                          {assign.courseName}
                        </span>
                        <span className="text-xs font-bold text-slate-900">{assign.title}</span>
                      </div>
                      <p className="text-xs text-slate-500 line-clamp-2">
                        {assign.description}
                      </p>
                      <div className="flex flex-wrap items-center gap-4 text-[11px] text-slate-500 pt-1">
                        <span className="flex items-center gap-1 font-medium text-slate-600">
                          <Calendar size={12} className="text-slate-400" />
                          Due: {assign.dueDate}
                        </span>
                        <span className="flex items-center gap-1 font-medium text-slate-600">
                          <Award size={12} className="text-amber-500" />
                          Max: {assign.maxMarks} Marks
                        </span>
                        <span className="flex items-center gap-1 font-medium text-emerald-600">
                          <Users size={12} />
                          {subCount} Submissions ({gradedCount} Graded)
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                      <button
                        type="button"
                        onClick={() => {
                          if (window.confirm(`Delete assignment "${assign.title}"?`)) {
                            onDeleteAssignment(assign.id);
                            showNotification(`Removed assignment "${assign.title}".`);
                          }
                        }}
                        className="p-2 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                        title="Delete Assignment"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
