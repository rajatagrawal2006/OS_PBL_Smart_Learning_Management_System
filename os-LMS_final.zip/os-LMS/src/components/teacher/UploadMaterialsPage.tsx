import React, { useState, useRef } from 'react';
import { UploadCloud, FileText, Trash2, Download, Eye, CheckCircle2, FolderOpen, HardDrive, X } from 'lucide-react';
import { Course, Material, User } from '../../types';
import { getStoredFile } from '../../utils/fileBlobStorage';
import { generateAcademicPdfBlob } from '../../utils/pdfGenerator';

interface UploadMaterialsPageProps {
  currentUser: User;
  courses: Course[];
  materials: Material[];
  onUploadMaterial: (materialData: Partial<Material>, fileBlob?: File | null) => void;
  onDeleteMaterial: (id: string) => void;
}

export const UploadMaterialsPage: React.FC<UploadMaterialsPageProps> = ({
  currentUser,
  courses,
  materials,
  onUploadMaterial,
  onDeleteMaterial
}) => {
  const [courseId, setCourseId] = useState(courses[0]?.id || 'C101');
  const [title, setTitle] = useState('');
  const [fileName, setFileName] = useState('');
  const [fileType, setFileType] = useState('PDF');
  const [fileSize, setFileSize] = useState('2.4 MB');
  const [description, setDescription] = useState('');
  const [selectedFileObject, setSelectedFileObject] = useState<File | null>(null);
  const [notice, setNotice] = useState('');
  const [previewMaterial, setPreviewMaterial] = useState<Material | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const showNotification = (msg: string) => {
    setNotice(msg);
    setTimeout(() => setNotice(''), 3500);
  };

  const handleFilePicked = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFileObject(file);
      setFileName(file.name);
      if (!title) {
        setTitle(file.name.replace(/\.[^/.]+$/, '').replace(/_/g, ' '));
      }
      const ext = file.name.split('.').pop()?.toUpperCase() || 'PDF';
      setFileType(['PDF', 'DOCX', 'PPTX', 'TXT', 'ZIP'].includes(ext) ? ext : 'PDF');
      const mb = (file.size / (1024 * 1024)).toFixed(1);
      setFileSize(`${mb === '0.0' ? '0.5' : mb} MB`);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalFileName = fileName.trim() || `${title.replace(/\s+/g, '_')}.pdf`;
    const selectedCourse = courses.find(c => c.id === courseId) || courses[0];

    onUploadMaterial(
      {
        courseId: selectedCourse?.id || 'C101',
        courseName: selectedCourse?.name || 'Operating Systems',
        title: title.trim() || finalFileName,
        fileName: finalFileName,
        fileType,
        fileSize,
        uploadedBy: currentUser.name,
        date: 'Today',
        description: description.trim() || 'Course lecture handouts and reference reading.'
      },
      selectedFileObject
    );

    setTitle('');
    setFileName('');
    setDescription('');
    setSelectedFileObject(null);
    showNotification(`✓ Material "${finalFileName}" uploaded successfully and available to students!`);
  };

  const triggerDownload = async (mat: Material) => {
    let blob: Blob | null = null;
    if (mat.id) {
      try {
        blob = await getStoredFile(mat.id);
      } catch (err) {
        blob = null;
      }
    }

    if (!blob) {
      blob = generateAcademicPdfBlob({
        title: mat.fileName,
        course: mat.courseName,
        author: mat.uploadedBy,
        fileSize: mat.fileSize,
        description: mat.description || 'Verified course handouts and syllabus material.'
      });
    }

    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = mat.fileName.endsWith('.pdf') ? mat.fileName : `${mat.fileName}.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    showNotification(`✓ Downloaded ${mat.fileName} (${mat.fileSize})`);
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-[#172033] flex items-center gap-2">
          <FolderOpen size={24} className="text-blue-600" />
          <span>Upload Course Materials</span>
        </h1>
        <p className="text-sm text-slate-500 font-medium">
          Distribute lecture notes, slide decks, syllabi, and reference guides to students
        </p>
      </div>

      {notice && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
          <span>{notice}</span>
        </div>
      )}

      {/* Two Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Form (1 Col) */}
        <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs p-6 h-fit">
          <h2 className="text-base font-bold text-[#172033] mb-4 flex items-center gap-2">
            <UploadCloud size={18} className="text-blue-600" />
            <span>Upload New Material</span>
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Target Course *
              </label>
              <select
                value={courseId}
                onChange={e => setCourseId(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600 bg-white font-medium"
              >
                {courses.map(c => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.code})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Material Title *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Chapter 4: CPU Scheduling Algorithms"
                value={title}
                onChange={e => setTitle(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600"
              />
            </div>

            {/* Drop Zone */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Upload File (PDF / DOCX)
              </label>
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-300 hover:border-blue-500 rounded-xl p-5 text-center cursor-pointer transition-colors bg-slate-50/50"
              >
                <UploadCloud size={28} className="mx-auto text-blue-500 mb-1.5" />
                <span className="text-xs font-bold text-blue-600 block">
                  {fileName ? fileName : 'Choose a file from computer'}
                </span>
                <span className="text-[11px] text-slate-400 block mt-0.5">
                  {selectedFileObject ? `${fileSize} • Ready to upload` : 'PDF, DOCX, TXT up to 25MB'}
                </span>
                <input
                  ref={fileInputRef}
                  type="file"
                  className="hidden"
                  onChange={handleFilePicked}
                  accept=".pdf,.docx,.pptx,.txt"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  File Type
                </label>
                <select
                  value={fileType}
                  onChange={e => setFileType(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600 bg-white"
                >
                  <option value="PDF">PDF Document</option>
                  <option value="DOCX">Word Document</option>
                  <option value="PPTX">Presentation</option>
                  <option value="TXT">Text Notes</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  File Size
                </label>
                <input
                  type="text"
                  value={fileSize}
                  onChange={e => setFileSize(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600 font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Description & Topics Covered
              </label>
              <textarea
                rows={3}
                placeholder="Key concepts explained in this document..."
                value={description}
                onChange={e => setDescription(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600 resize-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 px-4 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              <HardDrive size={15} />
              <span>Publish to Course Repository</span>
            </button>
          </form>
        </div>

        {/* Right Repository Table (2 Cols) */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-[#172033]">Published Materials Repository</h2>
              <p className="text-xs text-slate-500">All materials currently accessible to enrolled students</p>
            </div>
            <span className="text-xs font-bold px-2.5 py-1 bg-blue-50 text-blue-700 rounded-md">
              {materials.length} Files
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 font-bold uppercase tracking-wider text-[11px]">
                  <th className="py-3 px-5">Material Title / File</th>
                  <th className="py-3 px-3">Type</th>
                  <th className="py-3 px-3">Size</th>
                  <th className="py-3 px-4">Course</th>
                  <th className="py-3 px-4">Uploaded By</th>
                  <th className="py-3 px-5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {materials.map(mat => (
                  <tr key={mat.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3.5 px-5">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-sm shrink-0">
                          <FileText size={16} />
                        </div>
                        <div>
                          <div className="font-bold text-slate-900">{mat.title}</div>
                          <div className="text-[10px] text-slate-400 font-mono">{mat.fileName}</div>
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-3">
                      <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-bold text-[10px]">
                        {mat.fileType}
                      </span>
                    </td>

                    <td className="py-3.5 px-3 text-slate-600 font-mono">
                      {mat.fileSize}
                    </td>

                    <td className="py-3.5 px-4 font-semibold text-slate-700">
                      {mat.courseName}
                    </td>

                    <td className="py-3.5 px-4 text-slate-600">
                      {mat.uploadedBy}
                    </td>

                    <td className="py-3.5 px-5 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => setPreviewMaterial(mat)}
                          className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-blue-600 transition-colors cursor-pointer"
                          title="Preview Material Details"
                        >
                          <Eye size={15} />
                        </button>

                        <button
                          type="button"
                          onClick={() => triggerDownload(mat)}
                          className="p-1.5 rounded hover:bg-emerald-50 text-slate-500 hover:text-emerald-600 transition-colors cursor-pointer"
                          title="Download File"
                        >
                          <Download size={15} />
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            if (window.confirm(`Delete material "${mat.fileName}"?`)) {
                              onDeleteMaterial(mat.id);
                              showNotification(`Deleted "${mat.fileName}" from repository.`);
                            }
                          }}
                          className="p-1.5 rounded hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                          title="Delete Material"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Preview Modal */}
      {previewMaterial && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2">
                <FileText size={18} className="text-blue-600" />
                <h3 className="text-base font-bold text-slate-900">Material Overview</h3>
              </div>
              <button
                type="button"
                onClick={() => setPreviewMaterial(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X size={18} />
              </button>
            </div>

            <div className="space-y-3 text-xs mb-6">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400 font-bold uppercase text-[10px]">Title:</span>
                  <span className="font-bold text-slate-800">{previewMaterial.title}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400 font-bold uppercase text-[10px]">Course:</span>
                  <span className="font-semibold text-slate-700">{previewMaterial.courseName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400 font-bold uppercase text-[10px]">File Name:</span>
                  <span className="font-mono text-slate-700">{previewMaterial.fileName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400 font-bold uppercase text-[10px]">Size & Type:</span>
                  <span className="font-mono text-slate-700">{previewMaterial.fileSize} ({previewMaterial.fileType})</span>
                </div>
              </div>

              {previewMaterial.description && (
                <div>
                  <span className="text-slate-500 font-bold block mb-1">Description:</span>
                  <div className="p-3 rounded-lg bg-blue-50/50 border border-blue-100 text-slate-700">
                    {previewMaterial.description}
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => triggerDownload(previewMaterial)}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs"
              >
                <Download size={14} />
                <span>Download Material</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
