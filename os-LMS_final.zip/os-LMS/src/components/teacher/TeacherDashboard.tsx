import React, { useState } from 'react';
import {
  BookOpen,
  Users,
  FileText,
  CheckSquare,
  Plus,
  CheckCircle2,
  Award,
  Clock,
  Settings,
  Trash2,
  X,
  ArrowRight
} from 'lucide-react';
import { User, Course, Submission, Enrollment } from '../../types';

interface TeacherDashboardProps {
  currentUser: User;
  courses: Course[];
  submissions: Submission[];
  enrollments?: Enrollment[];
  users?: User[];
  onCreateCourse: (course: Partial<Course>) => void;
  onUpdateCourse?: (course: Course) => void;
  onDeleteCourse?: (courseId: string) => void;
  onGradeSubmission: (submissionId: string, marks: number, feedback: string) => void;
  onNavigate?: (page: string) => void;
}

export const TeacherDashboard: React.FC<TeacherDashboardProps> = ({
  currentUser,
  courses,
  submissions,
  enrollments = [],
  users = [],
  onCreateCourse,
  onUpdateCourse,
  onDeleteCourse,
  onGradeSubmission,
  onNavigate
}) => {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [managingCourse, setManagingCourse] = useState<Course | null>(null);
  const [selectedSubForGrading, setSelectedSubForGrading] = useState<Submission | null>(null);
  const [notice, setNotice] = useState<string>('');

  // Create course form states
  const [newCode, setNewCode] = useState('');
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');

  // Manage course form states (Code, Name, Description)
  const [editCode, setEditCode] = useState('');
  const [editName, setEditName] = useState('');
  const [editDesc, setEditDesc] = useState('');

  // Grading form states
  const [gradeMarks, setGradeMarks] = useState('18');
  const [gradeFeedback, setGradeFeedback] = useState('Strong execution of algorithm test cases.');

  const showNotification = (msg: string) => {
    setNotice(msg);
    setTimeout(() => setNotice(''), 3500);
  };

  const handleSaveCourse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCode.trim() || !newName.trim()) return;

    onCreateCourse({
      code: newCode.trim().toUpperCase(),
      name: newName.trim(),
      description: newDesc.trim() || 'Comprehensive theoretical and practical coursework.',
      teacherId: currentUser.id,
      teacherName: currentUser.name,
      enrolledCount: 0, // Starts at 0 until students enroll
      materialsCount: 1,
      assignmentsCount: 1,
      isActive: true
    });

    showNotification(`✓ Successfully created course "${newName}" (${newCode.toUpperCase()})!`);
    setNewCode('');
    setNewName('');
    setNewDesc('');
    setShowCreateModal(false);
  };

  const handleOpenManageModal = (course: Course) => {
    setManagingCourse(course);
    setEditCode(course.code);
    setEditName(course.name);
    setEditDesc(course.description || '');
  };

  const handleUpdateCourseDetails = (e: React.FormEvent) => {
    e.preventDefault();
    if (!managingCourse || !onUpdateCourse) return;

    const currentLiveEnrollmentCount = enrollments.filter(e => e.courseId === managingCourse.id).length;

    const updated: Course = {
      ...managingCourse,
      code: editCode.trim().toUpperCase(),
      name: editName.trim(),
      description: editDesc.trim(),
      enrolledCount: currentLiveEnrollmentCount
    };

    onUpdateCourse(updated);
    showNotification(`✓ Course details for "${updated.name}" updated successfully!`);
    setManagingCourse(null);
  };

  const handleDeleteCourseClick = () => {
    if (!managingCourse || !onDeleteCourse) return;
    if (window.confirm(`Are you sure you want to delete "${managingCourse.name}"?`)) {
      onDeleteCourse(managingCourse.id);
      showNotification(`Removed course "${managingCourse.name}".`);
      setManagingCourse(null);
    }
  };

  const handleSaveGrade = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSubForGrading) return;
    onGradeSubmission(selectedSubForGrading.id, Number(gradeMarks), gradeFeedback);
    showNotification(`✓ Evaluation saved for ${selectedSubForGrading.studentName}!`);
    setSelectedSubForGrading(null);
  };

  // Computations
  const totalStudentsEnrolled = enrollments.length > 0
    ? new Set(enrollments.map(e => e.studentId)).size
    : courses.reduce((acc, c) => acc + (c.enrolledCount || 0), 0);
  const totalAssignments = courses.reduce((acc, c) => acc + (c.assignmentsCount || 1), 0);
  const totalSubmissions = submissions.length;

  // Active enrolled students for the course being managed
  const activeEnrolledStudents = managingCourse
    ? users.filter(u => enrollments.some(e => e.courseId === managingCourse.id && e.studentId === u.id))
    : [];

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      {/* Welcome Title */}
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold text-[#172033]">
          Welcome, {currentUser.name}!
        </h1>
        <p className="text-sm text-slate-500 font-medium">Faculty Course Hub & Academic Management</p>
      </div>

      {notice && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
          <span>{notice}</span>
        </div>
      )}

      {/* 4 Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-xl">
            <BookOpen size={24} />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900">{courses.length}</div>
            <div className="text-xs font-medium text-slate-500">Active Courses</div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-xl">
            <Users size={24} />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900">{totalStudentsEnrolled}</div>
            <div className="text-xs font-medium text-slate-500">Enrolled Students (Live)</div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-500 flex items-center justify-center font-bold text-xl">
            <FileText size={24} />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900">{totalAssignments}</div>
            <div className="text-xs font-medium text-slate-500">Active Assignments</div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-500 flex items-center justify-center font-bold text-xl">
            <CheckSquare size={24} />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900">{totalSubmissions}</div>
            <div className="text-xs font-medium text-slate-500">Total Submissions</div>
          </div>
        </div>
      </div>

      {/* Main Two Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column: My Courses */}
        <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden flex flex-col">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-[#172033]">My Courses</h2>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                {courses.length}
              </span>
            </div>
            <button
              type="button"
              onClick={() => setShowCreateModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
            >
              <Plus size={14} />
              <span>Create Course</span>
            </button>
          </div>

          <div className="p-5 space-y-3 overflow-y-auto max-h-[380px]">
            {courses.length === 0 ? (
              <div className="py-8 text-center text-slate-400 text-xs">
                No courses available. Click "Create Course" to add your first course.
              </div>
            ) : (
              courses.map(course => {
                const liveCount = enrollments.filter(e => e.courseId === course.id).length;

                return (
                  <div
                    key={course.id}
                    className="flex items-center justify-between p-4 rounded-xl border border-slate-100 hover:border-blue-200 hover:bg-slate-50/70 transition-all"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-bold text-[10px]">
                          {course.code}
                        </span>
                        <h3 className="font-bold text-sm text-slate-900">{course.name}</h3>
                      </div>
                      <p className="text-xs text-slate-500 flex items-center gap-3">
                        <span className="font-semibold text-slate-700">
                          {liveCount} {liveCount === 1 ? 'student' : 'students'} enrolled
                        </span>
                        <span>•</span>
                        <span>{course.materialsCount || 1} materials</span>
                        <span>•</span>
                        <span>{course.assignmentsCount || 1} assignments</span>
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleOpenManageModal(course)}
                      className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer shrink-0"
                      title="Edit Course Name, Code & Description"
                    >
                      <Settings size={13} />
                      <span>Manage</span>
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Column: Recent Submissions */}
        <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden flex flex-col">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <h2 className="text-base font-bold text-[#172033]">Recent Submissions</h2>
            <button
              type="button"
              onClick={() => onNavigate?.('view_submissions')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800 cursor-pointer flex items-center gap-1"
            >
              <span>View All</span>
              <ArrowRight size={13} />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/60 text-[11px] font-bold uppercase text-slate-500 tracking-wider">
                  <th className="py-3 px-5">Student</th>
                  <th className="py-3 px-4">Assignment</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {submissions.slice(0, 5).map(sub => (
                  <tr key={sub.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3.5 px-5 font-semibold text-slate-900">
                      {sub.studentName}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600">
                      {sub.assignmentTitle}
                    </td>
                    <td className="py-3.5 px-4">
                      {sub.status === 'Submitted' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200/60">
                          <CheckCircle2 size={11} /> Submitted
                        </span>
                      )}
                      {sub.status === 'Graded' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-bold bg-blue-50 text-blue-700 border border-blue-200/60">
                          <Award size={11} /> Graded ({sub.marks}/20)
                        </span>
                      )}
                      {sub.status === 'Pending' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-bold bg-amber-50 text-amber-700 border border-amber-200/60">
                          <Clock size={11} /> Pending
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <button
                        type="button"
                        onClick={() => setSelectedSubForGrading(sub)}
                        className="px-2.5 py-1 text-xs font-semibold rounded bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
                      >
                        {sub.status === 'Graded' ? 'Review' : 'Grade'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Create Course Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleSaveCourse}
            className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <BookOpen size={20} className="text-blue-600" />
                <h3 className="text-lg font-bold text-slate-900">Create New Course</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            <div className="space-y-3 mb-6">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Course Code *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. CS305"
                  value={newCode}
                  onChange={e => setNewCode(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Course Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Advanced Operating Systems"
                  value={newName}
                  onChange={e => setNewName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Syllabus Overview & Description</label>
                <textarea
                  rows={3}
                  placeholder="Core curriculum topics and lab requirements..."
                  value={newDesc}
                  onChange={e => setNewDesc(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600 resize-none"
                />
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-500">
                💡 <strong>Enrollment note:</strong> Once created, this course becomes available in the student catalog. Student enrollment counts will increment automatically as students register.
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm cursor-pointer"
              >
                Create Course
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Course Management Modal */}
      {managingCourse && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 space-y-5">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                  <Settings size={18} />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">Manage Course: {managingCourse.name}</h3>
                  <p className="text-xs text-slate-500">{managingCourse.code} • Taught by {managingCourse.teacherName}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setManagingCourse(null)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Live Student Enrollment Indicator (Read-only, driven by student logins & registrations) */}
            <div className="p-3.5 bg-blue-50/80 rounded-xl border border-blue-200/80 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase text-blue-700 tracking-wider">
                  Live Student Enrollment
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                  ● Live Linked
                </span>
              </div>
              <div className="text-sm font-extrabold text-slate-900">
                {activeEnrolledStudents.length} {activeEnrolledStudents.length === 1 ? 'Student' : 'Students'} Currently Enrolled
              </div>
              <div className="text-xs text-slate-600">
                {activeEnrolledStudents.length > 0 ? (
                  <span>
                    Enrolled: <strong className="text-slate-800">{activeEnrolledStudents.map(s => s.name).join(', ')}</strong>
                  </span>
                ) : (
                  <span className="italic text-slate-400">No students enrolled yet. Students can register from their student dashboard or profile.</span>
                )}
              </div>
              <p className="text-[10px] text-slate-400 pt-0.5">
                * Note: Enrollment count updates automatically when students enroll or drop from their student portal.
              </p>
            </div>

            {/* Edit Course Form */}
            <form onSubmit={handleUpdateCourseDetails} className="space-y-3 pt-2">
              <span className="text-[11px] uppercase font-bold text-slate-400 block mb-1">Edit Course Information</span>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Course Code *</label>
                <input
                  type="text"
                  required
                  value={editCode}
                  onChange={e => setEditCode(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-mono focus:outline-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Course Name *</label>
                <input
                  type="text"
                  required
                  value={editName}
                  onChange={e => setEditName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Course Description & Syllabus</label>
                <textarea
                  rows={3}
                  value={editDesc}
                  onChange={e => setEditDesc(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600 resize-none"
                />
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={handleDeleteCourseClick}
                  className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-rose-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                >
                  <Trash2 size={14} />
                  <span>Delete Course</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setManagingCourse(null)}
                    className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-xs cursor-pointer"
                  >
                    Save Changes
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Grading Modal */}
      {selectedSubForGrading && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleSaveGrade}
            className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95"
          >
            <h3 className="text-lg font-bold text-slate-900 mb-1">
              Grade Submission: {selectedSubForGrading.studentName}
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Assignment: <span className="font-semibold text-slate-700">{selectedSubForGrading.assignmentTitle}</span> • File: {selectedSubForGrading.fileName}
            </p>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Marks Awarded (Out of 20)</label>
                <input
                  type="number"
                  min="0"
                  max="20"
                  required
                  value={gradeMarks}
                  onChange={e => setGradeMarks(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-blue-600"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Teacher Feedback</label>
                <textarea
                  rows={3}
                  required
                  value={gradeFeedback}
                  onChange={e => setGradeFeedback(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-blue-600"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setSelectedSubForGrading(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg shadow-sm cursor-pointer"
              >
                Save Grade & Feedback
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
