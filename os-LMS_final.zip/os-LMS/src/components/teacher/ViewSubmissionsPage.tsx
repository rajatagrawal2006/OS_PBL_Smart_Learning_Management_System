import React, { useState } from 'react';
import { FileCheck, Search, Download, Eye, Award, CheckCircle2, Filter, Clock, X, FileText } from 'lucide-react';
import { Course, Assignment, Submission, User } from '../../types';
import { getStoredFile } from '../../utils/fileBlobStorage';
import { generateAcademicPdfBlob } from '../../utils/pdfGenerator';

interface ViewSubmissionsPageProps {
  currentUser: User;
  courses: Course[];
  assignments: Assignment[];
  submissions: Submission[];
  onGradeSubmission: (submissionId: string, marks: number, feedback: string) => void;
}

export const ViewSubmissionsPage: React.FC<ViewSubmissionsPageProps> = ({
  currentUser,
  courses,
  assignments,
  submissions,
  onGradeSubmission
}) => {
  const [selectedCourseFilter, setSelectedCourseFilter] = useState('All');
  const [selectedAssignFilter, setSelectedAssignFilter] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [notice, setNotice] = useState('');

  // Grading Modal
  const [gradingSub, setGradingSub] = useState<Submission | null>(null);
  const [marksInput, setMarksInput] = useState<number>(18);
  const [feedbackInput, setFeedbackInput] = useState('');

  // Preview Modal
  const [previewSub, setPreviewSub] = useState<Submission | null>(null);

  const showNotification = (msg: string) => {
    setNotice(msg);
    setTimeout(() => setNotice(''), 3500);
  };

  // Filter Submissions
  const filteredSubmissions = submissions.filter(sub => {
    const matchCourse = selectedCourseFilter === 'All' || sub.courseName === selectedCourseFilter;
    const matchAssign = selectedAssignFilter === 'All' || sub.assignmentTitle === selectedAssignFilter;
    const matchSearch =
      sub.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sub.fileName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sub.assignmentTitle.toLowerCase().includes(searchTerm.toLowerCase());
    return matchCourse && matchAssign && matchSearch;
  });

  const handleOpenGradeModal = (sub: Submission) => {
    setGradingSub(sub);
    setMarksInput(sub.marks !== null && sub.marks !== undefined ? sub.marks : 18);
    setFeedbackInput(sub.feedback || 'Well-structured analysis and methodology.');
  };

  const handleSaveGrade = (e: React.FormEvent) => {
    e.preventDefault();
    if (!gradingSub) return;
    onGradeSubmission(gradingSub.id, Number(marksInput), feedbackInput.trim());
    showNotification(`✓ Graded ${gradingSub.studentName}'s submission: ${marksInput} marks awarded.`);
    setGradingSub(null);
  };

  const triggerDownload = async (sub: Submission) => {
    let blob: Blob | null = null;
    if (sub.id) {
      try {
        blob = await getStoredFile(sub.id);
      } catch (err) {
        blob = null;
      }
    }

    if (!blob) {
      blob = generateAcademicPdfBlob({
        title: sub.fileName,
        course: sub.courseName,
        author: sub.studentName,
        isSubmission: true,
        date: sub.submissionDate,
        fileSize: sub.fileSize,
        description: sub.feedback || 'Student solution report and source execution log.',
        grade: sub.marks || undefined
      });
    }

    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = sub.fileName.endsWith('.pdf') ? sub.fileName : `${sub.fileName}.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    showNotification(`✓ Downloaded ${sub.fileName} (${sub.fileSize})`);
  };

  // Stats
  const totalSubmissions = submissions.length;
  const gradedCount = submissions.filter(s => s.status === 'Graded').length;
  const pendingCount = totalSubmissions - gradedCount;

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#172033] flex items-center gap-2">
            <FileCheck size={24} className="text-blue-600" />
            <span>Student Submissions & Grading</span>
          </h1>
          <p className="text-sm text-slate-500 font-medium">
            Review submitted solution documents, evaluate student work, and publish feedback
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-700 text-xs font-bold border border-emerald-200">
            {gradedCount} Evaluated
          </span>
          <span className="px-3 py-1.5 rounded-lg bg-amber-50 text-amber-700 text-xs font-bold border border-amber-200">
            {pendingCount} Pending Review
          </span>
        </div>
      </div>

      {notice && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
          <span>{notice}</span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
            <Filter size={14} />
            <span>Filter By:</span>
          </div>

          <select
            value={selectedCourseFilter}
            onChange={e => {
              setSelectedCourseFilter(e.target.value);
              setSelectedAssignFilter('All');
            }}
            className="px-3 py-1.5 rounded-lg border border-slate-300 text-xs focus:outline-blue-600 bg-white font-medium"
          >
            <option value="All">All Courses</option>
            {courses.map(c => (
              <option key={c.id} value={c.name}>
                {c.name}
              </option>
            ))}
          </select>

          <select
            value={selectedAssignFilter}
            onChange={e => setSelectedAssignFilter(e.target.value)}
            className="px-3 py-1.5 rounded-lg border border-slate-300 text-xs focus:outline-blue-600 bg-white font-medium"
          >
            <option value="All">All Assignments</option>
            {assignments
              .filter(a => selectedCourseFilter === 'All' || a.courseName === selectedCourseFilter)
              .map(a => (
                <option key={a.id} value={a.title}>
                  {a.title}
                </option>
              ))}
          </select>
        </div>

        <div className="relative">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search by student or file..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="pl-9 pr-3 py-1.5 rounded-lg border border-slate-300 text-xs w-full md:w-64 focus:outline-blue-600"
          />
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 font-bold uppercase tracking-wider text-[11px]">
                <th className="py-3 px-5">Student</th>
                <th className="py-3 px-4">Assignment / Course</th>
                <th className="py-3 px-4">Submitted File</th>
                <th className="py-3 px-4">Submission Date</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Marks</th>
                <th className="py-3 px-5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredSubmissions.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-10 text-center text-slate-400 text-xs">
                    No submissions found matching the selected filters.
                  </td>
                </tr>
              ) : (
                filteredSubmissions.map(sub => (
                  <tr key={sub.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3.5 px-5">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-xs">
                          {sub.studentName.charAt(0)}
                        </div>
                        <div>
                          <div className="font-bold text-slate-900">{sub.studentName}</div>
                          <div className="text-[10px] text-slate-400">ID: {sub.studentId}</div>
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-800">{sub.assignmentTitle}</div>
                      <div className="text-[11px] text-slate-500">{sub.courseName}</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-1.5 font-mono text-slate-800 font-medium">
                        <FileText size={14} className="text-blue-500 shrink-0" />
                        <span className="truncate max-w-[160px]" title={sub.fileName}>
                          {sub.fileName}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-400">{sub.fileSize}</div>
                    </td>

                    <td className="py-3.5 px-4 font-mono text-slate-600 text-[11px]">
                      {sub.submissionDate}
                    </td>

                    <td className="py-3.5 px-4">
                      {sub.status === 'Graded' ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
                          <CheckCircle2 size={11} /> Graded
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
                          <Clock size={11} /> Pending
                        </span>
                      )}
                    </td>

                    <td className="py-3.5 px-4">
                      {sub.marks !== null && sub.marks !== undefined ? (
                        <div>
                          <span className="font-bold text-slate-900 text-sm">{sub.marks}</span>
                          <span className="text-slate-400 text-xs"> / 20</span>
                        </div>
                      ) : (
                        <span className="text-slate-400 italic">Not graded</span>
                      )}
                    </td>

                    <td className="py-3.5 px-5 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => setPreviewSub(sub)}
                          className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-blue-600 transition-colors cursor-pointer"
                          title="Preview Submission Details"
                        >
                          <Eye size={15} />
                        </button>

                        <button
                          type="button"
                          onClick={() => triggerDownload(sub)}
                          className="p-1.5 rounded hover:bg-emerald-50 text-slate-500 hover:text-emerald-600 transition-colors cursor-pointer"
                          title="Download Student File"
                        >
                          <Download size={15} />
                        </button>

                        <button
                          type="button"
                          onClick={() => handleOpenGradeModal(sub)}
                          className={`px-3 py-1 rounded text-xs font-bold transition-colors cursor-pointer ${
                            sub.status === 'Graded'
                              ? 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                              : 'bg-blue-600 hover:bg-blue-700 text-white shadow-xs'
                          }`}
                        >
                          {sub.status === 'Graded' ? 'Edit Grade' : 'Grade'}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Grade Submission Modal */}
      {gradingSub && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleSaveGrade}
            className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                  <Award size={18} />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">Grade Student Submission</h3>
                  <p className="text-xs text-slate-500">{gradingSub.studentName} • {gradingSub.assignmentTitle}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setGradingSub(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X size={18} />
              </button>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs mb-4 flex items-center justify-between">
              <div>
                <span className="font-semibold text-slate-700">Submitted File:</span>
                <span className="block font-mono text-slate-600 truncate max-w-[220px]">
                  {gradingSub.fileName}
                </span>
              </div>
              <button
                type="button"
                onClick={() => triggerDownload(gradingSub)}
                className="px-2.5 py-1 bg-white border border-slate-300 rounded text-xs font-semibold text-blue-600 hover:bg-blue-50"
              >
                Download
              </button>
            </div>

            <div className="space-y-4 mb-6">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-700">Marks Awarded (out of 20)</label>
                  <span className="text-xs font-bold text-blue-600">{marksInput} / 20</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="20"
                  value={marksInput}
                  onChange={e => setMarksInput(Number(e.target.value))}
                  className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Instructor Feedback & Review
                </label>
                <textarea
                  rows={3}
                  required
                  placeholder="Provide constructive feedback for the student..."
                  value={feedbackInput}
                  onChange={e => setFeedbackInput(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs focus:outline-blue-600 resize-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setGradingSub(null)}
                className="px-4 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs"
              >
                Save Evaluation
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Preview Modal */}
      {previewSub && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2">
                <FileText size={18} className="text-blue-600" />
                <h3 className="text-base font-bold text-slate-900">Submission Details</h3>
              </div>
              <button
                type="button"
                onClick={() => setPreviewSub(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X size={18} />
              </button>
            </div>

            <div className="space-y-3 text-xs mb-6">
              <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Student Name</span>
                  <span className="font-bold text-slate-800">{previewSub.studentName} ({previewSub.studentId})</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Course</span>
                  <span className="font-bold text-slate-800">{previewSub.courseName}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Assignment</span>
                  <span className="font-bold text-slate-800">{previewSub.assignmentTitle}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Submission Date</span>
                  <span className="font-mono text-slate-700">{previewSub.submissionDate}</span>
                </div>
              </div>

              <div>
                <span className="text-slate-500 font-bold block mb-1">File Information:</span>
                <div className="p-3 rounded-lg border border-slate-200 font-mono text-slate-700 flex items-center justify-between">
                  <span>{previewSub.fileName}</span>
                  <span className="text-slate-400">{previewSub.fileSize}</span>
                </div>
              </div>

              {previewSub.feedback && (
                <div>
                  <span className="text-slate-500 font-bold block mb-1">Instructor Feedback:</span>
                  <div className="p-3 rounded-lg bg-blue-50/50 border border-blue-100 text-slate-700">
                    {previewSub.feedback}
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => triggerDownload(previewSub)}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs"
              >
                <Download size={14} />
                <span>Download Original File</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
