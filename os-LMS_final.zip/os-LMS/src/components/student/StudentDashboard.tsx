import React, { useState } from 'react';
import { BookOpen, FileText, CheckCircle2, Award, Calendar, UploadCloud, Eye, Check } from 'lucide-react';
import { User, Course, Assignment, Submission } from '../../types';

interface StudentDashboardProps {
  currentUser: User;
  courses: Course[];
  assignments: Assignment[];
  submissions: Submission[];
  onSubmitAssignment: (assignmentId: string, fileName: string, fileBlob?: File | null) => void;
  onViewCourse: (course: Course) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  currentUser,
  courses,
  assignments,
  submissions,
  onSubmitAssignment,
  onViewCourse,
}) => {
  const [selectedAssignment, setSelectedAssignment] = useState<Assignment | null>(null);
  const [submitFileName, setSubmitFileName] = useState('');
  const [submitFileObject, setSubmitFileObject] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccessToast, setShowSuccessToast] = useState(false);

  // Computations scoped to the logged-in student
  const mySubmissions = submissions.filter(s => s.studentId === currentUser.id);
  const enrolledCoursesCount = courses.length;
  const submittedIds = new Set(mySubmissions.map(s => s.assignmentId));
  const pendingCount = assignments.filter(a => !submittedIds.has(a.id)).length;
  const submittedCount = mySubmissions.length;

  const gradedSubmissions = mySubmissions.filter(s => s.marks !== null && s.marks !== undefined);
  const avgGrade = gradedSubmissions.length > 0
    ? `${Math.round(gradedSubmissions.reduce((acc, s) => acc + ((s.marks || 0) / 20) * 100, 0) / gradedSubmissions.length)}%`
    : '82%';

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSubmitFileName(e.target.files[0].name);
      setSubmitFileObject(e.target.files[0]);
    }
  };

  const handleConfirmSubmit = () => {
    if (!selectedAssignment) return;
    const finalName = submitFileName || `${currentUser.username}_${selectedAssignment.title.replace(/\s+/g, '_')}.pdf`;
    setIsSubmitting(true);
    setTimeout(() => {
      onSubmitAssignment(selectedAssignment.id, finalName, submitFileObject);
      setIsSubmitting(false);
      setSelectedAssignment(null);
      setSubmitFileName('');
      setSubmitFileObject(null);
      setShowSuccessToast(true);
      setTimeout(() => setShowSuccessToast(false), 4000);
    }, 400);
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      {/* Toast Notification */}
      {showSuccessToast && (
        <div className="fixed top-20 right-8 z-50 bg-emerald-600 text-white px-5 py-3 rounded-xl shadow-xl flex items-center gap-3 animate-bounce">
          <CheckCircle2 size={20} />
          <div>
            <div className="font-bold text-sm">Assignment Submitted!</div>
            <div className="text-xs text-emerald-100">OS Simulator process spawned in Ready queue.</div>
          </div>
        </div>
      )}

      {/* Welcome Title */}
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold text-[#172033]">
          Welcome, {currentUser.name.split(' ')[0]}!
        </h1>
        <p className="text-sm text-slate-500 font-medium">Here is your learning progress</p>
      </div>

      {/* 4 Stat Cards matching Blueprint 1 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-xl">
            <BookOpen size={24} />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900">{enrolledCoursesCount}</div>
            <div className="text-xs font-medium text-slate-500">Enrolled Courses</div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-500 flex items-center justify-center font-bold text-xl">
            <FileText size={24} />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900">{pendingCount}</div>
            <div className="text-xs font-medium text-slate-500">Pending Assignments</div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-xl">
            <CheckCircle2 size={24} />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900">{submittedCount}</div>
            <div className="text-xs font-medium text-slate-500">Submitted Assignments</div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-500 flex items-center justify-center font-bold text-xl">
            <Award size={24} />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900">{avgGrade}</div>
            <div className="text-xs font-medium text-slate-500">Average Grade</div>
          </div>
        </div>
      </div>

      {/* Main Two Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column: My Courses */}
        <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <h2 className="text-base font-bold text-[#172033]">My Courses</h2>
            <button
              type="button"
              onClick={() => onViewCourse(courses[0])}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800"
            >
              View All
            </button>
          </div>

          <div className="p-5 space-y-3">
            {courses.map(course => (
              <div
                key={course.id}
                className="flex items-center justify-between p-3.5 rounded-lg border border-slate-100 hover:border-blue-200 hover:bg-slate-50/60 transition-all"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-sm shrink-0">
                    <BookOpen size={18} />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-slate-900">{course.name}</h3>
                    <p className="text-xs text-slate-500">{course.teacherName} • {course.materialsCount} Materials</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onViewCourse(course)}
                  className="px-3 py-1.5 rounded-md bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs transition-colors"
                >
                  View
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Upcoming Assignments */}
        <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <h2 className="text-base font-bold text-[#172033]">Upcoming Assignments</h2>
            <span className="text-xs font-medium text-slate-400">{assignments.length} total</span>
          </div>

          <div className="p-5 space-y-3">
            {assignments.map(assign => {
              const isSubmitted = mySubmissions.some(s => s.assignmentId === assign.id);
              const subObj = mySubmissions.find(s => s.assignmentId === assign.id);

              return (
                <div
                  key={assign.id}
                  className="flex items-center justify-between p-3.5 rounded-lg border border-slate-100 hover:border-slate-200 transition-all"
                >
                  <div className="flex items-center gap-3.5">
                    <div className="w-10 h-10 rounded-lg bg-rose-50 text-rose-500 flex items-center justify-center font-bold text-sm shrink-0">
                      <FileText size={18} />
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-slate-900">{assign.title}</h3>
                      <p className="text-xs text-slate-500 flex items-center gap-1.5">
                        <Calendar size={12} />
                        <span>Due: {assign.dueDate}</span>
                        <span>• {assign.courseName}</span>
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {isSubmitted ? (
                      <div className="flex items-center gap-2">
                        <div className="text-right">
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200/60">
                            <Check size={12} />
                            {subObj?.status || 'Submitted'}
                          </span>
                          <div className="text-[10px] text-slate-500 font-mono truncate max-w-[130px]" title={subObj?.fileName}>
                            {subObj?.fileName}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => setSelectedAssignment(assign)}
                          className="px-2.5 py-1 text-xs font-semibold rounded bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
                          title="Replace or upload a different file"
                        >
                          Re-upload
                        </button>
                      </div>
                    ) : (
                      <>
                        <span className="inline-flex items-center px-2 py-0.5 rounded-md text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200/60">
                          Pending
                        </span>
                        <button
                          type="button"
                          onClick={() => setSelectedAssignment(assign)}
                          className="px-3 py-1 rounded-md bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
                        >
                          Submit
                        </button>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Submission Modal */}
      {selectedAssignment && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <h3 className="text-lg font-bold text-slate-900 mb-1">
              Submit Assignment: {selectedAssignment.title}
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Course: <span className="font-semibold text-slate-700">{selectedAssignment.courseName}</span> • Max Marks: {selectedAssignment.maxMarks}
            </p>

            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 mb-4 text-xs text-slate-600">
              {selectedAssignment.description}
            </div>

            {/* File drop zone */}
            <div className="border-2 border-dashed border-slate-300 hover:border-blue-500 rounded-xl p-6 text-center cursor-pointer mb-4 transition-colors">
              <UploadCloud size={32} className="mx-auto text-blue-500 mb-2" />
              <label className="cursor-pointer block">
                <span className="text-sm font-semibold text-blue-600 hover:underline">
                  {submitFileName ? submitFileName : 'Click to browse a file'}
                </span>
                <span className="block text-xs text-slate-400 mt-1">PDF, DOCX, TXT (Max 15MB)</span>
                <input
                  type="file"
                  className="hidden"
                  onChange={handleFileSelect}
                  accept=".pdf,.docx,.txt"
                />
              </label>
            </div>

            {/* System OS note */}
            <div className="p-3 bg-blue-50 border border-blue-100 rounded-lg text-[11px] text-blue-700 mb-5">
              💡 <strong>OS Simulator Integration:</strong> Submitting this assignment will automatically record a system event and spawn a simulated I/O process in the OS Simulator ready queue.
            </div>

            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => { setSelectedAssignment(null); setSubmitFileName(''); }}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmSubmit}
                disabled={isSubmitting}
                className="px-4 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm"
              >
                {isSubmitting ? 'Uploading & Queuing OS Process...' : 'Confirm Submission'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
