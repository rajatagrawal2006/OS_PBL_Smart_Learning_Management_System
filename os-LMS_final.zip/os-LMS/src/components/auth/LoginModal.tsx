import React, { useState } from 'react';
import { User, Role } from '../../types';
import {
  GraduationCap,
  BookOpen,
  ShieldCheck,
  User as UserIcon,
  Lock,
  AlertCircle,
  UserPlus,
  LogIn,
  CheckCircle2
} from 'lucide-react';
import { hashPassword, verifyPassword } from '../../utils/crypto';

interface LoginModalProps {
  onLogin: (user: User) => void;
  onSignUp?: (userData: { name: string; username: string; password: string; role: Role }) => void;
  availableUsers: User[];
}

export const LoginModal: React.FC<LoginModalProps> = ({ onLogin, onSignUp, availableUsers }) => {
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [selectedRole, setSelectedRole] = useState<Role>('student');
  const [username, setUsername] = useState('rohan');
  const [password, setPassword] = useState('student123');
  const [error, setError] = useState('');
  const [successNotice, setSuccessNotice] = useState('');

  // Sign up minimal fields (least amount of details)
  const [signUpRole, setSignUpRole] = useState<'student' | 'teacher'>('student');
  const [signUpName, setSignUpName] = useState('');
  const [signUpUsername, setSignUpUsername] = useState('');
  const [signUpPassword, setSignUpPassword] = useState('');

  const handleRoleSelect = (role: Role) => {

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const targetUser = availableUsers.find(x => x.username.toLowerCase() === username.toLowerCase().trim());
    if (!targetUser) {
      setError('Invalid username or account not found.');
      return;
    }
    if (!targetUser.isActive) {
      setError('This account has been deactivated. Please contact an administrator.');
      return;
    }

    // Role check
    if (targetUser.role !== selectedRole) {
      setError(`Account '${targetUser.username}' is a ${targetUser.role.toUpperCase()} account, not ${selectedRole.toUpperCase()}. Switching role...`);
      setSelectedRole(targetUser.role);
      setTimeout(() => onLogin(targetUser), 500);
      return;
    }

    // If user has a passwordHash, verify with PBKDF2; otherwise allow standard default test passwords
    if (targetUser.passwordHash && targetUser.salt) {
      const isValid = await verifyPassword(password, targetUser.passwordHash, targetUser.salt);
      if (!isValid) {
        setError('Incorrect password. Please verify and try again.');
        return;
      }
    }

    onLogin(targetUser);
  };

  const handleSignUpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanUsername = signUpUsername.trim().toLowerCase();
    const cleanName = signUpName.trim();

    if (!cleanName || !cleanUsername || !signUpPassword) {
      setError('Please fill in all registration fields.');
      return;
    }

    if (cleanUsername.length < 3) {
      setError('Username must be at least 3 characters.');
      return;
    }

    if (signUpPassword.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }

    const existingUser = availableUsers.find(u => u.username.toLowerCase() === cleanUsername);
    if (existingUser) {
      setError(`Username '${cleanUsername}' is already taken. Please choose another.`);
      return;
    }

    if (onSignUp) {
      onSignUp({
        name: cleanName,
        username: cleanUsername,
        password: signUpPassword,
        role: signUpRole
      });
    } else {
      // Fallback local sign up
      const { hash, salt } = await hashPassword(signUpPassword);
      const newUser: User = {
        id: `U${100 + availableUsers.length + 1}`,
        name: cleanName,
        username: cleanUsername,
        role: signUpRole,
        email: `${cleanUsername}@smartlms.edu`,
        isActive: true,
        createdAt: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
        passwordHash: hash,
        salt
      };
      onLogin(newUser);
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F7FA] flex flex-col items-center justify-center p-4">
      {/* Brand Header */}
      <div className="text-center mb-6">
        <div className="w-14 h-14 bg-[#173B63] rounded-2xl mx-auto flex items-center justify-center text-white text-3xl font-bold shadow-lg mb-3 border border-white/20">
          🎓
        </div>
        <h1 className="text-3xl font-extrabold text-[#173B63] tracking-tight">Smart LMS</h1>
        <p className="text-sm text-slate-500 font-medium mt-1">
          Learning Management System with Operating System Architecture
        </p>
      </div>

      {/* Main Login / Sign Up Card */}
      <div className="bg-white rounded-2xl p-8 max-w-md w-full shadow-xl border border-slate-200 animate-in fade-in zoom-in-95">
        {/* Top Mode Switcher (Sign In vs Sign Up) */}
        <div className="flex items-center justify-between p-1 bg-slate-100 rounded-xl mb-6 border border-slate-200">
          <button
            type="button"
            onClick={() => {
              setAuthMode('login');
              setError('');
            }}
            className={`flex-1 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              authMode === 'login'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <LogIn size={15} />
            <span>Sign In</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setAuthMode('signup');
              setError('');
            }}
            className={`flex-1 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              authMode === 'signup'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <UserPlus size={15} />
            <span>Sign Up / Register</span>
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center gap-2">
            <AlertCircle size={16} className="shrink-0 text-rose-500" />
            <span>{error}</span>
          </div>
        )}

        {successNotice && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 size={16} className="shrink-0 text-emerald-600" />
            <span>{successNotice}</span>
          </div>
        )}

        {/* ===================== SIGN IN VIEW ===================== */}
        {authMode === 'login' && (
          <div>
            {/* Role Selector Tabs */}
            <div className="mb-5">
              <label className="block text-[11px] font-bold uppercase text-slate-400 tracking-wider mb-2 text-center">
                Select Profile Role
              </label>
              <div className="grid grid-cols-3 gap-2 bg-slate-100 p-1.5 rounded-xl border border-slate-200">
                <button
                  type="button"
                  onClick={() => handleRoleSelect('student')}
                  className={`flex flex-col items-center py-2 px-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    selectedRole === 'student'
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }`}
                >
                  <GraduationCap size={17} className="mb-1" />
                  <span>Student</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleRoleSelect('teacher')}
                  className={`flex flex-col items-center py-2 px-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    selectedRole === 'teacher'
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }`}
                >
                  <BookOpen size={17} className="mb-1" />
                  <span>Teacher</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleRoleSelect('admin')}
                  className={`flex flex-col items-center py-2 px-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    selectedRole === 'admin'
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }`}
                >
                  <ShieldCheck size={17} className="mb-1" />
                  <span>Admin</span>
                </button>
              </div>
            </div>

            {/* Standard Login Form */}
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Username
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <UserIcon size={16} />
                  </span>
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={e => setUsername(e.target.value)}
                    className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold text-slate-800 focus:outline-blue-600 focus:border-blue-600 shadow-2xs font-mono"
                    placeholder="Enter username"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Password
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Lock size={16} />
                  </span>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold text-slate-800 focus:outline-blue-600 focus:border-blue-600 shadow-2xs font-mono"
                    placeholder="Enter password"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-sm transition-all active:scale-[0.99] cursor-pointer"
              >
                Sign In as {selectedRole.charAt(0).toUpperCase() + selectedRole.slice(1)}
              </button>
            </form>

            {/* Prompt to register */}
            <div className="mt-5 pt-4 border-t border-slate-100 text-center">
              <span className="text-xs text-slate-500">New student or teacher? </span>
              <button
                type="button"
                onClick={() => setAuthMode('signup')}
                className="text-xs font-bold text-blue-600 hover:underline cursor-pointer"
              >
                Create an account
              </button>
            </div>
          </div>
        )}

        {/* ===================== SIGN UP VIEW ===================== */}
        {authMode === 'signup' && (
          <div>
            <div className="mb-4">
              <h3 className="text-base font-bold text-slate-900">Create New Profile</h3>
              <p className="text-xs text-slate-500">Enter minimal details to set up your account</p>
            </div>

            {/* Role Selector (Student or Teacher only) */}
            <div className="mb-4">
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Registering As *
              </label>
              <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1.5 rounded-xl border border-slate-200">
                <button
                  type="button"
                  onClick={() => setSignUpRole('student')}
                  className={`flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    signUpRole === 'student'
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <GraduationCap size={16} />
                  <span>Student Profile</span>
                </button>

                <button
                  type="button"
                  onClick={() => setSignUpRole('teacher')}
                  className={`flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    signUpRole === 'teacher'
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <BookOpen size={16} />
                  <span>Teacher Profile</span>
                </button>
              </div>
            </div>

            <form onSubmit={handleSignUpSubmit} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Full Legal Name *
                </label>
                <input
                  type="text"
                  required
                  value={signUpName}
                  onChange={e => setSignUpName(e.target.value)}
                  placeholder="e.g. Vikram Rao"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-800 focus:outline-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Username *
                </label>
                <input
                  type="text"
                  required
                  value={signUpUsername}
                  onChange={e => setSignUpUsername(e.target.value)}
                  placeholder="e.g. vikram"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-800 focus:outline-blue-600 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Password *
                </label>
                <input
                  type="password"
                  required
                  value={signUpPassword}
                  onChange={e => setSignUpPassword(e.target.value)}
                  placeholder="Min 6 characters"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-800 focus:outline-blue-600 font-mono"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm transition-all active:scale-[0.99] cursor-pointer flex items-center justify-center gap-1.5 mt-4"
              >
                <UserPlus size={15} />
                <span>Create {signUpRole === 'student' ? 'Student' : 'Teacher'} Profile & Sign In</span>
              </button>
            </form>

            <div className="mt-5 pt-4 border-t border-slate-100 text-center">
              <span className="text-xs text-slate-500">Already registered? </span>
              <button
                type="button"
                onClick={() => setAuthMode('login')}
                className="text-xs font-bold text-blue-600 hover:underline cursor-pointer"
              >
                Back to Sign In
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
