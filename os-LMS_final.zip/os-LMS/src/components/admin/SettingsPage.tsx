import React, { useState } from 'react';
import { Settings as SettingsIcon, Save, RotateCcw, Shield, HardDrive, Cpu, Database, CheckCircle2 } from 'lucide-react';

interface SettingsPageProps {
  onResetData: () => void;
  onClearLogs: () => void;
  onLogActivity: (act: string) => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({
  onResetData,
  onClearLogs,
  onLogActivity
}) => {
  const [defaultQuantum, setDefaultQuantum] = useState('2');
  const [defaultMemoryPool, setDefaultMemoryPool] = useState('1000');
  const [defaultMemoryAlgo, setDefaultMemoryAlgo] = useState<'First Fit' | 'Best Fit'>('First Fit');
  const [bufferSize, setBufferSize] = useState('5');
  const [sessionTimeout, setSessionTimeout] = useState('30');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedSuccess(true);
    onLogActivity(`System settings updated: Quantum=${defaultQuantum}ms, MemPool=${defaultMemoryPool}MB, BufferSize=${bufferSize}`);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleResetDataClick = () => {
    if (window.confirm('Reset all demo courses, users, and OS processes back to factory defaults?')) {
      onResetData();
      onLogActivity('System database reset to initial demonstration state');
    }
  };

  const handleClearLogsClick = () => {
    if (window.confirm('Clear all recorded system activity logs?')) {
      onClearLogs();
      onLogActivity('Activity log cleared by Administrator');
    }
  };

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-[#172033] flex items-center gap-2.5">
          <SettingsIcon size={24} className="text-blue-600" />
          <span>System Settings</span>
        </h1>
        <p className="text-sm text-slate-500 font-medium">
          Configure OS Simulator defaults, security preferences, and system storage maintenance
        </p>
      </div>

      {savedSuccess && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 size={16} className="text-emerald-600" />
          <span>Settings saved successfully and applied to active session!</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-6">
        {/* Section 1: OS Simulator Tuning */}
        <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs p-6 space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <Cpu size={18} className="text-blue-600" />
            <h2 className="text-base font-bold text-slate-900">OS Simulator Configuration</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Default Round Robin Time Quantum (ms)
              </label>
              <input
                type="number"
                min="1"
                max="20"
                value={defaultQuantum}
                onChange={e => setDefaultQuantum(e.target.value)}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm font-semibold focus:outline-blue-600"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                Time slice assigned per process before CPU preemption occurs.
              </span>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Default Memory Allocation Strategy
              </label>
              <select
                value={defaultMemoryAlgo}
                onChange={e => setDefaultMemoryAlgo(e.target.value as any)}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm font-semibold focus:outline-blue-600 bg-white"
              >
                <option value="First Fit">First Fit (First block large enough)</option>
                <option value="Best Fit">Best Fit (Smallest block that fits)</option>
              </select>
              <span className="text-[11px] text-slate-400 mt-1 block">
                Initial algorithm selected when opening Memory Management.
              </span>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Simulated RAM Pool Size (MB)
              </label>
              <input
                type="number"
                min="500"
                max="4000"
                step="100"
                value={defaultMemoryPool}
                onChange={e => setDefaultMemoryPool(e.target.value)}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm font-semibold focus:outline-blue-600"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                Total contiguous virtual memory capacity (Blueprint standard is 1000 MB).
              </span>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Producer-Consumer Buffer Capacity (Slots)
              </label>
              <input
                type="number"
                min="3"
                max="10"
                value={bufferSize}
                onChange={e => setBufferSize(e.target.value)}
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm font-semibold focus:outline-blue-600"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                Bounded buffer slots in synchronization lab (Blueprint uses 5).
              </span>
            </div>
          </div>
        </div>

        {/* Section 2: Security & Authentication */}
        <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs p-6 space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <Shield size={18} className="text-emerald-600" />
            <h2 className="text-base font-bold text-slate-900">Security & Authentication</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs text-slate-600">
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="font-bold text-slate-800 block text-sm">PBKDF2-HMAC-SHA256</span>
              <p>Cryptographic password hashing algorithm enforced across all user logins.</p>
              <div className="text-[11px] font-mono text-emerald-700 mt-2 font-bold">
                ✓ 100,000 iterations • 16-byte random salt
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="font-bold text-slate-800 block text-sm">Role-Based Access Control</span>
              <p>Student, Teacher, and Administrator access boundary enforcement.</p>
              <div className="text-[11px] font-mono text-blue-700 mt-2 font-bold">
                ✓ Zero cross-role privilege leakage
              </div>
            </div>
          </div>
        </div>

        {/* Section 3: Data Storage & Maintenance */}
        <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs p-6 space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <Database size={18} className="text-indigo-600" />
            <h2 className="text-base font-bold text-slate-900">Storage & Maintenance</h2>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800">Database Reset & Cleanup</h3>
              <p className="text-xs text-slate-500">
                Restore default demo records (Rohan, Dr. Sharma, Operating Systems, P101–P104)
              </p>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={handleClearLogsClick}
                className="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors"
              >
                Clear Activity Logs
              </button>

              <button
                type="button"
                onClick={handleResetDataClick}
                className="px-4 py-2 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold text-xs transition-colors"
              >
                Reset Demo Data
              </button>
            </div>
          </div>
        </div>

        {/* Save Bar */}
        <div className="flex justify-end">
          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md transition-all active:scale-[0.99] cursor-pointer"
          >
            <Save size={16} />
            <span>Save Settings</span>
          </button>
        </div>
      </form>
    </div>
  );
};
