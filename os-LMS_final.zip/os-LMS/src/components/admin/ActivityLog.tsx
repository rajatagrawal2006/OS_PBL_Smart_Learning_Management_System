import React from 'react';
import { Activity, Clock } from 'lucide-react';
import { ActivityEntry } from '../../types';

export const ActivityLog: React.FC<{ logs: ActivityEntry[] }> = ({ logs }) => {
  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-[#172033]">System Activity Log</h1>
        <p className="text-sm text-slate-500 font-medium">Audit trail of LMS events and OS Simulator operations</p>
      </div>

      <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/80 text-[11px] font-bold uppercase text-slate-500 tracking-wider">
                <th className="py-3 px-5">Timestamp</th>
                <th className="py-3 px-4">User</th>
                <th className="py-3 px-4">Activity</th>
                <th className="py-3 px-5">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {logs.map(log => (
                <tr key={log.id} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-3.5 px-5 font-mono text-slate-500 flex items-center gap-1.5">
                    <Clock size={12} className="text-slate-400" />
                    <span>{log.timestamp}</span>
                  </td>
                  <td className="py-3.5 px-4 font-bold text-slate-900">
                    {log.user}
                  </td>
                  <td className="py-3.5 px-4 font-semibold text-blue-600">
                    {log.activity}
                  </td>
                  <td className="py-3.5 px-5 text-slate-500">
                    {log.details || '-'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
