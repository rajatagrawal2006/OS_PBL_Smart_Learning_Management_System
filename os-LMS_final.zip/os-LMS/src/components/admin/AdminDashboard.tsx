import React from 'react';
import { Users, BookOpen, FileText, UserCheck, Activity, ArrowRight, UserPlus, FolderPlus, Cpu, HardDrive } from 'lucide-react';
import { ActivityEntry } from '../../types';

interface AdminDashboardProps {
  activityLogs: ActivityEntry[];
  onNavigate: (page: string) => void;
  onOpenAddUser: () => void;
  onOpenAddCourse: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  activityLogs,
  onNavigate,
  onOpenAddUser,
  onOpenAddCourse
}) => {
  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      {/* Welcome Title */}
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold text-[#172033]">
          Welcome, Admin!
        </h1>
        <p className="text-sm text-slate-500 font-medium">System Overview</p>
      </div>

      {/* 4 Stat Cards matching Blueprint 3 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-xl">
            <Users size={24} />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900">45</div>
            <div className="text-xs font-medium text-slate-500">Total Students</div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-xl">
            <UserCheck size={24} />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900">6</div>
            <div className="text-xs font-medium text-slate-500">Total Teachers</div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-500 flex items-center justify-center font-bold text-xl">
            <BookOpen size={24} />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900">8</div>
            <div className="text-xs font-medium text-slate-500">Total Courses</div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-500 flex items-center justify-center font-bold text-xl">
            <FileText size={24} />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900">24</div>
            <div className="text-xs font-medium text-slate-500">Total Assignments</div>
          </div>
        </div>
      </div>

      {/* Main Split Section: Activity on Left, Quick Actions on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Recent System Activity */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <h2 className="text-base font-bold text-[#172033] flex items-center gap-2">
              <Activity size={18} className="text-blue-600" />
              Recent System Activity
            </h2>
            <button
              type="button"
              onClick={() => onNavigate('system_activity')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1"
            >
              <span>View All</span>
              <ArrowRight size={13} />
            </button>
          </div>

          <div className="p-5 space-y-3.5">
            {activityLogs.slice(0, 5).map((log) => {
              const isUser = log.activity.toLowerCase().includes('user') || log.activity.toLowerCase().includes('registered');
              const isSubmit = log.activity.toLowerCase().includes('submit');
              const isMaterial = log.activity.toLowerCase().includes('material');
              const isProcess = log.activity.toLowerCase().includes('process');

              return (
                <div
                  key={log.id}
                  className="flex items-start gap-3.5 p-3 rounded-lg border border-slate-100 hover:bg-slate-50/70 transition-colors"
                >
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center font-bold text-sm shrink-0 mt-0.5 ${
                    isProcess ? 'bg-indigo-50 text-indigo-600' :
                    isUser ? 'bg-emerald-50 text-emerald-600' :
                    isSubmit ? 'bg-blue-50 text-blue-600' : 'bg-amber-50 text-amber-600'
                  }`}>
                    {isProcess ? '⚙️' : isUser ? '👤' : isSubmit ? '📝' : '📄'}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-xs font-bold text-slate-900 truncate">
                        {log.activity}
                      </p>
                      <span className="text-[11px] font-medium text-slate-400 shrink-0">
                        {log.timestamp}
                      </span>
                    </div>
                    {log.details && (
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        {log.details}
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 1 Col: Quick Actions */}
        <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs p-5 flex flex-col justify-between">
          <div>
            <h2 className="text-base font-bold text-[#172033] mb-4">Quick Actions</h2>
            <div className="space-y-3">
              <button
                type="button"
                onClick={onOpenAddUser}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm transition-all active:scale-[0.99]"
              >
                <UserPlus size={16} />
                <span>Add New User</span>
              </button>

              <button
                type="button"
                onClick={onOpenAddCourse}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm transition-all active:scale-[0.99]"
              >
                <FolderPlus size={16} />
                <span>Add New Course</span>
              </button>

              <button
                type="button"
                onClick={() => onNavigate('system_activity')}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm transition-all active:scale-[0.99]"
              >
                <Activity size={16} />
                <span>View System Activity</span>
              </button>

              <button
                type="button"
                onClick={() => onNavigate('process_management')}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-sm transition-all active:scale-[0.99]"
              >
                <Cpu size={16} />
                <span>Open OS Simulator</span>
              </button>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 bg-slate-50/60 p-3.5 rounded-xl text-xs text-slate-600">
            <span className="font-bold text-slate-800 block mb-1">💡 College Project Notice</span>
            All simulated processes and allocations are isolated from host OS hardware.
          </div>
        </div>
      </div>
    </div>
  );
};
