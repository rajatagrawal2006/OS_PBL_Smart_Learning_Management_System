import React, { useState, useMemo } from 'react';
import { Play, Plus, Trash2, Cpu, RotateCcw, CheckCircle2, Sparkles } from 'lucide-react';
import {
  calculateFCFS,
  calculateSJF,
  calculateSJFPreemptive,
  calculatePriority,
  calculateRoundRobin,
  ProcessInput
} from '../../../utils/osCalculations';
import { SchedulingResult } from '../../../types';

export const CpuScheduling: React.FC<{ onLogActivity?: (act: string) => void }> = ({ onLogActivity }) => {
  const [algorithm, setAlgorithm] = useState<'FCFS' | 'SJF' | 'SJF Preemptive' | 'Priority' | 'Round Robin'>('FCFS');
  const [quantum, setQuantum] = useState<number>(2);
  const [feedbackNotice, setFeedbackNotice] = useState<string>('FCFS Computed');

  // Input processes
  const [processes, setProcesses] = useState<ProcessInput[]>([
    { pid: 'P1', arrivalTime: 0, burstTime: 6, priority: 3 },
    { pid: 'P2', arrivalTime: 2, burstTime: 2, priority: 1 },
    { pid: 'P3', arrivalTime: 3, burstTime: 4, priority: 4 },
    { pid: 'P4', arrivalTime: 5, burstTime: 1, priority: 2 }
  ]);

  // Dynamic simulation computation
  const result: SchedulingResult = useMemo(() => {
    switch (algorithm) {
      case 'FCFS':
        return calculateFCFS(processes);
      case 'SJF':
        return calculateSJF(processes);
      case 'SJF Preemptive':
        return calculateSJFPreemptive(processes);
      case 'Priority':
        return calculatePriority(processes);
      case 'Round Robin':
        return calculateRoundRobin(processes, quantum);
      default:
        return calculateFCFS(processes);
    }
  }, [algorithm, processes, quantum]);

  const handleAlgorithmChange = (newAlgo: typeof algorithm) => {
    setAlgorithm(newAlgo);
    setFeedbackNotice(`Switched & Computed: ${newAlgo}`);
    if (onLogActivity) {
      onLogActivity(`Selected ${newAlgo} CPU scheduling`);
    }
    setTimeout(() => setFeedbackNotice(''), 3000);
  };

  const handleRunSimulation = () => {
    setFeedbackNotice(`✓ Recomputed: ${algorithm} (Avg WT: ${result.avgWaitingTime} ms)`);
    if (onLogActivity) {
      onLogActivity(`${algorithm} simulation re-run (Avg WT: ${result.avgWaitingTime}, Avg TAT: ${result.avgTurnaroundTime})`);
    }
    setTimeout(() => setFeedbackNotice(''), 3500);
  };

  const handleAddProcess = () => {
    const nextNum = processes.length + 1;
    setProcesses([
      ...processes,
      { pid: `P${nextNum}`, arrivalTime: nextNum - 1, burstTime: 3, priority: 2 }
    ]);
    setFeedbackNotice(`Added P${nextNum}`);
    setTimeout(() => setFeedbackNotice(''), 2500);
  };

  const handleRemoveProcess = (pid: string) => {
    if (processes.length <= 1) return;
    setProcesses(processes.filter(p => p.pid !== pid));
    setFeedbackNotice(`Removed ${pid}`);
    setTimeout(() => setFeedbackNotice(''), 2500);
  };

  const handleUpdateProcess = (pid: string, field: keyof ProcessInput, val: number) => {
    setProcesses(processes.map(p => {
      if (p.pid === pid) {
        return { ...p, [field]: Math.max(0, val) };
      }
      return p;
    }));
  };

  const loadDatasetDistinct = () => {
    setProcesses([
      { pid: 'P1', arrivalTime: 0, burstTime: 6, priority: 3 },
      { pid: 'P2', arrivalTime: 2, burstTime: 2, priority: 1 },
      { pid: 'P3', arrivalTime: 3, burstTime: 4, priority: 4 },
      { pid: 'P4', arrivalTime: 5, burstTime: 1, priority: 2 }
    ]);
    setFeedbackNotice('Loaded Distinct-Order Dataset (Shows dramatic differences across all 5 algorithms)');
    setTimeout(() => setFeedbackNotice(''), 3500);
  };

  const loadDatasetDefault = () => {
    setProcesses([
      { pid: 'P1', arrivalTime: 0, burstTime: 5, priority: 2 },
      { pid: 'P2', arrivalTime: 1, burstTime: 3, priority: 1 },
      { pid: 'P3', arrivalTime: 2, burstTime: 4, priority: 3 }
    ]);
    setFeedbackNotice('Loaded Blueprint Baseline Dataset (P1, P2, P3)');
    setTimeout(() => setFeedbackNotice(''), 3500);
  };

  const getProcessColor = (pid: string) => {
    switch (pid) {
      case 'P1':
        return { bg: 'bg-[#38BDF8]', text: 'text-slate-900', border: 'border-sky-400' };
      case 'P2':
        return { bg: 'bg-[#4ADE80]', text: 'text-slate-900', border: 'border-emerald-400' };
      case 'P3':
        return { bg: 'bg-[#F87171]', text: 'text-slate-900', border: 'border-rose-400' };
      case 'P4':
        return { bg: 'bg-[#FBBF24]', text: 'text-slate-900', border: 'border-amber-400' };
      case 'P5':
        return { bg: 'bg-[#A78BFA]', text: 'text-slate-900', border: 'border-purple-400' };
      case 'IDLE':
        return { bg: 'bg-slate-200', text: 'text-slate-500', border: 'border-slate-300' };
      default:
        return { bg: 'bg-blue-300', text: 'text-slate-900', border: 'border-blue-400' };
    }
  };

  const totalTime = result.timeline.length > 0 ? result.timeline[result.timeline.length - 1].end : 0;

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      {/* Title & Dataset Quick Switchers */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#172033] flex items-center gap-2">
            <Cpu size={24} className="text-blue-600" />
            <span>CPU Scheduling Simulator</span>
          </h1>
          <p className="text-sm text-slate-500 font-medium">
            Simulate and mathematically compute FCFS, SJF (Non-preemptive & Preemptive/SRTF), Priority, and Round Robin
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={loadDatasetDistinct}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 text-xs font-bold transition-colors cursor-pointer"
            title="Load sample dataset where every algorithm produces a visibly distinct order"
          >
            <Sparkles size={13} className="text-sky-600" />
            <span>Sample: Distinct Orders</span>
          </button>

          <button
            type="button"
            onClick={loadDatasetDefault}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
            title="Reset to 3-process baseline (P1, P2, P3)"
          >
            <RotateCcw size={13} />
            <span>Baseline (P1..P3)</span>
          </button>
        </div>
      </div>

      {feedbackNotice && (
        <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-blue-900 text-xs font-bold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 size={16} className="text-blue-600 shrink-0" />
          <span>{feedbackNotice}</span>
        </div>
      )}

      {/* Top Controls Bar */}
      <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Select Algorithm (5 Options)</label>
            <select
              value={algorithm}
              onChange={e => handleAlgorithmChange(e.target.value as any)}
              className="px-3.5 py-2 rounded-lg border-2 border-blue-500/50 text-sm font-bold text-slate-800 bg-white focus:outline-blue-600 shadow-2xs cursor-pointer"
            >
              <option value="FCFS">1. FCFS (First Come First Served)</option>
              <option value="SJF">2. SJF (Shortest Job First - Non Preemptive)</option>
              <option value="SJF Preemptive">3. SJF Preemptive (SRTF / Shortest Remaining Time First)</option>
              <option value="Priority">4. Priority Scheduling (Non Preemptive)</option>
              <option value="Round Robin">5. Round Robin (Time Slicing)</option>
            </select>
          </div>

          {algorithm === 'Round Robin' && (
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Time Quantum (ms)</label>
              <input
                type="number"
                min="1"
                max="10"
                value={quantum}
                onChange={e => setQuantum(Math.max(1, Number(e.target.value)))}
                className="w-24 px-3 py-2 rounded-lg border border-slate-300 text-sm font-semibold focus:outline-blue-600 shadow-2xs"
              />
            </div>
          )}
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={handleAddProcess}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors cursor-pointer"
          >
            <Plus size={14} />
            <span>Add Process</span>
          </button>

          <button
            type="button"
            onClick={handleRunSimulation}
            className="flex items-center gap-1.5 px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm transition-all active:scale-[0.99] cursor-pointer"
          >
            <Play size={14} fill="currentColor" />
            <span>Run Simulation</span>
          </button>
        </div>
      </div>

      {/* Main Split Layout: Left Input Table | Right Gantt & Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Editable Input Processes */}
        <div className="lg:col-span-5 bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h2 className="text-sm font-bold text-slate-900">Input Processes Table</h2>
            <span className="text-xs text-slate-500 font-medium">{processes.length} Processes</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold bg-slate-50/70">
                  <th className="py-2.5 px-3">PID</th>
                  <th className="py-2.5 px-3">Arrival (ms)</th>
                  <th className="py-2.5 px-3">Burst (ms)</th>
                  <th className="py-2.5 px-3">Priority</th>
                  <th className="py-2.5 px-2 text-right"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {processes.map(p => {
                  const color = getProcessColor(p.pid);
                  return (
                    <tr key={p.pid} className="hover:bg-slate-50/60">
                      <td className="py-2 px-3 font-bold text-slate-900">
                        <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold ${color.bg} ${color.text}`}>
                          {p.pid}
                        </span>
                      </td>
                      <td className="py-2 px-3">
                        <input
                          type="number"
                          min="0"
                          value={p.arrivalTime}
                          onChange={e => handleUpdateProcess(p.pid, 'arrivalTime', Number(e.target.value))}
                          className="w-16 px-2 py-1 rounded border border-slate-200 font-medium text-xs focus:outline-blue-600"
                        />
                      </td>
                      <td className="py-2 px-3">
                        <input
                          type="number"
                          min="1"
                          value={p.burstTime}
                          onChange={e => handleUpdateProcess(p.pid, 'burstTime', Number(e.target.value))}
                          className="w-16 px-2 py-1 rounded border border-slate-200 font-medium text-xs focus:outline-blue-600"
                        />
                      </td>
                      <td className="py-2 px-3">
                        <input
                          type="number"
                          min="1"
                          value={p.priority}
                          onChange={e => handleUpdateProcess(p.pid, 'priority', Number(e.target.value))}
                          className="w-16 px-2 py-1 rounded border border-slate-200 font-medium text-xs focus:outline-blue-600"
                          title="1 = Highest Priority"
                        />
                      </td>
                      <td className="py-2 px-2 text-right">
                        {processes.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemoveProcess(p.pid)}
                            className="p-1 rounded text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                            title="Delete Process"
                          >
                            <Trash2 size={13} />
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div className="text-[11px] text-slate-400 pt-1">
            * Edit arrival times or burst times above to test custom scenarios. Lower priority number indicates higher scheduling priority.
          </div>
        </div>

        {/* Right Column: Dynamic Gantt Chart & Computed Results */}
        <div className="lg:col-span-7 bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs space-y-5">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Active Simulation Results</h2>
              <span className="text-xs font-semibold text-blue-600">{result.algorithm}</span>
            </div>
            <div className="text-xs text-slate-500 font-mono">
              Total Duration: {totalTime} ms
            </div>
          </div>

          {/* Dynamic Gantt Chart */}
          <div>
            <div className="text-xs font-bold text-slate-700 mb-2">Gantt Chart (Timeline Progress)</div>
            {result.timeline.length > 0 ? (
              <div>
                <div className="flex h-12 w-full rounded-lg overflow-hidden border border-slate-300 shadow-inner">
                  {result.timeline.map((seg, idx) => {
                    const widthPercent = totalTime > 0 ? ((seg.end - seg.start) / totalTime) * 100 : 0;
                    const color = getProcessColor(seg.pid);
                    return (
                      <div
                        key={idx}
                        style={{ width: `${widthPercent}%` }}
                        className={`${color.bg} ${color.text} flex flex-col items-center justify-center border-r border-white/40 text-xs font-bold relative group`}
                        title={`${seg.pid}: ${seg.start}ms → ${seg.end}ms (Duration: ${seg.end - seg.start}ms)`}
                      >
                        <span>{seg.pid}</span>
                        <span className="text-[9px] opacity-80">{seg.end - seg.start}ms</span>
                      </div>
                    );
                  })}
                </div>

                {/* Time Tick Marks */}
                <div className="relative h-6 mt-1 text-[10px] font-mono text-slate-500">
                  <span className="absolute left-0">0</span>
                  {result.timeline.map((seg, idx) => {
                    const leftPercent = totalTime > 0 ? (seg.end / totalTime) * 100 : 0;
                    return (
                      <span
                        key={idx}
                        style={{ left: `${leftPercent}%` }}
                        className="absolute -translate-x-1/2"
                      >
                        {seg.end}
                      </span>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="h-12 bg-slate-100 rounded-lg flex items-center justify-center text-xs text-slate-400">
                No active processes to schedule
              </div>
            )}
          </div>

          {/* Execution Order & Metrics Cards */}
          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
            <div className="text-xs">
              <span className="font-bold text-slate-700">Execution Sequence: </span>
              <span className="font-mono font-bold text-blue-700">{result.executionOrder || 'None'}</span>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-2 border-t border-slate-200">
              <div className="p-2.5 rounded-lg bg-white border border-slate-200">
                <div className="text-[11px] font-medium text-slate-500">Average Waiting Time</div>
                <div className="text-lg font-extrabold text-slate-900 mt-0.5">
                  {result.avgWaitingTime} <span className="text-xs font-normal text-slate-500">ms</span>
                </div>
              </div>

              <div className="p-2.5 rounded-lg bg-white border border-slate-200">
                <div className="text-[11px] font-medium text-slate-500">Average Turnaround Time</div>
                <div className="text-lg font-extrabold text-slate-900 mt-0.5">
                  {result.avgTurnaroundTime} <span className="text-xs font-normal text-slate-500">ms</span>
                </div>
              </div>
            </div>
          </div>

          {/* Detailed Computed Metrics Table */}
          <div>
            <div className="text-xs font-bold text-slate-700 mb-2">Process Metrics Breakdown</div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 font-semibold bg-slate-50/70">
                    <th className="py-2 px-3">Process</th>
                    <th className="py-2 px-3">Arrival</th>
                    <th className="py-2 px-3">Burst</th>
                    <th className="py-2 px-3">Completion (CT)</th>
                    <th className="py-2 px-3">Turnaround (TAT)</th>
                    <th className="py-2 px-3">Waiting (WT)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  {result.details.map(d => (
                    <tr key={d.pid} className="hover:bg-slate-50/60">
                      <td className="py-2 px-3 font-bold text-slate-900">{d.pid}</td>
                      <td className="py-2 px-3 text-slate-600">{d.arrivalTime}</td>
                      <td className="py-2 px-3 text-slate-600">{d.burstTime}</td>
                      <td className="py-2 px-3 text-slate-800 font-semibold">{d.completionTime}</td>
                      <td className="py-2 px-3 text-blue-700 font-semibold">{d.turnaroundTime}</td>
                      <td className="py-2 px-3 text-emerald-700 font-semibold">{d.waitingTime}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
