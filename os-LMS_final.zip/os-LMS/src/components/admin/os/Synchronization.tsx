import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Plus, Minus, RefreshCw, ShieldCheck } from 'lucide-react';

export const Synchronization: React.FC<{ onLogActivity?: (act: string) => void }> = ({ onLogActivity }) => {
  const bufferSize = 5;
  const [buffer, setBuffer] = useState<string[]>(['A', 'B', 'C']); // Seeded matching blueprint 4.5
  const [producerLog, setProducerLog] = useState<string[]>([
    'Produced: A',
    'Produced: B',
    'Produced: C'
  ]);
  const [consumerLog, setConsumerLog] = useState<string[]>([
    'Consumed: A',
    'Consumed: B'
  ]);
  const [isRunning, setIsRunning] = useState(false);
  const [nextLetterCode, setNextLetterCode] = useState(ord('D'));

  function ord(char: string) {
    return char.charCodeAt(0);
  }

  const produceItem = () => {
    if (buffer.length >= bufferSize) {
      return false; // Buffer full
    }
    const item = String.fromCharCode(nextLetterCode);
    setNextLetterCode(prev => 65 + ((prev - 65 + 1) % 26));
    setBuffer(prev => [...prev, item]);
    setProducerLog(prev => [...prev, `Produced: ${item}`]);
    return true;
  };

  const consumeItem = () => {
    if (buffer.length === 0) {
      return false; // Buffer empty
    }
    const removed = buffer[0];
    setBuffer(prev => prev.slice(1));
    setConsumerLog(prev => [...prev, `Consumed: ${removed}`]);
    return true;
  };

  // Automated simulation loop
  useEffect(() => {
    if (!isRunning) return;

    let turn = 0;
    const interval = setInterval(() => {
      if (turn % 2 === 0) {
        produceItem();
      } else {
        consumeItem();
      }
      turn++;
    }, 1200);

    return () => clearInterval(interval);
  }, [isRunning, buffer, nextLetterCode]);

  const handleReset = () => {
    setIsRunning(false);
    setBuffer([]);
    setProducerLog([]);
    setConsumerLog([]);
    setNextLetterCode(ord('A'));
    if (onLogActivity) {
      onLogActivity('Producer-Consumer lab reset to empty state');
    }
  };

  const handleStart = () => {
    setIsRunning(true);
    if (onLogActivity) {
      onLogActivity('Producer-Consumer synchronization simulation started');
    }
  };

  const handlePause = () => {
    setIsRunning(false);
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#172033]">Producer – Consumer Problem</h1>
          <p className="text-sm text-slate-500 font-medium">Simulate synchronization using semaphore</p>
        </div>

        {/* Buttons matching Blueprint colors: Green, Yellow, Red */}
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={handleStart}
            disabled={isRunning}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg font-bold text-xs shadow-xs transition-colors ${
              isRunning
                ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                : 'bg-[#16A34A] hover:bg-emerald-700 text-white cursor-pointer'
            }`}
          >
            <Play size={14} fill="currentColor" />
            <span>Start Simulation</span>
          </button>

          <button
            type="button"
            onClick={handlePause}
            disabled={!isRunning}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg font-bold text-xs shadow-xs transition-colors ${
              !isRunning
                ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                : 'bg-[#F59E0B] hover:bg-amber-600 text-white cursor-pointer'
            }`}
          >
            <Pause size={14} fill="currentColor" />
            <span>Pause</span>
          </button>

          <button
            type="button"
            onClick={handleReset}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#EF4444] hover:bg-rose-700 text-white font-bold text-xs shadow-xs transition-colors"
          >
            <RotateCcw size={14} />
            <span>Reset</span>
          </button>
        </div>
      </div>

      {/* Manual Step buttons and Semaphores indicators */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-200/90 shadow-xs">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={produceItem}
            disabled={buffer.length >= bufferSize}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold text-xs border border-emerald-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Plus size={14} />
            <span>Step Produce</span>
          </button>

          <button
            type="button"
            onClick={consumeItem}
            disabled={buffer.length === 0}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-xs border border-blue-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Minus size={14} />
            <span>Step Consume</span>
          </button>
        </div>

        {/* Semaphore State Counters */}
        <div className="flex items-center gap-4 text-xs font-semibold">
          <span className="flex items-center gap-1 text-slate-600">
            <ShieldCheck size={14} className="text-blue-600" />
            Mutex: <strong className="text-slate-900">1 (Unlocked)</strong>
          </span>
          <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
            Empty Slots: {bufferSize - buffer.length}
          </span>
          <span className="text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
            Full Slots: {buffer.length}
          </span>
        </div>
      </div>

      {/* Buffer Card (Size: 5) matching Blueprint 4.5 */}
      <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs p-6">
        <h2 className="text-sm font-bold text-slate-900 mb-4">
          Buffer (Size: {bufferSize})
        </h2>

        {/* Visual Slots: [ A ] [ B ] [ C ] [   ] [   ] */}
        <div className="flex items-center gap-3">
          {Array.from({ length: bufferSize }).map((_, index) => {
            const isFilled = index < buffer.length;
            const itemValue = isFilled ? buffer[index] : '';

            return (
              <div
                key={index}
                className={`w-20 h-16 rounded-xl flex items-center justify-center font-extrabold text-xl shadow-xs transition-all duration-200 ${
                  isFilled
                    ? 'bg-[#93C5FD] text-[#1E3A8A] border-2 border-blue-400 scale-100 animate-in zoom-in-90'
                    : 'bg-slate-100 text-slate-300 border-2 border-dashed border-slate-300'
                }`}
              >
                {itemValue}
              </div>
            );
          })}
        </div>
      </div>

      {/* Split Logs matching Blueprint 4.5 */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Producer Log (Green Text) */}
        <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden flex flex-col h-64">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/60">
            <h3 className="text-sm font-bold text-slate-900">Producer Log</h3>
            <span className="text-[11px] font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              Producer Active
            </span>
          </div>
          <div className="flex-1 p-4 overflow-y-auto space-y-1.5 font-mono text-xs text-[#16A34A]">
            {producerLog.length === 0 ? (
              <span className="text-slate-400 italic">No items produced yet.</span>
            ) : (
              producerLog.map((log, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <span className="text-slate-300 select-none">▸</span>
                  <span>{log}</span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Consumer Log (Blue Text) */}
        <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden flex flex-col h-64">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/60">
            <h3 className="text-sm font-bold text-slate-900">Consumer Log</h3>
            <span className="text-[11px] font-semibold text-blue-600 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
              Consumer Active
            </span>
          </div>
          <div className="flex-1 p-4 overflow-y-auto space-y-1.5 font-mono text-xs text-[#2563EB]">
            {consumerLog.length === 0 ? (
              <span className="text-slate-400 italic">No items consumed yet.</span>
            ) : (
              consumerLog.map((log, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <span className="text-slate-300 select-none">▸</span>
                  <span>{log}</span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
