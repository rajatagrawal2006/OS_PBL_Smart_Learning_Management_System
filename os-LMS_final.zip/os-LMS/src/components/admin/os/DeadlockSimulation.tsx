import React, { useState, useMemo, useEffect, useRef } from 'react';
import { AlertTriangle, CheckCircle2, RefreshCw, Play, Zap, RotateCcw } from 'lucide-react';
import { detectDeadlockInGraph } from '../../../utils/osCalculations';

export const DeadlockSimulation: React.FC<{ onLogActivity?: (act: string) => void }> = ({ onLogActivity }) => {
  const processes = ['P1', 'P2', 'P3'];
  const resources = ['R1', 'R2', 'R3'];

  // Allocation matrix: Process holds Resource
  const [allocation, setAllocation] = useState<Record<string, Record<string, number>>>({
    P1: { R1: 1, R2: 0, R3: 0 },
    P2: { R1: 0, R2: 1, R3: 0 },
    P3: { R1: 0, R2: 0, R3: 1 }
  });

  // Request matrix: Process waits for Resource (3-way circular wait)
  const [request, setRequest] = useState<Record<string, Record<string, number>>>({
    P1: { R1: 0, R2: 1, R3: 0 },
    P2: { R1: 0, R2: 0, R3: 1 },
    P3: { R1: 1, R2: 0, R3: 0 }
  });

  // Available resources vector
  const [available, setAvailable] = useState<Record<string, number>>({
    R1: 0,
    R2: 0,
    R3: 0
  });

  // Interactive feedback toast
  const [detectionFeedback, setDetectionFeedback] = useState<string | null>(null);

  // Step-by-step simulation state
  const [simStepIndex, setSimStepIndex] = useState<number>(-1);
  const [activeProcess, setActiveProcess] = useState<string | null>(null);
  const [completedProcesses, setCompletedProcesses] = useState<string[]>([]);
  const simTimerRef = useRef<any>(null);

  // Detect deadlock dynamically
  const detectionResult = useMemo(() => {
    return detectDeadlockInGraph(processes, resources, allocation, request, available);
  }, [processes, resources, allocation, request, available]);

  // Clean up timer on unmount
  useEffect(() => {
    return () => {
      if (simTimerRef.current) clearTimeout(simTimerRef.current);
    };
  }, []);

  const stopSimulation = () => {
    if (simTimerRef.current) {
      clearTimeout(simTimerRef.current);
      simTimerRef.current = null;
    }
    setActiveProcess(null);
    setSimStepIndex(-1);
    setCompletedProcesses([]);
  };

  const loadDeadlockScenario = () => {
    stopSimulation();
    setAllocation({
      P1: { R1: 1, R2: 0, R3: 0 },
      P2: { R1: 0, R2: 1, R3: 0 },
      P3: { R1: 0, R2: 0, R3: 1 }
    });
    setRequest({
      P1: { R1: 0, R2: 1, R3: 0 },
      P2: { R1: 0, R2: 0, R3: 1 },
      P3: { R1: 1, R2: 0, R3: 0 }
    });
    setAvailable({
      R1: 0,
      R2: 0,
      R3: 0
    });
    setDetectionFeedback('Deadlock scenario loaded (P1→R2→P2→R3→P3→R1→P1)');
    setTimeout(() => setDetectionFeedback(null), 3000);
    if (onLogActivity) {
      onLogActivity('Deadlock circular wait scenario loaded (P1-R2-P2-R3-P3-R1)');
    }
  };

  const loadSafeScenario = () => {
    stopSimulation();
    setAllocation({
      P1: { R1: 0, R2: 1, R3: 0 },
      P2: { R1: 2, R2: 0, R3: 0 },
      P3: { R1: 0, R2: 0, R3: 2 }
    });
    setRequest({
      P1: { R1: 0, R2: 0, R3: 1 },
      P2: { R1: 0, R2: 1, R3: 0 },
      P3: { R1: 0, R2: 0, R3: 0 }
    });
    setAvailable({
      R1: 1,
      R2: 0,
      R3: 1
    });
    setDetectionFeedback('Safe state scenario loaded (Safe Sequence: P1→P2→P3 or P3→P1→P2)');
    setTimeout(() => setDetectionFeedback(null), 3000);
    if (onLogActivity) {
      onLogActivity('Safe state scenario loaded (No circular wait, Banker safe)');
    }
  };

  const resetScenario = () => {
    stopSimulation();
    setAllocation({
      P1: { R1: 0, R2: 0, R3: 0 },
      P2: { R1: 0, R2: 0, R3: 0 },
      P3: { R1: 0, R2: 0, R3: 0 }
    });
    setRequest({
      P1: { R1: 0, R2: 0, R3: 0 },
      P2: { R1: 0, R2: 0, R3: 0 },
      P3: { R1: 0, R2: 0, R3: 0 }
    });
    setAvailable({
      R1: 1,
      R2: 1,
      R3: 1
    });
    setDetectionFeedback('Matrix reset to blank for custom experimentation');
    setTimeout(() => setDetectionFeedback(null), 3000);
  };

  const handleRunDetection = () => {
    stopSimulation();
    const isDl = detectionResult.hasDeadlock;
    const msg = isDl
      ? `Detection complete: Deadlock Detected! Cycle: ${detectionResult.cycleString}`
      : `Detection complete: Safe State! Sequence: ${detectionResult.safeSequence.join(' → ')}`;
    setDetectionFeedback(msg);
    setTimeout(() => setDetectionFeedback(null), 4000);
    if (onLogActivity) {
      onLogActivity(`Deadlock detection manual run: ${isDl ? 'Deadlock Detected' : 'Safe State'}`);
    }
  };

  const handleStartStepSimulation = () => {
    stopSimulation();
    const seq = detectionResult.safeSequence;
    if (seq.length === 0) {
      setDetectionFeedback('Cannot simulate safe steps: System is deadlocked or has no safe sequence.');
      setTimeout(() => setDetectionFeedback(null), 3500);
      return;
    }

    setDetectionFeedback('Starting step-by-step process execution...');
    let currentIdx = 0;
    const doneList: string[] = [];

    const runStep = () => {
      if (currentIdx < seq.length) {
        const proc = seq[currentIdx];
        setActiveProcess(proc);
        setSimStepIndex(currentIdx);

        simTimerRef.current = setTimeout(() => {
          doneList.push(proc);
          setCompletedProcesses([...doneList]);
          setActiveProcess(null);
          currentIdx++;
          simTimerRef.current = setTimeout(runStep, 600);
        }, 900);
      } else {
        setDetectionFeedback('Simulation complete: All processes safely satisfied and completed!');
        setTimeout(() => setDetectionFeedback(null), 4000);
      }
    };

    runStep();
  };

  const handleUpdateAllocation = (p: string, r: string, val: number) => {
    setAllocation(prev => ({
      ...prev,
      [p]: { ...prev[p], [r]: Math.max(0, val) }
    }));
  };

  const handleUpdateRequest = (p: string, r: string, val: number) => {
    setRequest(prev => ({
      ...prev,
      [p]: { ...prev[p], [r]: Math.max(0, val) }
    }));
  };

  const handleUpdateAvailable = (r: string, val: number) => {
    setAvailable(prev => ({
      ...prev,
      [r]: Math.max(0, val)
    }));
  };

  // Node positions in clockwise circular layout (cx=160, cy=125, r=85)
  // Top: P1, Top-Right: R2, Bottom-Right: P2, Bottom: R3, Bottom-Left: P3, Top-Left: R1
  const nodeCoords: Record<string, { x: number; y: number }> = {
    P1: { x: 160, y: 40 },
    R2: { x: 245, y: 85 },
    P2: { x: 245, y: 170 },
    R3: { x: 160, y: 210 },
    P3: { x: 75, y: 170 },
    R1: { x: 75, y: 85 }
  };

  // Build cycle edge set
  const cycleEdgePairs = useMemo(() => {
    const pairs = new Set<string>();
    const cycle = detectionResult.cycleNodes;
    if (detectionResult.hasDeadlock && cycle.length >= 2) {
      for (let i = 0; i < cycle.length - 1; i++) {
        pairs.add(`${cycle[i]}->${cycle[i + 1]}`);
      }
    }
    return pairs;
  }, [detectionResult]);

  // Build all directed edges
  const dynamicEdges = useMemo(() => {
    const list: Array<{
      from: string;
      to: string;
      count: number;
      kind: 'allocation' | 'request';
      isCycle: boolean;
    }> = [];

    // Allocation: Resource -> Process
    processes.forEach(p => {
      resources.forEach(r => {
        const val = allocation[p]?.[r] || 0;
        if (val > 0) {
          list.push({
            from: r,
            to: p,
            count: val,
            kind: 'allocation',
            isCycle: cycleEdgePairs.has(`${r}->${p}`)
          });
        }
      });
    });

    // Request: Process -> Resource
    processes.forEach(p => {
      resources.forEach(r => {
        const val = request[p]?.[r] || 0;
        if (val > 0) {
          list.push({
            from: p,
            to: r,
            count: val,
            kind: 'request',
            isCycle: cycleEdgePairs.has(`${p}->${r}`)
          });
        }
      });
    });

    // Draw cycle edges last so they appear on top
    return list.sort((a, b) => (a.isCycle ? 1 : 0) - (b.isCycle ? 1 : 0));
  }, [processes, resources, allocation, request, cycleEdgePairs]);

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#172033]">Deadlock Simulation</h1>
          <p className="text-sm text-slate-500 font-medium">
            Interactive Resource Allocation Graph (RAG) & Banker's Safe State Simulation
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={loadSafeScenario}
            className="px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold text-xs border border-emerald-200 transition-colors shadow-2xs cursor-pointer"
          >
            🟢 Load Safe State
          </button>

          <button
            type="button"
            onClick={loadDeadlockScenario}
            className="px-3 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs border border-rose-200 transition-colors shadow-2xs cursor-pointer"
          >
            🔴 Load Deadlock State
          </button>

          <button
            type="button"
            onClick={resetScenario}
            className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs border border-slate-200 transition-colors shadow-2xs cursor-pointer"
            title="Reset matrix"
          >
            <RotateCcw size={13} className="inline mr-1" />
            Clear
          </button>

          <button
            type="button"
            onClick={handleStartStepSimulation}
            className="px-3.5 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-2xs cursor-pointer"
          >
            <Zap size={13} />
            Simulate Steps
          </button>

          <button
            type="button"
            onClick={handleRunDetection}
            className="px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-2xs cursor-pointer"
          >
            <Play size={13} />
            Run Detection
          </button>
        </div>
      </div>

      {/* Action Notification Toast Banner */}
      {detectionFeedback && (
        <div className="px-4 py-2.5 rounded-lg bg-slate-900 text-white text-xs font-semibold flex items-center justify-between shadow-md animate-fade-in">
          <span>{detectionFeedback}</span>
          <span className="text-[10px] text-slate-400">Live Feedback</span>
        </div>
      )}

      {/* Main Split: Tables on Left, Graph & Trace on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Resource Tables (Allocation, Request, Available) */}
        <div className="lg:col-span-7 space-y-5">
          {/* Resource Allocation Table */}
          <div className="bg-white rounded-xl border border-slate-200/90 shadow-2xs overflow-hidden">
            <div className="p-3.5 border-b border-slate-100 flex items-center justify-between bg-slate-50/60">
              <div>
                <h2 className="text-sm font-bold text-slate-900">Resource Allocation Table</h2>
                <p className="text-[11px] text-slate-500">Units currently held by each process</p>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-700">Held (R→P)</span>
            </div>

            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/40 text-[11px] font-bold uppercase text-slate-500">
                  <th className="py-2.5 px-5">Process</th>
                  {resources.map(r => (
                    <th key={r} className="py-2.5 px-4 text-center">{r}</th>
                  ))}
                  <th className="py-2.5 px-4 text-center">Total Held</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {processes.map(p => {
                  const total = resources.reduce((sum, r) => sum + (allocation[p]?.[r] || 0), 0);
                  const isDeadlocked = detectionResult.deadlockedProcesses.includes(p);
                  return (
                    <tr key={p} className={isDeadlocked ? 'bg-rose-50/40' : 'hover:bg-slate-50/50'}>
                      <td className="py-2 px-5 font-bold text-blue-600 flex items-center gap-1.5">
                        <span>{p}</span>
                        {isDeadlocked && <span className="text-[10px] text-rose-600 font-semibold">(Stalled)</span>}
                      </td>
                      {resources.map(r => (
                        <td key={r} className="py-2 px-4 text-center">
                          <input
                            type="number"
                            min="0"
                            max="9"
                            value={allocation[p]?.[r] ?? 0}
                            onChange={e => handleUpdateAllocation(p, r, Number(e.target.value))}
                            className="w-12 text-center py-1 rounded border border-slate-200 font-bold text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                          />
                        </td>
                      ))}
                      <td className="py-2 px-4 text-center font-bold text-slate-600">{total}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Resource Request Table */}
          <div className="bg-white rounded-xl border border-slate-200/90 shadow-2xs overflow-hidden">
            <div className="p-3.5 border-b border-slate-100 flex items-center justify-between bg-slate-50/60">
              <div>
                <h2 className="text-sm font-bold text-slate-900">Resource Request Table</h2>
                <p className="text-[11px] text-slate-500">Outstanding units waited for by processes</p>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-700">Waiting (P→R)</span>
            </div>

            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/40 text-[11px] font-bold uppercase text-slate-500">
                  <th className="py-2.5 px-5">Process</th>
                  {resources.map(r => (
                    <th key={r} className="py-2.5 px-4 text-center">{r}</th>
                  ))}
                  <th className="py-2.5 px-4 text-center">Total Requested</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {processes.map(p => {
                  const total = resources.reduce((sum, r) => sum + (request[p]?.[r] || 0), 0);
                  return (
                    <tr key={p} className="hover:bg-slate-50/50">
                      <td className="py-2 px-5 font-bold text-slate-800">{p}</td>
                      {resources.map(r => (
                        <td key={r} className="py-2 px-4 text-center">
                          <input
                            type="number"
                            min="0"
                            max="9"
                            value={request[p]?.[r] ?? 0}
                            onChange={e => handleUpdateRequest(p, r, Number(e.target.value))}
                            className="w-12 text-center py-1 rounded border border-slate-200 font-bold text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                          />
                        </td>
                      ))}
                      <td className="py-2 px-4 text-center font-bold text-slate-600">{total}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Available Resources Vector Pool */}
          <div className="bg-white rounded-xl border border-slate-200/90 shadow-2xs p-3.5 flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-900">Available Resources Vector (Work Pool)</h3>
              <p className="text-[11px] text-slate-500">Free unallocated resource units</p>
            </div>

            <div className="flex items-center gap-3">
              {resources.map(r => (
                <div key={r} className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 px-2.5 py-1 rounded-lg">
                  <span className="text-xs font-bold text-slate-700">{r}:</span>
                  <input
                    type="number"
                    min="0"
                    max="9"
                    value={available[r] ?? 0}
                    onChange={e => handleUpdateAvailable(r, Number(e.target.value))}
                    className="w-10 text-center font-bold text-xs bg-white rounded border border-slate-300 py-0.5 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Visual Resource Allocation Graph & Trace */}
        <div className="lg:col-span-5 flex flex-col gap-5">
          {/* Visual Directed Graph */}
          <div className="bg-white rounded-xl border border-slate-200/90 shadow-2xs p-4 flex flex-col">
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-sm font-bold text-slate-900">Resource Allocation Graph (RAG)</h2>
              <div className="flex items-center gap-3 text-[10px] font-semibold">
                <span className="flex items-center gap-1 text-emerald-600">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span> Held
                </span>
                <span className="flex items-center gap-1 text-blue-600">
                  <span className="w-2 h-2 rounded-full bg-blue-500"></span> Request
                </span>
                <span className="flex items-center gap-1 text-rose-600">
                  <span className="w-2 h-2 rounded-full bg-rose-500"></span> Cycle
                </span>
              </div>
            </div>

            {/* SVG Visual Directed Graph */}
            <div className="relative w-full h-64 bg-slate-50/70 rounded-xl border border-slate-100 flex items-center justify-center p-2">
              <svg className="w-full h-full" viewBox="0 0 320 250">
                <defs>
                  <marker id="arrowhead-blue" markerWidth="7" markerHeight="5" refX="6" refY="2.5" orient="auto">
                    <polygon points="0 0, 7 2.5, 0 5" fill="#3B82F6" />
                  </marker>
                  <marker id="arrowhead-green" markerWidth="7" markerHeight="5" refX="6" refY="2.5" orient="auto">
                    <polygon points="0 0, 7 2.5, 0 5" fill="#10B981" />
                  </marker>
                  <marker id="arrowhead-red" markerWidth="8" markerHeight="6" refX="7" refY="3" orient="auto">
                    <polygon points="0 0, 8 3, 0 6" fill="#EF4444" />
                  </marker>
                </defs>

                {/* Real Dynamic Edges */}
                {dynamicEdges.map((edge, idx) => {
                  const p1 = nodeCoords[edge.from];
                  const p2 = nodeCoords[edge.to];
                  if (!p1 || !p2) return null;

                  const dx = p2.x - p1.x;
                  const dy = p2.y - p1.y;
                  const dist = Math.hypot(dx, dy) || 1;
                  const nodeRadius = 18;
                  const sx = p1.x + (dx / dist) * nodeRadius;
                  const sy = p1.y + (dy / dist) * nodeRadius;
                  const ex = p2.x - (dx / dist) * (nodeRadius + 4);
                  const ey = p2.y - (dy / dist) * (nodeRadius + 4);

                  let strokeColor = '#3B82F6';
                  let marker = 'url(#arrowhead-blue)';
                  let strokeWidth = 1.5;

                  if (edge.isCycle) {
                    strokeColor = '#EF4444';
                    marker = 'url(#arrowhead-red)';
                    strokeWidth = 2.5;
                  } else if (edge.kind === 'allocation') {
                    strokeColor = '#10B981';
                    marker = 'url(#arrowhead-green)';
                    strokeWidth = 1.5;
                  }

                  const mx = (sx + ex) / 2;
                  const my = (sy + ey) / 2;

                  return (
                    <g key={`${edge.from}-${edge.to}-${idx}`}>
                      <line
                        x1={sx}
                        y1={sy}
                        x2={ex}
                        y2={ey}
                        stroke={strokeColor}
                        strokeWidth={strokeWidth}
                        markerEnd={marker}
                      />
                      {edge.count > 1 && (
                        <g>
                          <circle cx={mx} cy={my} r={7} fill="#FFFFFF" stroke={strokeColor} strokeWidth={1} />
                          <text x={mx} y={my + 3} textAnchor="middle" fontSize={8} fontWeight="bold" fill={strokeColor}>
                            {edge.count}
                          </text>
                        </g>
                      )}
                    </g>
                  );
                })}

                {/* Nodes rendering: Processes as Circles, Resources as Squares */}
                {Object.entries(nodeCoords).map(([name, pos]) => {
                  const isProc = name.startsWith('P');
                  const inCycle = detectionResult.hasDeadlock && detectionResult.cycleNodes.includes(name);
                  const isActive = activeProcess === name;
                  const isCompleted = completedProcesses.includes(name);

                  if (isProc) {
                    let fill = '#DBEAFE';
                    let stroke = '#3B82F6';
                    let textColor = '#1E3A8A';

                    if (isActive) {
                      fill = '#FEF08A';
                      stroke = '#CA8A04';
                      textColor = '#713F12';
                    } else if (isCompleted) {
                      fill = '#DCFCE7';
                      stroke = '#16A34A';
                      textColor = '#14532D';
                    } else if (inCycle) {
                      fill = '#FEE2E2';
                      stroke = '#EF4444';
                      textColor = '#991B1B';
                    }

                    return (
                      <g key={name}>
                        <circle
                          cx={pos.x}
                          cy={pos.y}
                          r={18}
                          fill={fill}
                          stroke={stroke}
                          strokeWidth={inCycle || isActive ? 2.5 : 1.5}
                        />
                        <text
                          x={pos.x}
                          y={pos.y + 4}
                          textAnchor="middle"
                          fontSize={10}
                          fontWeight="bold"
                          fill={textColor}
                        >
                          {name}
                        </text>
                      </g>
                    );
                  } else {
                    let fill = inCycle ? '#FFEDD5' : '#F1F5F9';
                    let stroke = inCycle ? '#EA580C' : '#64748B';
                    let textColor = inCycle ? '#9A3412' : '#334155';

                    return (
                      <g key={name}>
                        <rect
                          x={pos.x - 16}
                          y={pos.y - 16}
                          width={32}
                          height={32}
                          rx={5}
                          fill={fill}
                          stroke={stroke}
                          strokeWidth={inCycle ? 2 : 1.5}
                        />
                        <text
                          x={pos.x}
                          y={pos.y + 4}
                          textAnchor="middle"
                          fontSize={10}
                          fontWeight="bold"
                          fill={textColor}
                        >
                          {name}
                        </text>
                      </g>
                    );
                  }
                })}
              </svg>
            </div>
          </div>

          {/* Step Trace Log Box */}
          <div className="bg-slate-900 rounded-xl border border-slate-800 p-3.5 shadow-2xs flex-1 flex flex-col">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono font-bold text-slate-300">Simulation Trace Terminal</span>
              <span className="text-[10px] font-mono text-slate-400">Banker & RAG Evaluator</span>
            </div>
            <div className="font-mono text-[11px] text-slate-300 space-y-1 overflow-y-auto max-h-36 pr-1">
              {detectionResult.simulationSteps.map((step, idx) => (
                <div key={idx} className="leading-relaxed">
                  <span className="text-sky-400 mr-1.5">•</span>
                  {step}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Detection Result Banner */}
      <div
        className={`p-4 rounded-xl border flex items-center gap-3.5 shadow-2xs transition-all ${
          detectionResult.hasDeadlock
            ? 'bg-rose-50 border-rose-200 text-rose-900'
            : 'bg-emerald-50 border-emerald-200 text-emerald-900'
        }`}
      >
        {detectionResult.hasDeadlock ? (
          <AlertTriangle size={24} className="text-rose-600 shrink-0" />
        ) : (
          <CheckCircle2 size={24} className="text-emerald-600 shrink-0" />
        )}

        <div>
          <div className="font-extrabold text-sm flex items-center gap-2">
            {detectionResult.hasDeadlock ? 'Deadlock Detected! (Circular Wait)' : 'No Deadlock Detected (Safe State)'}
          </div>
          <div className="text-xs font-semibold mt-0.5 font-mono">
            {detectionResult.hasDeadlock
              ? `Cycle: ${detectionResult.cycleString} | Stalled processes cannot proceed.`
              : `Safe sequence: ${detectionResult.safeSequence.join(' → ')} | System can resolve all requests safely.`}
          </div>
        </div>
      </div>
    </div>
  );
};
