import React, { useState, useRef } from 'react';
import { Upload, Trash2, Eye, Download, FileText, CheckCircle2, AlertCircle, X, FileCheck, HardDrive, Search } from 'lucide-react';
import { Material, Submission } from '../../../types';
import { generateAcademicPdfBlob } from '../../../utils/pdfGenerator';
import { getStoredFile, saveStoredFile } from '../../../utils/fileBlobStorage';

interface FileManagementProps {
  materials: Material[];
  submissions: Submission[];
  onUploadMaterial: (mat: Partial<Material>, fileBlob?: File | null) => void;
  onDeleteMaterial: (id: string) => void;
  onDeleteSubmission: (id: string) => void;
}

export const FileManagement: React.FC<FileManagementProps> = ({
  materials,
  submissions,
  onUploadMaterial,
  onDeleteMaterial,
  onDeleteSubmission
}) => {
  const [activeTab, setActiveTab] = useState<'materials' | 'submissions'>('materials');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [previewItem, setPreviewItem] = useState<any | null>(null);
  const [notice, setNotice] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Upload Form
  const [fileName, setFileName] = useState('');
  const [fileType, setFileType] = useState('PDF');
  const [fileSize, setFileSize] = useState('2.4 MB');
  const [courseName, setCourseName] = useState('Operating Systems');
  const [description, setDescription] = useState('Supplementary OS lecture handouts and reference material.');
  const [selectedFileObject, setSelectedFileObject] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const showNotification = (msg: string) => {
    setNotice(msg);
    setTimeout(() => setNotice(''), 3500);
  };

  const toggleSelect = (id: string) => {
    setSelectedIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const toggleSelectAll = () => {
    const allIds = activeTab === 'materials' ? materials.map(m => m.id) : submissions.map(s => s.id);
    if (selectedIds.length === allIds.length && allIds.length > 0) {
      setSelectedIds([]);
    } else {
      setSelectedIds(allIds);
    }
  };

  // Real browser file download implementation
  const triggerDownload = async (item: any) => {
    let blob: Blob | null = null;
    const finalDownloadName = item.fileName || 'document.pdf';

    // 1. First check if user uploaded a real physical file into IndexedDB/Memory
    if (item.id) {
      try {
        blob = await getStoredFile(item.id);
      } catch (e) {
        blob = null;
      }
    }

    // 2. If no physical blob exists (seed sample item or uncaptured), generate authentic PDF
    if (!blob) {
      const isPdf = finalDownloadName.toLowerCase().endsWith('.pdf') || item.fileType === 'PDF' || !finalDownloadName.includes('.');
      if (isPdf) {
        blob = generateAcademicPdfBlob({
          title: item.fileName,
          course: item.courseName || item.assignmentTitle || 'Operating Systems (CS301)',
          author: item.uploadedBy || item.studentName || 'Smart LMS Faculty',
          isSubmission: Boolean(item.studentName),
          date: item.date || item.submissionDate,
          fileSize: item.fileSize,
          description: item.description || item.feedback,
          grade: item.marks
        });
      } else {
        const fileContent = [
          `=====================================================`,
          `Smart LMS — Local File Storage System`,
          `File: ${item.fileName}`,
          `Course: ${item.courseName || 'General'}`,
          `Size: ${item.fileSize || 'Standard'}`,
          item.uploadedBy ? `Instructor / Uploader: ${item.uploadedBy}` : `Student: ${item.studentName}`,
          `Timestamp: ${new Date().toLocaleString()}`,
          `=====================================================`,
          ``,
          item.description || item.feedback || `Official file asset managed under Smart LMS operating system file directory.`,
          ``,
          `--- End of Document Stream ---`
        ].join('\n');
        blob = new Blob([fileContent], { type: 'text/plain;charset=utf-8' });
      }
    }

    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = finalDownloadName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(url), 2000);

    showNotification(`✓ Downloaded original file: ${finalDownloadName}`);
  };

  const handleDeleteItem = (id: string, name: string) => {
    if (activeTab === 'materials') {
      onDeleteMaterial(id);
    } else {
      onDeleteSubmission(id);
    }
    setSelectedIds(prev => prev.filter(x => x !== id));
    showNotification(`Removed: ${name}`);
  };

  const handleDeleteSelected = () => {
    if (selectedIds.length === 0) return;
    const count = selectedIds.length;
    if (activeTab === 'materials') {
      selectedIds.forEach(id => onDeleteMaterial(id));
    } else {
      selectedIds.forEach(id => onDeleteSubmission(id));
    }
    setSelectedIds([]);
    showNotification(`Deleted ${count} selected item(s) from storage.`);
  };

  const handleLocalFilePicked = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFileObject(file);
      setFileName(file.name);
      const ext = file.name.split('.').pop()?.toUpperCase() || 'PDF';
      setFileType(['PDF', 'DOCX', 'PPTX', 'TXT', 'ZIP'].includes(ext) ? ext : 'PDF');
      const mb = (file.size / (1024 * 1024)).toFixed(1);
      setFileSize(`${mb === '0.0' ? '0.4' : mb} MB`);
    }
  };

  const handleConfirmUpload = (e: React.FormEvent) => {
    e.preventDefault();
    const finalName = fileName.trim() || 'New_Course_Material.pdf';
    onUploadMaterial(
      {
        title: finalName,
        fileName: finalName,
        fileType,
        fileSize,
        courseName,
        uploadedBy: 'Dr. Sharma',
        date: 'Today',
        description
      },
      selectedFileObject
    );
    setFileName('');
    setSelectedFileObject(null);
    setShowUploadModal(false);
    showNotification(`✓ Uploaded "${finalName}" to course storage`);
  };

  const filteredMaterials = materials.filter(m =>
    m.fileName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    m.courseName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    m.uploadedBy.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredSubmissions = submissions.filter(s =>
    s.fileName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.assignmentTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.courseName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const currentList = activeTab === 'materials' ? filteredMaterials : filteredSubmissions;
  const allSelected = currentList.length > 0 && selectedIds.length === currentList.length;

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#172033] flex items-center gap-2">
            <HardDrive size={24} className="text-blue-600" />
            <span>File Management</span>
          </h1>
          <p className="text-sm text-slate-500 font-medium">
            Manage course materials and student submissions stored in directory storage
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setShowUploadModal(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer"
          >
            <Upload size={14} />
            <span>Upload File</span>
          </button>

          <button
            type="button"
            onClick={handleDeleteSelected}
            disabled={selectedIds.length === 0}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-bold text-xs shadow-xs transition-colors ${
              selectedIds.length > 0
                ? 'bg-rose-600 hover:bg-rose-700 text-white cursor-pointer'
                : 'bg-slate-200 text-slate-400 cursor-not-allowed'
            }`}
          >
            <Trash2 size={14} />
            <span>Delete Selected ({selectedIds.length})</span>
          </button>
        </div>
      </div>

      {notice && (
        <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
          <span>{notice}</span>
        </div>
      )}

      {/* Tabs and Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-3">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => { setActiveTab('materials'); setSelectedIds([]); }}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-bold text-xs transition-all cursor-pointer ${
              activeTab === 'materials'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <FileText size={15} />
            <span>Course Materials ({materials.length})</span>
          </button>

          <button
            type="button"
            onClick={() => { setActiveTab('submissions'); setSelectedIds([]); }}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-bold text-xs transition-all cursor-pointer ${
              activeTab === 'submissions'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <FileCheck size={15} />
            <span>Student Submissions ({submissions.length})</span>
          </button>
        </div>

        {/* Live Search Input */}
        <div className="relative">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder={activeTab === 'materials' ? 'Search materials by name or course...' : 'Search submissions by file, student or course...'}
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="pl-9 pr-3 py-1.5 rounded-lg border border-slate-300 text-xs w-full sm:w-72 focus:outline-blue-600 bg-white"
          />
        </div>
      </div>

      {/* Main Table matching Blueprint 4.4 */}
      <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 font-bold uppercase tracking-wider text-[11px]">
                <th className="py-3 px-4 w-10 text-center">
                  <input
                    type="checkbox"
                    checked={allSelected}
                    onChange={toggleSelectAll}
                    className="rounded text-blue-600 focus:ring-0 cursor-pointer"
                    title="Select All"
                  />
                </th>
                <th className="py-3 px-4">File Name</th>
                <th className="py-3 px-3">Type</th>
                <th className="py-3 px-3">Size</th>
                <th className="py-3 px-4">{activeTab === 'materials' ? 'Uploaded By' : 'Student Name'}</th>
                <th className="py-3 px-4">Course / Assignment</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {activeTab === 'materials' && filteredMaterials.length === 0 && (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400">
                    {searchTerm ? `No materials matching "${searchTerm}".` : 'No course materials uploaded yet. Click "Upload File" to add files.'}
                  </td>
                </tr>
              )}

              {activeTab === 'materials' &&
                filteredMaterials.map(mat => (
                  <tr key={mat.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3.5 px-4 text-center">
                      <input
                        type="checkbox"
                        checked={selectedIds.includes(mat.id)}
                        onChange={() => toggleSelect(mat.id)}
                        className="rounded text-blue-600 focus:ring-0 cursor-pointer"
                      />
                    </td>
                    <td className="py-3.5 px-4 font-bold text-slate-900 flex items-center gap-2">
                      <FileText size={16} className="text-blue-500 shrink-0" />
                      <span>{mat.fileName}</span>
                    </td>
                    <td className="py-3.5 px-3">
                      <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-bold text-[10px]">
                        {mat.fileType}
                      </span>
                    </td>
                    <td className="py-3.5 px-3 text-slate-600 font-mono font-medium">
                      {mat.fileSize}
                    </td>
                    <td className="py-3.5 px-4 text-slate-800 font-medium">
                      {mat.uploadedBy}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600">
                      {mat.courseName}
                    </td>
                    <td className="py-3.5 px-4 text-slate-500 font-mono text-[11px]">
                      {mat.date}
                    </td>
                    <td className="py-3.5 px-5 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => setPreviewItem(mat)}
                          className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-blue-600 transition-colors cursor-pointer"
                          title="Preview File"
                        >
                          <Eye size={15} />
                        </button>
                        <button
                          type="button"
                          onClick={() => triggerDownload(mat)}
                          className="p-1.5 rounded hover:bg-emerald-50 text-slate-500 hover:text-emerald-600 transition-colors cursor-pointer"
                          title="Download to Computer"
                        >
                          <Download size={15} />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteItem(mat.id, mat.fileName)}
                          className="p-1.5 rounded hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                          title="Delete File"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}

              {activeTab === 'submissions' && filteredSubmissions.length === 0 && (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400">
                    {searchTerm ? `No submissions matching "${searchTerm}".` : 'No student submissions found.'}
                  </td>
                </tr>
              )}

              {activeTab === 'submissions' &&
                filteredSubmissions.map(sub => (
                  <tr key={sub.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3.5 px-4 text-center">
                      <input
                        type="checkbox"
                        checked={selectedIds.includes(sub.id)}
                        onChange={() => toggleSelect(sub.id)}
                        className="rounded text-blue-600 focus:ring-0 cursor-pointer"
                      />
                    </td>
                    <td className="py-3.5 px-4 font-bold text-slate-900 flex items-center gap-2">
                      <FileCheck size={16} className="text-emerald-500 shrink-0" />
                      <span>{sub.fileName}</span>
                    </td>
                    <td className="py-3.5 px-3">
                      <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-bold text-[10px]">
                        PDF
                      </span>
                    </td>
                    <td className="py-3.5 px-3 text-slate-600 font-mono font-medium">
                      {sub.fileSize || '1.8 MB'}
                    </td>
                    <td className="py-3.5 px-4 text-slate-800 font-semibold">
                      {sub.studentName}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600">
                      {sub.assignmentTitle}
                    </td>
                    <td className="py-3.5 px-4 text-slate-500 font-mono text-[11px]">
                      {sub.submissionDate}
                    </td>
                    <td className="py-3.5 px-5 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => setPreviewItem(sub)}
                          className="p-1.5 rounded hover:bg-slate-100 text-slate-500 hover:text-blue-600 transition-colors cursor-pointer"
                          title="Preview Submission"
                        >
                          <Eye size={15} />
                        </button>
                        <button
                          type="button"
                          onClick={() => triggerDownload(sub)}
                          className="p-1.5 rounded hover:bg-emerald-50 text-slate-500 hover:text-emerald-600 transition-colors cursor-pointer"
                          title="Download Submission"
                        >
                          <Download size={15} />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteItem(sub.id, sub.fileName)}
                          className="p-1.5 rounded hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                          title="Delete Submission"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Upload File Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Upload size={18} className="text-blue-600" />
                <span>Upload Course Material</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowUploadModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleConfirmUpload} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Select File from Computer
                </label>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleLocalFilePicked}
                  className="w-full text-xs text-slate-500 file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 cursor-pointer"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">File Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. OS_Lecture_05_Virtual_Memory.pdf"
                  value={fileName}
                  onChange={e => setFileName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm font-semibold focus:outline-blue-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Format</label>
                  <select
                    value={fileType}
                    onChange={e => setFileType(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-blue-600 bg-white"
                  >
                    <option value="PDF">PDF Document</option>
                    <option value="DOCX">Word DOCX</option>
                    <option value="PPTX">PowerPoint PPTX</option>
                    <option value="TXT">Text Document</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Simulated Size</label>
                  <input
                    type="text"
                    value={fileSize}
                    onChange={e => setFileSize(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm font-semibold focus:outline-blue-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Target Course</label>
                <select
                  value={courseName}
                  onChange={e => setCourseName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-blue-600 bg-white"
                >
                  <option value="Operating Systems">Operating Systems (CS301)</option>
                  <option value="Computer Networks">Computer Networks (CS302)</option>
                  <option value="Database Management Systems">Database Management Systems (CS303)</option>
                  <option value="Design & Analysis of Algorithms">Design & Analysis of Algorithms (CS304)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Description / Notes</label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-blue-600"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm cursor-pointer"
                >
                  Confirm Upload
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Preview Modal */}
      {previewItem && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Eye size={18} className="text-blue-600" />
                <span>File Metadata & Preview</span>
              </h3>
              <button
                type="button"
                onClick={() => setPreviewItem(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X size={18} />
              </button>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs space-y-2 mb-4">
              <div className="flex justify-between">
                <span className="text-slate-500 font-medium">Filename:</span>
                <span className="font-bold text-slate-900 font-mono">{previewItem.fileName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 font-medium">File Size:</span>
                <span className="font-mono text-slate-700">{previewItem.fileSize || '1.8 MB'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 font-medium">Course:</span>
                <span className="font-semibold text-blue-700">{previewItem.courseName || previewItem.assignmentTitle}</span>
              </div>
              {previewItem.uploadedBy && (
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Uploaded By:</span>
                  <span className="font-semibold text-slate-800">{previewItem.uploadedBy}</span>
                </div>
              )}
              {previewItem.studentName && (
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Student Author:</span>
                  <span className="font-semibold text-slate-800">{previewItem.studentName}</span>
                </div>
              )}
              {previewItem.grade !== undefined && (
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Evaluation Grade:</span>
                  <span className="font-bold text-emerald-700">{previewItem.grade} / 20</span>
                </div>
              )}
            </div>

            <div className="p-3 bg-white border border-slate-200 rounded-lg text-xs text-slate-600 leading-relaxed mb-4">
              <div className="font-bold text-slate-700 mb-1">Document Content Abstract:</div>
              <p className="italic text-[11px] text-slate-500">
                "{previewItem.description || previewItem.feedback || 'Official course document verified by Smart LMS filesystem manager. Content is formatted and ready for examination.'}"
              </p>
            </div>

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => triggerDownload(previewItem)}
                className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg shadow-sm cursor-pointer"
              >
                <Download size={14} />
                <span>Download File</span>
              </button>
              <button
                type="button"
                onClick={() => setPreviewItem(null)}
                className="px-4 py-2 text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
