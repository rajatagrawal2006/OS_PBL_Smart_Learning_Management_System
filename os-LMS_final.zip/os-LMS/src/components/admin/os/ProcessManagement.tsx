import React, { useState } from 'react';
import { Plus, Trash2, Play, Pause, Square, FileText, CheckCircle2 } from 'lucide-react';
import { SimulatedProcess, ProcessState } from '../../../types';

interface ProcessManagementProps {
  processes: SimulatedProcess[];
  onCreateProcess: (proc: Omit<SimulatedProcess, 'pid' | 'remainingTime' | 'creationTime'>) => void;
  onUpdateState: (pid: string, state: ProcessState) => void;
  onTerminateProcess: (pid: string) => void;
  onDeleteProcess: (pid: string) => void;
}

export const ProcessManagement: React.FC<ProcessManagementProps> = ({
  processes,
  onCreateProcess,
  onUpdateState,
  onTerminateProcess,
  onDeleteProcess
}) => {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedPCB, setSelectedPCB] = useState<SimulatedProcess | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [taskType, setTaskType] = useState('I/O Bound');
  const [arrivalTime, setArrivalTime] = useState('0');
  const [burstTime, setBurstTime] = useState('5');
  const [priority, setPriority] = useState('2');
  const [memoryReq, setMemoryReq] = useState('100');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) return;
    onCreateProcess({
      name,
      taskType,
      arrivalTime: Number(arrivalTime),
      burstTime: Number(burstTime),
      priority: Number(priority),
      memoryReq: Number(memoryReq),
      state: 'Ready'
    });
    setName('');
    setShowCreateModal(false);
  };

  const getStateBadgeClass = (state: ProcessState) => {
    switch (state) {
      case 'Ready':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200/80';
      case 'Running':
        return 'bg-blue-50 text-blue-700 border-blue-200/80';
      case 'Waiting':
        return 'bg-amber-50 text-amber-700 border-amber-200/80';
      case 'Terminated':
        return 'bg-slate-100 text-slate-500 border-slate-200';
      default:
        return 'bg-slate-50 text-slate-600 border-slate-200';
    }
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#172033]">Process Management</h1>
          <p className="text-sm text-slate-500 font-medium">Create and manage simulated processes</p>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-colors"
          >
            <Plus size={16} />
            <span>Create Process</span>
          </button>

          <button
            type="button"
            onClick={() => {
              const active = processes.filter(p => p.state !== 'Terminated');
              if (active.length > 0) {
                onTerminateProcess(active[0].pid);
              }
            }}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-xs transition-colors"
          >
            <Square size={14} />
            <span>Terminate Process</span>
          </button>
        </div>
      </div>

      {/* Process Table Card matching Blueprint 4.1 */}
      <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/80 text-[11px] font-bold uppercase text-slate-600 tracking-wider">
                <th className="py-3 px-5">PID</th>
                <th className="py-3 px-4">Process Name</th>
                <th className="py-3 px-4">Arrival Time</th>
                <th className="py-3 px-4">Burst Time</th>
                <th className="py-3 px-4">Priority</th>
                <th className="py-3 px-4">State</th>
                <th className="py-3 px-5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {processes.map(proc => (
                <tr key={proc.pid} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3.5 px-5 font-bold text-blue-600">
                    {proc.pid}
                  </td>
                  <td className="py-3.5 px-4 font-semibold text-slate-800">
                    {proc.name}
                  </td>
                  <td className="py-3.5 px-4 text-slate-600">
                    {proc.arrivalTime}
                  </td>
                  <td className="py-3.5 px-4 text-slate-600">
                    {proc.burstTime}
                  </td>
                  <td className="py-3.5 px-4 text-slate-600 font-medium">
                    {proc.priority}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className={`inline-flex items-center px-2.5 py-1 rounded-md text-[11px] font-bold border ${getStateBadgeClass(proc.state)}`}>
                      {proc.state}
                    </span>
                  </td>
                  <td className="py-3.5 px-5 text-right">
                    <div className="inline-flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setSelectedPCB(proc)}
                        className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] transition-colors"
                        title="View Process Control Block (PCB)"
                      >
                        PCB
                      </button>

                      {proc.state !== 'Running' && (
                        <button
                          type="button"
                          onClick={() => onUpdateState(proc.pid, 'Running')}
                          className="p-1 rounded bg-emerald-50 hover:bg-emerald-100 text-emerald-600 transition-colors"
                          title="Set Running"
                        >
                          <Play size={13} fill="currentColor" />
                        </button>
                      )}

                      {proc.state === 'Running' && (
                        <button
                          type="button"
                          onClick={() => onUpdateState(proc.pid, 'Waiting')}
                          className="p-1 rounded bg-amber-50 hover:bg-amber-100 text-amber-600 transition-colors"
                          title="Set Waiting"
                        >
                          <Pause size={13} fill="currentColor" />
                        </button>
                      )}

                      {proc.state !== 'Terminated' && (
                        <button
                          type="button"
                          onClick={() => onTerminateProcess(proc.pid)}
                          className="p-1 rounded bg-rose-50 hover:bg-rose-100 text-rose-600 transition-colors"
                          title="Terminate"
                        >
                          <Square size={13} fill="currentColor" />
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => onDeleteProcess(proc.pid)}
                        className="p-1 rounded hover:bg-slate-100 text-slate-400 hover:text-rose-600 transition-colors"
                        title="Delete"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Process Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <form onSubmit={handleCreate} className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="text-lg font-bold text-slate-900 mb-4">Create Simulated Process</h3>
            <div className="space-y-3 mb-6">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Process Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Assignment Upload"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-blue-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Task Type</label>
                  <select
                    value={taskType}
                    onChange={e => setTaskType(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-blue-600"
                  >
                    <option value="I/O Bound">I/O Bound</option>
                    <option value="CPU Bound">CPU Bound</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Priority (1 = Highest)</label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    required
                    value={priority}
                    onChange={e => setPriority(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-blue-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Arrival Time (ms)</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={arrivalTime}
                    onChange={e => setArrivalTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Burst Time (ms)</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={burstTime}
                    onChange={e => setBurstTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-blue-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Memory Requirement (MB)</label>
                <input
                  type="number"
                  min="10"
                  max="500"
                  required
                  value={memoryReq}
                  onChange={e => setMemoryReq(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-blue-600"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm"
              >
                Create Process
              </button>
            </div>
          </form>
        </div>
      )}

      {/* PCB Modal */}
      {selectedPCB && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <FileText size={18} className="text-blue-600" />
                Process Control Block (PCB): {selectedPCB.pid}
              </h3>
              <span className={`px-2 py-0.5 rounded text-xs font-bold border ${getStateBadgeClass(selectedPCB.state)}`}>
                {selectedPCB.state}
              </span>
            </div>

            <div className="bg-slate-50/80 rounded-xl p-4 border border-slate-200/80 text-xs space-y-2 mb-6 font-mono">
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500 font-sans">PID:</span>
                <span className="font-bold text-blue-600">{selectedPCB.pid}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500 font-sans">Process Name:</span>
                <span className="font-semibold text-slate-800">{selectedPCB.name}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500 font-sans">Task Type:</span>
                <span className="text-slate-700">{selectedPCB.taskType}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500 font-sans">Arrival Time:</span>
                <span className="text-slate-700">{selectedPCB.arrivalTime} ms</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500 font-sans">Burst Time:</span>
                <span className="text-slate-700">{selectedPCB.burstTime} ms</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500 font-sans">Remaining Time:</span>
                <span className="text-slate-700">{selectedPCB.remainingTime} ms</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500 font-sans">Priority:</span>
                <span className="text-slate-700">Level {selectedPCB.priority} (1=Highest)</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500 font-sans">Memory Allocation:</span>
                <span className="text-slate-700">{selectedPCB.memoryReq} MB</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500 font-sans">Created At:</span>
                <span className="text-slate-600">{selectedPCB.creationTime}</span>
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedPCB(null)}
                className="px-4 py-2 text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg"
              >
                Close PCB
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
