import React, { useState } from 'react';
import { HardDrive, AlertCircle, CheckCircle2, RotateCcw } from 'lucide-react';
import { MemoryBlock } from '../../../types';
import { allocateMemory, releaseMemory } from '../../../utils/osCalculations';

interface MemoryManagementProps {
  memoryBlocks: MemoryBlock[];
  onUpdateMemory: (newBlocks: MemoryBlock[], activityDesc?: string) => void;
}

export const MemoryManagement: React.FC<MemoryManagementProps> = ({
  memoryBlocks,
  onUpdateMemory
}) => {
  const [algorithm, setAlgorithm] = useState<'First Fit' | 'Best Fit'>('First Fit');
  const [processId, setProcessId] = useState('P4');
  const [requestSize, setRequestSize] = useState('150');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const totalPool = 1000;
  const allocatedSum = memoryBlocks
    .filter(b => b.status === 'Allocated')
    .reduce((acc, b) => acc + b.size, 0);
  const freeSum = totalPool - allocatedSum;
  const utilizationPct = Math.round((allocatedSum / totalPool) * 100);

  const handleAllocate = () => {
    const size = Number(requestSize);
    if (!processId.trim()) {
      setFeedback({ type: 'error', message: 'Please enter a process identifier.' });
      return;
    }
    const res = allocateMemory(memoryBlocks, processId.trim().toUpperCase(), size, algorithm);
    if (res.success) {
      setFeedback({ type: 'success', message: res.message });
      onUpdateMemory(res.updatedBlocks, `Memory allocated to ${processId.toUpperCase()} (${size} MB via ${algorithm})`);
    } else {
      setFeedback({ type: 'error', message: res.message });
    }
  };

  const handleRelease = () => {
    if (!processId.trim()) {
      setFeedback({ type: 'error', message: 'Please enter the process identifier to release.' });
      return;
    }
    const res = releaseMemory(memoryBlocks, processId.trim().toUpperCase());
    if (res.success) {
      setFeedback({ type: 'success', message: res.message });
      onUpdateMemory(res.updatedBlocks, `Memory released from ${processId.toUpperCase()}`);
    } else {
      setFeedback({ type: 'error', message: res.message });
    }
  };

  const handleReset = () => {
    const resetBlocks: MemoryBlock[] = [
      { start: 0, size: 100, status: 'Allocated', process: 'P1' },
      { start: 100, size: 250, status: 'Allocated', process: 'P2' },
      { start: 350, size: 150, status: 'Allocated', process: 'P3' },
      { start: 500, size: 500, status: 'Free', process: '-' }
    ];
    onUpdateMemory(resetBlocks, 'Memory pool reset to initial state');
    setFeedback({ type: 'success', message: 'Memory pool reset to blueprint configuration.' });
  };

  const getBlockColor = (block: MemoryBlock) => {
    if (block.status === 'Free') {
      return { bg: 'bg-slate-200', text: 'text-slate-700', border: 'border-slate-300' };
    }
    switch (block.process) {
      case 'P1':
        return { bg: 'bg-[#7DD3FC]', text: 'text-slate-900', border: 'border-sky-300' };
      case 'P2':
        return { bg: 'bg-[#86EFAC]', text: 'text-slate-900', border: 'border-emerald-300' };
      case 'P3':
        return { bg: 'bg-[#FCA5A5]', text: 'text-slate-900', border: 'border-rose-300' };
      case 'P4':
        return { bg: 'bg-[#FDE047]', text: 'text-slate-900', border: 'border-amber-300' };
      case 'P5':
        return { bg: 'bg-[#C4B5FD]', text: 'text-slate-900', border: 'border-purple-300' };
      default:
        return { bg: 'bg-blue-300', text: 'text-slate-900', border: 'border-blue-400' };
    }
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-[#172033]">Memory Management</h1>
        <p className="text-sm text-slate-500 font-medium">Simulate memory allocation algorithms</p>
      </div>

      {/* Top Controls Bar matching Blueprint 4.3 */}
      <div className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Select Algorithm</label>
            <select
              value={algorithm}
              onChange={e => setAlgorithm(e.target.value as any)}
              className="px-3.5 py-2 rounded-lg border border-slate-300 text-sm font-semibold text-slate-800 bg-white focus:outline-blue-600 shadow-2xs"
            >
              <option value="First Fit">First Fit</option>
              <option value="Best Fit">Best Fit</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Process</label>
            <input
              type="text"
              value={processId}
              onChange={e => setProcessId(e.target.value)}
              placeholder="e.g. P4"
              className="w-24 px-3 py-2 rounded-lg border border-slate-300 text-sm font-semibold focus:outline-blue-600 shadow-2xs"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Request Memory (MB)</label>
            <input
              type="number"
              min="1"
              max={totalPool}
              value={requestSize}
              onChange={e => setRequestSize(e.target.value)}
              className="w-32 px-3 py-2 rounded-lg border border-slate-300 text-sm font-semibold focus:outline-blue-600 shadow-2xs"
            />
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={handleAllocate}
            className="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-colors"
          >
            Allocate
          </button>

          <button
            type="button"
            onClick={handleRelease}
            className="px-5 py-2 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-xs transition-colors"
          >
            Release
          </button>

          <button
            type="button"
            onClick={handleReset}
            className="p-2 rounded-lg hover:bg-slate-100 text-slate-500 hover:text-slate-800 transition-colors"
            title="Reset Pool to Initial Blueprint Configuration"
          >
            <RotateCcw size={16} />
          </button>
        </div>
      </div>

      {/* Feedback banner */}
      {feedback && (
        <div className={`p-3.5 rounded-xl border flex items-center gap-2.5 text-xs font-medium animate-in fade-in duration-200 ${
          feedback.type === 'success'
            ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
            : 'bg-rose-50 text-rose-800 border-rose-200'
        }`}>
          {feedback.type === 'success' ? <CheckCircle2 size={16} /> : <AlertCircle size={16} />}
          <span>{feedback.message}</span>
        </div>
      )}

      {/* Simulated Memory (1000 MB) Visual Bar matching Blueprint 4.3 */}
      <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs p-6">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-bold text-slate-900">
            Simulated Memory ({totalPool} MB)
          </h2>
          <div className="text-xs font-semibold text-slate-500 flex items-center gap-3">
            <span>Allocated: <strong className="text-blue-600">{allocatedSum} MB</strong></span>
            <span>Free: <strong className="text-emerald-600">{freeSum} MB</strong></span>
            <span>Utilization: <strong className="text-slate-900">{utilizationPct}%</strong></span>
          </div>
        </div>

        {/* Visual Map Bar */}
        <div className="flex h-16 w-full rounded-xl overflow-hidden border border-slate-300 shadow-inner">
          {memoryBlocks.map((block, idx) => {
            const widthPct = (block.size / totalPool) * 100;
            const colors = getBlockColor(block);

            return (
              <div
                key={idx}
                style={{ width: `${widthPct}%` }}
                className={`${colors.bg} ${colors.text} border-r last:border-r-0 border-white/60 flex flex-col items-center justify-center font-bold text-xs p-1 select-none transition-all`}
                title={`${block.status === 'Allocated' ? block.process : 'Free'}: ${block.size} MB (Address: ${block.start} - ${block.start + block.size} MB)`}
              >
                <span className="leading-tight">{block.status === 'Allocated' ? block.process : 'Free'}</span>
                <span className="text-[10px] font-medium opacity-85 leading-tight">{block.size} MB</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Memory Blocks Table matching Blueprint 4.3 */}
      <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900">Memory Blocks</h2>
          <span className="text-xs font-medium text-slate-400">{memoryBlocks.length} Partitions</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50/80 text-[11px] font-bold uppercase text-slate-500 tracking-wider">
                <th className="py-3 px-5">Start (MB)</th>
                <th className="py-3 px-4">Size (MB)</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-5">Process</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {memoryBlocks.map((b, idx) => (
                <tr key={idx} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-3 px-5 font-mono text-slate-600">
                    {b.start}
                  </td>
                  <td className="py-3 px-4 font-mono font-semibold text-slate-800">
                    {b.size}
                  </td>
                  <td className="py-3 px-4">
                    {b.status === 'Allocated' ? (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200/80">
                        Allocated
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-sky-50 text-sky-700 border border-sky-200/80">
                        Free
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-5 font-bold text-blue-600">
                    {b.process}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
