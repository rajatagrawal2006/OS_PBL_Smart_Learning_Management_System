import React, { useState } from 'react';
import { BookOpen, Plus, Trash2, Edit2 } from 'lucide-react';
import { Course } from '../../types';

interface CourseManagementProps {
  courses: Course[];
  onCreateCourse: (course: Partial<Course>) => void;
  onDeleteCourse: (courseId: string) => void;
}

export const CourseManagement: React.FC<CourseManagementProps> = ({
  courses,
  onCreateCourse,
  onDeleteCourse
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [teacher, setTeacher] = useState('Prof. Sharma');
  const [desc, setDesc] = useState('');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code || !name) return;
    onCreateCourse({
      code,
      name,
      teacherName: teacher,
      teacherId: 'U102',
      description: desc || 'Syllabus and coursework.',
      enrolledCount: 20,
      materialsCount: 1,
      assignmentsCount: 1,
      isActive: true
    });
    setCode('');
    setName('');
    setDesc('');
    setShowAddModal(false);
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#172033]">Manage Courses</h1>
          <p className="text-sm text-slate-500 font-medium">Curriculum, enrolled student counts, and course offerings</p>
        </div>

        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-colors"
        >
          <Plus size={16} />
          <span>Add Course</span>
        </button>
      </div>

      <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/80 text-[11px] font-bold uppercase text-slate-500 tracking-wider">
                <th className="py-3 px-5">Course ID</th>
                <th className="py-3 px-4">Course Name</th>
                <th className="py-3 px-4">Instructor</th>
                <th className="py-3 px-4">Enrolled Students</th>
                <th className="py-3 px-4">Assignments</th>
                <th className="py-3 px-5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {courses.map(c => (
                <tr key={c.id} className="hover:bg-slate-50/60 transition-colors">
                  <td className="py-3 px-5 font-bold text-blue-600">{c.code}</td>
                  <td className="py-3 px-4 font-semibold text-slate-900">{c.name}</td>
                  <td className="py-3 px-4 text-slate-700">{c.teacherName}</td>
                  <td className="py-3 px-4 text-slate-600">{c.enrolledCount} students</td>
                  <td className="py-3 px-4 text-slate-600">{c.assignmentsCount} assignments</td>
                  <td className="py-3 px-5 text-right">
                    <button
                      type="button"
                      onClick={() => onDeleteCourse(c.id)}
                      className="p-1 rounded hover:bg-slate-100 text-slate-400 hover:text-rose-600 transition-colors"
                      title="Delete Course"
                    >
                      <Trash2 size={14} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <form onSubmit={handleAdd} className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="text-lg font-bold text-slate-900 mb-4">Add Course</h3>
            <div className="space-y-3 mb-6">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Course Code</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. CS306"
                  value={code}
                  onChange={e => setCode(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-blue-600"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Course Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Cybersecurity Fundamentals"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-blue-600"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Instructor</label>
                <select
                  value={teacher}
                  onChange={e => setTeacher(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-blue-600"
                >
                  <option value="Prof. Sharma">Prof. Sharma</option>
                  <option value="Prof. Mehta">Prof. Mehta</option>
                  <option value="Prof. Singh">Prof. Singh</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Description</label>
                <textarea
                  rows={2}
                  value={desc}
                  onChange={e => setDesc(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-blue-600"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-sm"
              >
                Save Course
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
