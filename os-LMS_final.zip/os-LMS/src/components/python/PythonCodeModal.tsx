import React, { useState } from 'react';
import { X, Download, Copy, Check, FileCode, Folder, Terminal } from 'lucide-react';
import JSZip from 'jszip';
import { PYTHON_FILES } from './pythonFileSources';

interface PythonCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PythonCodeModal: React.FC<PythonCodeModalProps> = ({ isOpen, onClose }) => {
  const [selectedPath, setSelectedPath] = useState<string>('main.py');
  const [copied, setCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);

  if (!isOpen) return null;

  const currentFile = PYTHON_FILES[selectedPath] || PYTHON_FILES['main.py'];

  const handleCopy = () => {
    navigator.clipboard.writeText(currentFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const zip = new JSZip();
      const folder = zip.folder('SmartLMS');

      if (folder) {
        Object.entries(PYTHON_FILES).forEach(([path, file]) => {
          folder.file(path, file.code);
        });

        // Add dummy demo data JSON files inside data folder
        const dataFolder = folder.folder('data');
        if (dataFolder) {
          dataFolder.file('users.json', JSON.stringify([], null, 2));
          dataFolder.file('courses.json', JSON.stringify([], null, 2));
        }
      }

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'SmartLMS_Python_Project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Error generating zip:', err);
    } finally {
      setIsZipping(false);
    }
  };

  // Group files by directory
  const filesList = Object.keys(PYTHON_FILES);

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-[#0F172A] text-slate-100 rounded-2xl max-w-5xl w-full h-[85vh] flex flex-col shadow-2xl border border-slate-700 overflow-hidden animate-in fade-in zoom-in-95">
        {/* Modal Header */}
        <div className="p-4 px-6 border-b border-slate-800 flex items-center justify-between bg-slate-900 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center font-bold">
              🐍
            </div>
            <div>
              <h2 className="font-bold text-base text-white">Smart LMS — Complete Python & Tkinter Desktop Codebase</h2>
              <p className="text-xs text-slate-400">Modular structure separating view logic from OS simulations</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleDownloadZip}
              disabled={isZipping}
              className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-colors"
            >
              <Download size={14} />
              <span>{isZipping ? 'Archiving...' : 'Download SmartLMS.zip'}</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Instructions banner */}
        <div className="bg-blue-950/40 border-b border-blue-900/40 px-6 py-2.5 flex items-center justify-between text-xs text-blue-200">
          <div className="flex items-center gap-2">
            <Terminal size={14} className="text-blue-400" />
            <span>To run locally on Windows / Mac / Linux:</span>
            <code className="bg-black/40 px-2 py-0.5 rounded border border-blue-500/30 text-emerald-400 font-mono text-[11px]">
              python main.py
            </code>
          </div>
          <span className="text-slate-400 text-[11px]">Zero pip packages needed • Pure standard library</span>
        </div>

        {/* File Tree & Editor Split */}
        <div className="flex-1 flex overflow-hidden">
          {/* File Sidebar */}
          <div className="w-64 border-r border-slate-800 bg-[#0B1120] overflow-y-auto p-3 space-y-1 text-xs">
            <div className="px-2 py-1 text-[11px] font-bold uppercase text-slate-400 tracking-wider">
              Project Structure
            </div>

            {filesList.map(filePath => {
              const isSelected = selectedPath === filePath;
              const isSubdir = filePath.includes('/');

              return (
                <button
                  key={filePath}
                  type="button"
                  onClick={() => setSelectedPath(filePath)}
                  className={`w-full text-left flex items-center gap-2 px-2.5 py-1.5 rounded-md font-mono transition-colors ${
                    isSubdir ? 'pl-5' : ''
                  } ${
                    isSelected
                      ? 'bg-blue-600/30 text-blue-300 font-bold border border-blue-500/40'
                      : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'
                  }`}
                >
                  <FileCode size={13} className={isSelected ? 'text-blue-400' : 'text-slate-500'} />
                  <span className="truncate">{filePath}</span>
                </button>
              );
            })}
          </div>

          {/* Code Viewer */}
          <div className="flex-1 flex flex-col bg-[#020617] overflow-hidden">
            <div className="px-6 py-2.5 border-b border-slate-800/80 bg-slate-900/50 flex items-center justify-between">
              <span className="font-mono text-xs font-bold text-slate-300">
                {selectedPath}
              </span>
              <button
                type="button"
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
              >
                {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
                <span>{copied ? 'Copied!' : 'Copy Code'}</span>
              </button>
            </div>

            <div className="flex-1 overflow-auto p-6 font-mono text-xs leading-relaxed text-slate-300 selection:bg-blue-700">
              <pre className="whitespace-pre">{currentFile.code}</pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
