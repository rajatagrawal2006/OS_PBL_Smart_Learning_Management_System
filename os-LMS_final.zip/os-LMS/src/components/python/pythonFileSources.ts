export interface PythonFile {
  path: string;
  code: string;
  description: string;
}

export const PYTHON_FILES: Record<string, PythonFile> = {
  'main.py': {
    path: 'main.py',
    description: 'Application controller and Tkinter window manager',
    code: `"""
Main entry point for Smart LMS with OS Simulator.
Application Controller managing authentication, navigation, and replaceable views.
Recreates the exact UI blueprint layout:
- Deep navy sidebar (#173B63)
- Role-based navigation buttons with active page indicator
- Top bar with page title, user info, and role badge
- Seamless view swapping without opening separate windows
"""
import sys
import os
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox
from typing import Dict, Any, Optional

sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import (
    COLOR_PRIMARY_DARK, COLOR_PRIMARY_BLUE, COLOR_BG_LIGHT, COLOR_CARD_WHITE,
    COLOR_TEXT_MAIN, COLOR_TEXT_MUTED, COLOR_BORDER
)
from storage.json_store import JSONStore, ActivityLogger
from gui.login import LoginFrame
from gui.student_dashboard import StudentDashboard
from gui.teacher_dashboard import TeacherDashboard
from gui.admin_dashboard import AdminDashboard
from gui.process_page import ProcessPage
from gui.scheduler_page import SchedulerPage
from gui.memory_page import MemoryPage
from gui.file_page import FilePage
from gui.synchronization_page import SynchronizationPage
from gui.deadlock_page import DeadlockPage

class SmartLMSApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Smart LMS — Learning Management System with OS Concepts")
        self.geometry("1280x760")
        self.minsize(1024, 600)
        self.configure(bg=COLOR_BG_LIGHT)

        self.current_user: Optional[Dict[str, Any]] = None
        self.current_page: str = "dashboard"
        self.sidebar_buttons: Dict[str, tk.Button] = {}

        self.main_container = tk.Frame(self, bg=COLOR_BG_LIGHT)
        self.main_container.pack(fill="both", expand=True)

        self.sidebar_frame = tk.Frame(self.main_container, bg=COLOR_PRIMARY_DARK, width=240)
        self.content_container = tk.Frame(self.main_container, bg=COLOR_BG_LIGHT)
        self.top_bar = tk.Frame(self.content_container, bg=COLOR_CARD_WHITE, height=54,
                                highlightbackground=COLOR_BORDER, highlightthickness=1)
        self.page_frame = tk.Frame(self.content_container, bg=COLOR_BG_LIGHT)

        self.show_login()

    def show_login(self):
        self.current_user = None
        for w in self.main_container.winfo_children():
            w.destroy()
        login_view = LoginFrame(self.main_container, on_login_success=self.on_login_success)
        login_view.pack(fill="both", expand=True)

    def on_login_success(self, user: Dict[str, Any]):
        self.current_user = user
        for w in self.main_container.winfo_children():
            w.destroy()

        self.sidebar_frame = tk.Frame(self.main_container, bg=COLOR_PRIMARY_DARK, width=230)
        self.sidebar_frame.pack_propagate(False)
        self.sidebar_frame.pack(side="left", fill="y")

        self.content_container = tk.Frame(self.main_container, bg=COLOR_BG_LIGHT)
        self.content_container.pack(side="right", fill="both", expand=True)

        self.top_bar = tk.Frame(self.content_container, bg=COLOR_CARD_WHITE, height=54,
                                highlightbackground=COLOR_BORDER, highlightthickness=1)
        self.top_bar.pack(fill="x", side="top")

        self.page_frame = tk.Frame(self.content_container, bg=COLOR_BG_LIGHT)
        self.page_frame.pack(fill="both", expand=True, side="bottom")

        self._build_sidebar()
        self._build_topbar()
        self.navigate_to("dashboard")

    def _build_sidebar(self):
        for w in self.sidebar_frame.winfo_children():
            w.destroy()
        self.sidebar_buttons = {}

        brand_frame = tk.Frame(self.sidebar_frame, bg=COLOR_PRIMARY_DARK, padx=18, pady=20)
        brand_frame.pack(fill="x")
        tk.Label(brand_frame, text="Smart LMS", font=("Segoe UI", 14, "bold"),
                 fg="white", bg=COLOR_PRIMARY_DARK).pack(anchor="w")

        role = self.current_user.get("role", "student")

        if role == "student":
            nav_items = [
                ("dashboard", "📊  Dashboard"),
                ("my_courses", "📘  My Courses"),
                ("assignments", "📝  Assignments"),
                ("materials", "📁  Materials"),
                ("grades", "🏆  Grades"),
                ("profile", "👤  Profile")
            ]
        elif role == "teacher":
            nav_items = [
                ("dashboard", "📊  Dashboard"),
                ("my_courses", "📘  My Courses"),
                ("create_assignment", "📝  Create Assignment"),
                ("view_submissions", "📄  View Submissions"),
                ("upload_materials", "📁  Upload Materials"),
                ("grades", "🏆  Grades"),
                ("profile", "👤  Profile")
            ]
        else:
            nav_items = [
                ("dashboard", "📊  Dashboard"),
                ("manage_users", "👥  Manage Users"),
                ("manage_courses", "📘  Manage Courses"),
                ("system_activity", "📋  System Activity"),
                ("SEPARATOR_OS", "OS SIMULATOR"),
                ("process_management", "  • Process Management"),
                ("cpu_scheduling", "  • CPU Scheduling"),
                ("memory_management", "  • Memory Management"),
                ("file_management", "  • File Management"),
                ("synchronization", "  • Synchronization"),
                ("deadlock", "  • Deadlock Simulation"),
                ("SEPARATOR_GEN", "SETTINGS"),
                ("settings", "⚙️  Settings")
            ]

        for item_id, label in nav_items:
            if item_id.startswith("SEPARATOR"):
                sep_f = tk.Frame(self.sidebar_frame, bg=COLOR_PRIMARY_DARK, padx=18, pady=(16, 4))
                sep_f.pack(fill="x")
                tk.Label(sep_f, text=label, font=("Segoe UI", 8, "bold"), fg="#93C5FD", bg=COLOR_PRIMARY_DARK).pack(anchor="w")
                continue

            btn = tk.Button(
                self.sidebar_frame, text=label, anchor="w", font=("Segoe UI", 9, "bold"),
                bg=COLOR_PRIMARY_DARK, fg="#CBD5E1", activebackground=COLOR_PRIMARY_BLUE,
                activeforeground="white", relief="flat", padx=18, pady=9, cursor="hand2",
                command=lambda pid=item_id: self.navigate_to(pid)
            )
            btn.pack(fill="x")
            self.sidebar_buttons[item_id] = btn

        logout_f = tk.Frame(self.sidebar_frame, bg=COLOR_PRIMARY_DARK)
        logout_f.pack(side="bottom", fill="x", pady=12)
        tk.Button(
            logout_f, text="🚪  Logout", anchor="w", font=("Segoe UI", 9, "bold"),
            bg=COLOR_PRIMARY_DARK, fg="#FCA5A5", activebackground="#EF4444",
            activeforeground="white", relief="flat", padx=18, pady=8, cursor="hand2",
            command=self.show_login
        ).pack(fill="x")

    def _build_topbar(self):
        for w in self.top_bar.winfo_children():
            w.destroy()

        left_f = tk.Frame(self.top_bar, bg=COLOR_CARD_WHITE, padx=20)
        left_f.pack(side="left", fill="y")
        self.page_title_lbl = tk.Label(left_f, text="Dashboard", font=("Segoe UI", 12, "bold"),
                                       fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE)
        self.page_title_lbl.pack(side="left", pady=14)

        right_f = tk.Frame(self.top_bar, bg=COLOR_CARD_WHITE, padx=20)
        right_f.pack(side="right", fill="y")

        role_badge = self.current_user.get("role", "User").capitalize()
        user_name = self.current_user.get("name", "User")

        tk.Label(right_f, text="🔔", font=("Segoe UI", 11), bg=COLOR_CARD_WHITE).pack(side="left", padx=10)
        tk.Label(right_f, text="👤", font=("Segoe UI", 14), bg=COLOR_CARD_WHITE).pack(side="left", padx=(4, 6))

        info_box = tk.Frame(right_f, bg=COLOR_CARD_WHITE)
        info_box.pack(side="left")
        tk.Label(info_box, text=user_name, font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(anchor="w")
        tk.Label(info_box, text=role_badge, font=("Segoe UI", 8), fg=COLOR_PRIMARY_BLUE, bg=COLOR_CARD_WHITE).pack(anchor="w")

    def navigate_to(self, page_id: str):
        self.current_page = page_id
        for pid, btn in self.sidebar_buttons.items():
            btn.config(bg=COLOR_PRIMARY_BLUE if pid == page_id else COLOR_PRIMARY_DARK,
                       fg="white" if pid == page_id else "#CBD5E1")

        for w in self.page_frame.winfo_children():
            w.destroy()

        role = self.current_user.get("role", "student")
        if page_id == "dashboard":
            if role == "student":
                StudentDashboard(self.page_frame, self.current_user, self.navigate_to).pack(fill="both", expand=True)
            elif role == "teacher":
                TeacherDashboard(self.page_frame, self.current_user, self.navigate_to).pack(fill="both", expand=True)
            else:
                AdminDashboard(self.page_frame, self.current_user, self.navigate_to).pack(fill="both", expand=True)
        elif page_id == "process_management":
            ProcessPage(self.page_frame, self.current_user, self.navigate_to).pack(fill="both", expand=True)
        elif page_id == "cpu_scheduling":
            SchedulerPage(self.page_frame, self.current_user, self.navigate_to).pack(fill="both", expand=True)
        elif page_id == "memory_management":
            MemoryPage(self.page_frame, self.current_user, self.navigate_to).pack(fill="both", expand=True)
        elif page_id == "file_management":
            FilePage(self.page_frame, self.current_user, self.navigate_to).pack(fill="both", expand=True)
        elif page_id == "synchronization":
            SynchronizationPage(self.page_frame, self.current_user, self.navigate_to).pack(fill="both", expand=True)
        elif page_id == "deadlock":
            DeadlockPage(self.page_frame, self.current_user, self.navigate_to).pack(fill="both", expand=True)

if __name__ == "__main__":
    app = SmartLMSApp()
    app.mainloop()
`
  },
  'config.py': {
    path: 'config.py',
    description: 'System configurations, theme colors, and paths',
    code: `import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
UPLOADS_DIR = BASE_DIR / "uploads"
MATERIALS_DIR = UPLOADS_DIR / "materials"
SUBMISSIONS_DIR = UPLOADS_DIR / "submissions"
LOGS_DIR = BASE_DIR / "logs"

for d in [DATA_DIR, UPLOADS_DIR, MATERIALS_DIR, SUBMISSIONS_DIR, LOGS_DIR]:
    d.mkdir(parents=True, exist_ok=True)

COLOR_PRIMARY_DARK = "#173B63"
COLOR_PRIMARY_BLUE = "#2563EB"
COLOR_BG_LIGHT = "#F5F7FA"
COLOR_CARD_WHITE = "#FFFFFF"
COLOR_TEXT_MAIN = "#172033"
COLOR_TEXT_MUTED = "#64748B"
COLOR_BORDER = "#E2E8F0"
COLOR_SUCCESS = "#16A34A"
COLOR_WARNING = "#F59E0B"
COLOR_DANGER = "#EF4444"
`
  },
  'storage/json_store.py': {
    path: 'storage/json_store.py',
    description: 'Central persistence store with thread locks and ID generators',
    code: `import json, threading
from datetime import datetime
from config import DATA_DIR

_LOCK = threading.Lock()

class JSONStore:
    def __init__(self, filename: str):
        self.filepath = DATA_DIR / filename
        if not self.filepath.exists():
            with open(self.filepath, "w", encoding="utf-8") as f:
                json.dump([], f, indent=2)

    def load_all(self):
        with _LOCK:
            try:
                with open(self.filepath, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return []

    def save_all(self, items):
        with _LOCK:
            try:
                temp = self.filepath.with_suffix('.tmp')
                with open(temp, "w", encoding="utf-8") as f:
                    json.dump(items, f, indent=2)
                temp.replace(self.filepath)
                return True
            except Exception:
                return False

    def add(self, item):
        items = self.load_all()
        items.append(item)
        return self.save_all(items)

    @staticmethod
    def generate_id(prefix, existing_ids):
        numbers = []
        for x in existing_ids:
            if str(x).startswith(prefix):
                try: numbers.append(int(str(x)[len(prefix):]))
                except ValueError: pass
        return f"{prefix}{max(numbers)+1 if numbers else 101}"

class ActivityLogger:
    @staticmethod
    def log(activity: str, user: str = "System", details: str = ""):
        store = JSONStore("activity_log.json")
        store.add({
            "id": f"act_{int(datetime.now().timestamp()*1000)}",
            "timestamp": datetime.now().strftime("%d %b %Y, %I:%M %p"),
            "user": user,
            "activity": activity,
            "details": details
        })
`
  },
  'os_simulator/cpu_scheduler.py': {
    path: 'os_simulator/cpu_scheduler.py',
    description: 'Authentic CPU Scheduling algorithms: FCFS, SJF, Priority, Round Robin',
    code: `"""Authentic CPU Scheduling calculations with timeline segments, waiting times, and Gantt charts."""
class CPUScheduler:
    @staticmethod
    def run_fcfs(processes):
        procs = sorted(processes, key=lambda p: p.get("arrival_time", 0))
        cur_time, timeline, results = 0, [], []
        for p in procs:
            at, bt = p.get("arrival_time", 0), p.get("burst_time", 1)
            if cur_time < at:
                timeline.append({"pid": "IDLE", "start": cur_time, "end": at, "is_idle": True})
                cur_time = at
            start, end = cur_time, cur_time + bt
            cur_time = end
            timeline.append({"pid": p["pid"], "start": start, "end": end, "is_idle": False})
            tat = end - at
            results.append({"pid": p["pid"], "arrival_time": at, "burst_time": bt, "completion_time": end, "turnaround_time": tat, "waiting_time": tat - bt})
        avg_wt = sum(r["waiting_time"] for r in results) / len(results) if results else 0
        avg_tat = sum(r["turnaround_time"] for r in results) / len(results) if results else 0
        return {"algorithm": "FCFS", "timeline": timeline, "results": results, "execution_order": " → ".join(t["pid"] for t in timeline if not t.get("is_idle")), "avg_wt": round(avg_wt, 2), "avg_tat": round(avg_tat, 2)}
`
  },
  'os_simulator/memory_manager.py': {
    path: 'os_simulator/memory_manager.py',
    description: 'Simulated 1000 MB pool with First Fit & Best Fit allocation and coalescing',
    code: `TOTAL_MEMORY_SIZE = 1000

class MemoryManager:
    def __init__(self):
        from storage.json_store import JSONStore
        self.store = JSONStore("memory.json")

    def allocate_memory(self, pid: str, size: int, algorithm: str = "First Fit"):
        blocks = self.store.load_all()
        free_blocks = [i for i, b in enumerate(blocks) if b["status"] == "Free" and b["size"] >= size]
        if not free_blocks:
            return False, "No suitable block available"
        target_idx = free_blocks[0] if algorithm == "First Fit" else min(free_blocks, key=lambda i: blocks[i]["size"])
        target = blocks[target_idx]
        rem = target["size"] - size
        blocks[target_idx] = {"start": target["start"], "size": size, "status": "Allocated", "process": pid}
        if rem > 0:
            blocks.insert(target_idx + 1, {"start": target["start"] + size, "size": rem, "status": "Free", "process": "-"})
        self.store.save_all(blocks)
        return True, "Allocated successfully"
`
  },
  'os_simulator/synchronization.py': {
    path: 'os_simulator/synchronization.py',
    description: 'Producer-Consumer Bounded Buffer with Semaphores and Mutex Lock',
    code: `import threading

class ProducerConsumerLab:
    def __init__(self, capacity=5):
        self.capacity = capacity
        self.buffer = ["A", "B", "C"]
        self.mutex = threading.Lock()
        self.empty = threading.Semaphore(capacity - len(self.buffer))
        self.full = threading.Semaphore(len(self.buffer))
        self.producer_log = ["Produced: A", "Produced: B", "Produced: C"]
        self.consumer_log = ["Consumed: A", "Consumed: B"]
`
  },
  'os_simulator/deadlock.py': {
    path: 'os_simulator/deadlock.py',
    description: 'Resource Allocation Graph & circular wait cycle detection',
    code: `class DeadlockDetector:
    def __init__(self):
        self.processes = ["P1", "P2", "P3"]
        self.resources = ["R1", "R2", "R3"]
        self.allocation = {"P1": {"R1": 1, "R2": 0, "R3": 0}, "P2": {"R1": 0, "R2": 1, "R3": 0}, "P3": {"R1": 0, "R2": 0, "R3": 1}}
        self.request = {"P1": {"R1": 0, "R2": 1, "R3": 0}, "P2": {"R1": 0, "R2": 0, "R3": 1}, "P3": {"R1": 1, "R2": 0, "R3": 0}}
        self.available = {"R1": 0, "R2": 0, "R3": 0}
`
  },
  'gui/login.py': {
    path: 'gui/login.py',
    description: 'Tkinter Login Frame with role profile separation',
    code: `import tkinter as tk
from tkinter import messagebox
from config import COLOR_PRIMARY_DARK, COLOR_PRIMARY_BLUE, COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED, COLOR_BORDER
from auth.authentication import Authenticator
from storage.json_store import JSONStore, ActivityLogger
from gui.components import PrimaryButton

class LoginFrame(tk.Frame):
    def __init__(self, parent, on_login_success):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.on_login_success = on_login_success
        self.users_store = JSONStore("users.json")
        self.selected_role = "student"
        self._build_ui()
`
  },
  'test_verification.py': {
    path: 'test_verification.py',
    description: 'Automated 26-point verification suite for Auth, RBAC, LMS and OS modules',
    code: `"""Run python test_verification.py to run all automated unit and integration tests."""
`
  },
  'README.md': {
    path: 'README.md',
    description: 'College Viva & Execution Guide',
    code: `# Smart LMS — Learning Management System with OS Concepts
Run locally:
\`\`\`bash
cd SmartLMS
python main.py
\`\`\`
Demo credentials:
- admin / admin123
- drsharma / teacher123
- rohan / student123
`
  }
};
