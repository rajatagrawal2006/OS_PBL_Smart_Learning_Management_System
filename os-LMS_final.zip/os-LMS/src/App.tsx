/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { StudentDashboard } from './components/student/StudentDashboard';
import { TeacherDashboard } from './components/teacher/TeacherDashboard';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { ProcessManagement } from './components/admin/os/ProcessManagement';
import { CpuScheduling } from './components/admin/os/CpuScheduling';
import { MemoryManagement } from './components/admin/os/MemoryManagement';
import { FileManagement } from './components/admin/os/FileManagement';
import { Synchronization } from './components/admin/os/Synchronization';
import { DeadlockSimulation } from './components/admin/os/DeadlockSimulation';
import { UserManagement } from './components/admin/UserManagement';
import { CourseManagement } from './components/admin/CourseManagement';
import { ActivityLog } from './components/admin/ActivityLog';
import { SettingsPage } from './components/admin/SettingsPage';
import { LoginModal } from './components/auth/LoginModal';
import { CreateAssignmentPage } from './components/teacher/CreateAssignmentPage';
import { ViewSubmissionsPage } from './components/teacher/ViewSubmissionsPage';
import { UploadMaterialsPage } from './components/teacher/UploadMaterialsPage';
import { GradesPage } from './components/common/GradesPage';
import { ProfilePage } from './components/common/ProfilePage';
import { generateAcademicPdfBlob } from './utils/pdfGenerator';
import { saveStoredFile, getStoredFile } from './utils/fileBlobStorage';
import { hashPassword } from './utils/crypto';

import {
  INITIAL_USERS,
  INITIAL_COURSES,
  INITIAL_ASSIGNMENTS,
  INITIAL_SUBMISSIONS,
  INITIAL_MATERIALS,
  INITIAL_PROCESSES,
  INITIAL_MEMORY_BLOCKS,
  INITIAL_ACTIVITY_LOG,
  INITIAL_ENROLLMENTS
} from './data/seedData';
import { User, Course, Assignment, Submission, Material, SimulatedProcess, MemoryBlock, ActivityEntry, ProcessState, Role, Enrollment } from './types';

export default function App() {
  // Persistent or seed state
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('smartlms_users');
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('smartlms_logged_in_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [currentPage, setCurrentPage] = useState<string>('dashboard');

  const [enrollments, setEnrollments] = useState<Enrollment[]>(() => {
    const saved = localStorage.getItem('smartlms_enrollments');
    return saved ? JSON.parse(saved) : INITIAL_ENROLLMENTS;
  });

  const [courses, setCourses] = useState<Course[]>(() => {
    const saved = localStorage.getItem('smartlms_courses');
    return saved ? JSON.parse(saved) : INITIAL_COURSES;
  });

  const [assignments, setAssignments] = useState<Assignment[]>(() => {
    const saved = localStorage.getItem('smartlms_assignments');
    return saved ? JSON.parse(saved) : INITIAL_ASSIGNMENTS;
  });

  const [submissions, setSubmissions] = useState<Submission[]>(() => {
    const saved = localStorage.getItem('smartlms_submissions');
    return saved ? JSON.parse(saved) : INITIAL_SUBMISSIONS;
  });

  const [materials, setMaterials] = useState<Material[]>(() => {
    const saved = localStorage.getItem('smartlms_materials');
    return saved ? JSON.parse(saved) : INITIAL_MATERIALS;
  });

  const [processes, setProcesses] = useState<SimulatedProcess[]>(() => {
    const saved = localStorage.getItem('smartlms_processes');
    return saved ? JSON.parse(saved) : INITIAL_PROCESSES;
  });

  const [memoryBlocks, setMemoryBlocks] = useState<MemoryBlock[]>(() => {
    const saved = localStorage.getItem('smartlms_memory');
    return saved ? JSON.parse(saved) : INITIAL_MEMORY_BLOCKS;
  });

  const [activityLogs, setActivityLogs] = useState<ActivityEntry[]>(() => {
    const saved = localStorage.getItem('smartlms_activity');
    return saved ? JSON.parse(saved) : INITIAL_ACTIVITY_LOG;
  });

  const handleResetDemoData = () => {
    setUsers(INITIAL_USERS);
    setCourses(INITIAL_COURSES);
    setAssignments(INITIAL_ASSIGNMENTS);
    setSubmissions(INITIAL_SUBMISSIONS);
    setMaterials(INITIAL_MATERIALS);
    setProcesses(INITIAL_PROCESSES);
    setMemoryBlocks(INITIAL_MEMORY_BLOCKS);
    setActivityLogs(INITIAL_ACTIVITY_LOG);
    setEnrollments(INITIAL_ENROLLMENTS);
    localStorage.clear();
  };

  const handleClearLogs = () => {
    setActivityLogs([]);
    localStorage.removeItem('smartlms_activity');
  };

  // Sync to localStorage
  useEffect(() => { localStorage.setItem('smartlms_users', JSON.stringify(users)); }, [users]);
  useEffect(() => { localStorage.setItem('smartlms_courses', JSON.stringify(courses)); }, [courses]);
  useEffect(() => { localStorage.setItem('smartlms_assignments', JSON.stringify(assignments)); }, [assignments]);
  useEffect(() => { localStorage.setItem('smartlms_submissions', JSON.stringify(submissions)); }, [submissions]);
  useEffect(() => { localStorage.setItem('smartlms_materials', JSON.stringify(materials)); }, [materials]);
  useEffect(() => { localStorage.setItem('smartlms_processes', JSON.stringify(processes)); }, [processes]);
  useEffect(() => { localStorage.setItem('smartlms_memory', JSON.stringify(memoryBlocks)); }, [memoryBlocks]);
  useEffect(() => { localStorage.setItem('smartlms_activity', JSON.stringify(activityLogs)); }, [activityLogs]);
  useEffect(() => { localStorage.setItem('smartlms_enrollments', JSON.stringify(enrollments)); }, [enrollments]);

  const logActivity = (activity: string, details?: string) => {
    const newEntry: ActivityEntry = {
      id: `act-${Date.now()}`,
      timestamp: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) +
        ', ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      user: currentUser?.name || 'System',
      activity,
      details
    };
    setActivityLogs(prev => [newEntry, ...prev]);
  };

  const handleToggleEnrollment = (courseId: string, studentId?: string) => {
    const targetStudentId = studentId || currentUser?.id;
    if (!targetStudentId) return;

    const studentUser = users.find(u => u.id === targetStudentId);
    const targetCourse = courses.find(c => c.id === courseId);
    const isEnrolled = enrollments.some(e => e.courseId === courseId && e.studentId === targetStudentId);

    if (isEnrolled) {
      const nextEnrollments = enrollments.filter(e => !(e.courseId === courseId && e.studentId === targetStudentId));
      setEnrollments(nextEnrollments);
      setCourses(prev =>
        prev.map(c =>
          c.id === courseId
            ? { ...c, enrolledCount: Math.max(0, nextEnrollments.filter(e => e.courseId === c.id).length) }
            : c
        )
      );
      logActivity(
        `${studentUser?.name || 'Student'} dropped course ${targetCourse?.name || courseId}`,
        `Course Code: ${targetCourse?.code || ''}`
      );
    } else {
      const newEnrollment: Enrollment = {
        id: `E${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        studentId: targetStudentId,
        courseId,
        enrolledAt: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
      };
      const nextEnrollments = [...enrollments, newEnrollment];
      setEnrollments(nextEnrollments);
      setCourses(prev =>
        prev.map(c =>
          c.id === courseId
            ? { ...c, enrolledCount: nextEnrollments.filter(e => e.courseId === c.id).length }
            : c
        )
      );
      logActivity(
        `${studentUser?.name || 'Student'} enrolled in course ${targetCourse?.name || courseId}`,
        `Course Code: ${targetCourse?.code || ''}`
      );
    }
  };

  // LMS Handlers
  const handleStudentSubmitAssignment = (assignmentId: string, fileName: string, fileBlob?: File | null) => {
    const assign = assignments.find(a => a.id === assignmentId);
    if (!assign || !currentUser) return;

    const calculatedSize = fileBlob
      ? `${(fileBlob.size / (1024 * 1024)).toFixed(1)} MB`
      : '1.4 MB';

    // Guaranteed globally unique ID to prevent React key and storage collisions
    const newSubId = `sub_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

    const newSub: Submission = {
      id: newSubId,
      assignmentId,
      assignmentTitle: assign.title,
      courseName: assign.courseName,
      studentId: currentUser.id,
      studentName: currentUser.name,
      fileName,
      fileSize: calculatedSize === '0.0 MB' ? '0.4 MB' : calculatedSize,
      submissionDate: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) +
        ', ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      status: 'Submitted',
      marks: null,
      feedback: ''
    };

    if (fileBlob) {
      saveStoredFile(newSub.id, fileBlob);
    }

    setSubmissions(prev => {
      // Check if THIS student already submitted this assignment, update if so, otherwise prepend
      const existingIdx = prev.findIndex(s => s.assignmentId === assignmentId && s.studentId === currentUser.id);
      if (existingIdx >= 0) {
        const next = [...prev];
        next[existingIdx] = newSub;
        return next;
      }
      return [newSub, ...prev];
    });

    // Section 34 requirement: Create simulated OS process
    const newProc: SimulatedProcess = {
      pid: `P${100 + processes.length + 1}`,
      name: `Submission: ${currentUser.name}`,
      taskType: 'File Processing',
      arrivalTime: 0,
      burstTime: 4,
      remainingTime: 4,
      priority: 2,
      memoryReq: 120,
      state: 'Ready',
      creationTime: newSub.submissionDate
    };
    setProcesses(prev => [...prev, newProc]);

    logActivity(`${currentUser.name} submitted ${assign.title}`, `File: ${fileName}`);
    logActivity(`Process ${newProc.pid} created (Assignment Submission)`);
  };

  const handleGradeSubmission = (submissionId: string, marks: number, feedback: string) => {
    setSubmissions(prev =>
      prev.map(s => (s.id === submissionId ? { ...s, marks, feedback, status: 'Graded' } : s))
    );
    logActivity(`Grade assigned for submission (${marks} marks)`);
  };

  const handleCreateCourse = (courseData: Partial<Course>) => {
    const newCourse: Course = {
      id: `C${100 + courses.length + 1}`,
      code: courseData.code || 'CS399',
      name: courseData.name || 'New Course',
      teacherId: currentUser?.id || 'U102',
      teacherName: currentUser?.name || 'Faculty',
      description: courseData.description || '',
      enrolledCount: courseData.enrolledCount || 20,
      materialsCount: 1,
      assignmentsCount: 1,
      isActive: true
    };
    setCourses(prev => [newCourse, ...prev]);
    logActivity(`Course created: ${newCourse.name} (${newCourse.code})`);
  };

  const handleUpdateCourse = (updatedCourse: Course) => {
    setCourses(prev => prev.map(c => (c.id === updatedCourse.id ? updatedCourse : c)));
    logActivity(`Course updated: ${updatedCourse.name} (${updatedCourse.code})`);
  };

  const handleDeleteCourse = (courseId: string) => {
    const course = courses.find(c => c.id === courseId);
    setCourses(prev => prev.filter(c => c.id !== courseId));
    logActivity(`Course deleted: ${course?.name || courseId}`);
  };

  const handleCreateAssignment = (assignmentData: Omit<Assignment, 'id'>) => {
    const newAssign: Assignment = {
      id: `A${100 + assignments.length + 1}`,
      ...assignmentData
    };
    setAssignments(prev => [newAssign, ...prev]);
    setCourses(prev =>
      prev.map(c => (c.id === newAssign.courseId ? { ...c, assignmentsCount: c.assignmentsCount + 1 } : c))
    );
    logActivity(`Assignment created: ${newAssign.title} (${newAssign.courseName})`);
  };

  const handleDeleteAssignment = (id: string) => {
    const assign = assignments.find(a => a.id === id);
    setAssignments(prev => prev.filter(a => a.id !== id));
    logActivity(`Assignment deleted: ${assign?.title || id}`);
  };

  const handleUpdateUser = (updatedUser: User) => {
    setUsers(prev => prev.map(u => (u.id === updatedUser.id ? updatedUser : u)));
    if (currentUser?.id === updatedUser.id) {
      setCurrentUser(updatedUser);
      localStorage.setItem('smartlms_logged_in_user', JSON.stringify(updatedUser));
    }
    logActivity(`User profile updated: ${updatedUser.name}`);
  };

  // OS Simulator Handlers
  const handleCreateProcess = (procData: Omit<SimulatedProcess, 'pid' | 'remainingTime' | 'creationTime'>) => {
    const newPid = `P${100 + processes.length + 1}`;
    const newProc: SimulatedProcess = {
      ...procData,
      pid: newPid,
      remainingTime: procData.burstTime,
      creationTime: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
    };
    setProcesses(prev => [...prev, newProc]);
    logActivity(`Process ${newPid} created (${newProc.name})`);
  };

  const handleUpdateProcessState = (pid: string, state: ProcessState) => {
    setProcesses(prev => prev.map(p => (p.pid === pid ? { ...p, state } : p)));
    logActivity(`Process ${pid} state changed to ${state}`);
  };

  const handleTerminateProcess = (pid: string) => {
    setProcesses(prev => prev.map(p => (p.pid === pid ? { ...p, state: 'Terminated', remainingTime: 0 } : p)));
    // Release memory if allocated
    setMemoryBlocks(prev => prev.map(b => (b.process === pid ? { ...b, status: 'Free', process: '-' } : b)));
    logActivity(`Process ${pid} terminated`);
  };

  const handleDeleteProcess = (pid: string) => {
    setProcesses(prev => prev.filter(p => p.pid !== pid));
    logActivity(`Process ${pid} deleted`);
  };

  const handleUploadMaterial = (matData: Partial<Material>, fileBlob?: File | null) => {
    const newMat: Material = {
      id: `M${Date.now().toString().slice(-4)}`,
      courseId: 'C101',
      courseName: matData.courseName || 'Operating Systems',
      title: matData.title || matData.fileName || 'Lecture_Notes.pdf',
      fileName: matData.fileName || 'Lecture_Notes.pdf',
      fileType: matData.fileType || 'PDF',
      fileSize: matData.fileSize || '2.1 MB',
      uploadedBy: currentUser?.name || 'Dr. Sharma',
      date: 'Today',
      description: matData.description
    };
    if (fileBlob) {
      saveStoredFile(newMat.id, fileBlob);
    }
    setMaterials(prev => [...prev, newMat]);
    logActivity(`${currentUser?.name} uploaded material: ${newMat.fileName}`);
  };

  const handleDeleteMaterial = (id: string) => {
    setMaterials(prev => prev.filter(m => m.id !== id));
    logActivity('Material deleted');
  };

  const handleDeleteSubmission = (id: string) => {
    setSubmissions(prev => prev.filter(s => s.id !== id));
    logActivity('Submission removed');
  };

  const handleAddUser = (userData: Partial<User>) => {
    const newUser: User = {
      id: `U${100 + users.length + 1}`,
      name: userData.name || 'New User',
      username: userData.username || 'user',
      role: userData.role || 'student',
      email: userData.email || 'user@smartlms.edu',
      isActive: true,
      createdAt: 'Today'
    };
    setUsers(prev => [...prev, newUser]);
    logActivity(`New user (${newUser.name}) registered`, `Role: ${newUser.role}`);
  };

  const handleToggleUserStatus = (userId: string) => {
    setUsers(prev => prev.map(u => (u.id === userId ? { ...u, isActive: !u.isActive } : u)));
    logActivity('User account status updated');
  };

  const handleResetUserPassword = (userId: string) => {
    alert(`Temporary password reset email sent for user ${userId}.`);
    logActivity(`Password reset requested for ${userId}`);
  };

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem('smartlms_logged_in_user', JSON.stringify(user));
    setCurrentPage('dashboard');
    logActivity(`User logged in (${user.name}) as ${user.role.toUpperCase()}`);
  };

  const handleSignUp = async (userData: { name: string; username: string; password: string; role: Role }) => {
    const { hash, salt } = await hashPassword(userData.password);
    const cleanUsername = userData.username.toLowerCase().trim();
    const newUser: User = {
      id: `U${100 + users.length + 1}`,
      name: userData.name.trim(),
      username: cleanUsername,
      role: userData.role,
      email: `${cleanUsername}@smartlms.edu`,
      isActive: true,
      createdAt: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
      passwordHash: hash,
      salt
    };
    setUsers(prev => [...prev, newUser]);
    setCurrentUser(newUser);
    localStorage.setItem('smartlms_logged_in_user', JSON.stringify(newUser));
    setCurrentPage('dashboard');
    logActivity(
      `New user registered (${newUser.name}) as ${newUser.role.toUpperCase()}`,
      `Username: @${newUser.username}`
    );
  };

  const handleLogout = () => {
    if (currentUser) {
      logActivity(`User logged out (${currentUser.name})`);
    }
    setCurrentUser(null);
    localStorage.removeItem('smartlms_logged_in_user');
    setCurrentPage('dashboard');
  };

  if (!currentUser) {
    return <LoginModal onLogin={handleLogin} onSignUp={handleSignUp} availableUsers={users} />;
  }

  const getPageTitle = () => {
    switch (currentPage) {
      case 'dashboard':
        return currentUser.role === 'student' ? 'Student Dashboard' : currentUser.role === 'teacher' ? 'Teacher Dashboard' : 'Admin Dashboard';
      case 'manage_users':
        return 'Admin — Manage Users';
      case 'manage_courses':
        return 'Admin — Manage Courses';
      case 'system_activity':
        return 'Admin — System Activity';
      case 'process_management':
        return 'OS Simulator — Process Management';
      case 'cpu_scheduling':
        return 'OS Simulator — CPU Scheduling';
      case 'memory_management':
        return 'OS Simulator — Memory Management';
      case 'file_management':
        return 'OS Simulator — File Management';
      case 'synchronization':
        return 'OS Simulator — Synchronization Lab';
      case 'deadlock':
        return 'OS Simulator — Deadlock Detection';
      case 'my_courses':
        return 'My Courses';
      case 'assignments':
      case 'create_assignment':
        return 'Assignments';
      case 'materials':
      case 'upload_materials':
        return 'Course Materials';
      case 'view_submissions':
        return 'Student Submissions';
      case 'grades':
        return 'Grades & Academic Progress';
      case 'profile':
        return 'User Profile';
      case 'settings':
        return 'System Settings';
      default:
        return 'Smart LMS';
    }
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#F5F7FA] font-sans antialiased text-[#172033]">
      {/* Left Sidebar */}
      <Sidebar
        currentRole={currentUser.role}
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        onLogout={handleLogout}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Top Header */}
        <Header
          currentUser={currentUser}
          pageTitle={getPageTitle()}
        />

        {/* Dynamic Page Views */}
        <main className="flex-1 overflow-y-auto">
          {currentPage === 'dashboard' && (
            <>
              {currentUser.role === 'student' && (
                <StudentDashboard
                  currentUser={currentUser}
                  courses={courses}
                  assignments={assignments}
                  submissions={submissions.filter(s => s.studentId === currentUser.id || s.studentName.includes(currentUser.name))}
                  onSubmitAssignment={handleStudentSubmitAssignment}
                  onViewCourse={() => setCurrentPage('my_courses')}
                />
              )}
              {currentUser.role === 'teacher' && (
                <TeacherDashboard
                  currentUser={currentUser}
                  courses={courses}
                  submissions={submissions}
                  enrollments={enrollments}
                  users={users}
                  onCreateCourse={handleCreateCourse}
                  onUpdateCourse={handleUpdateCourse}
                  onDeleteCourse={handleDeleteCourse}
                  onGradeSubmission={handleGradeSubmission}
                  onNavigate={setCurrentPage}
                />
              )}
              {currentUser.role === 'admin' && (
                <AdminDashboard
                  activityLogs={activityLogs}
                  onNavigate={setCurrentPage}
                  onOpenAddUser={() => setCurrentPage('manage_users')}
                  onOpenAddCourse={() => setCurrentPage('manage_courses')}
                />
              )}
            </>
          )}

          {/* OS Simulator Pages (Admin section) */}
          {currentPage === 'process_management' && (
            <ProcessManagement
              processes={processes}
              onCreateProcess={handleCreateProcess}
              onUpdateState={handleUpdateProcessState}
              onTerminateProcess={handleTerminateProcess}
              onDeleteProcess={handleDeleteProcess}
            />
          )}

          {currentPage === 'cpu_scheduling' && (
            <CpuScheduling onLogActivity={logActivity} />
          )}

          {currentPage === 'memory_management' && (
            <MemoryManagement
              memoryBlocks={memoryBlocks}
              onUpdateMemory={(newBlocks, desc) => {
                setMemoryBlocks(newBlocks);
                if (desc) logActivity(desc);
              }}
            />
          )}

          {currentPage === 'file_management' && (
            <FileManagement
              materials={materials}
              submissions={submissions}
              onUploadMaterial={handleUploadMaterial}
              onDeleteMaterial={handleDeleteMaterial}
              onDeleteSubmission={handleDeleteSubmission}
            />
          )}

          {currentPage === 'synchronization' && (
            <Synchronization onLogActivity={logActivity} />
          )}

          {currentPage === 'deadlock' && (
            <DeadlockSimulation onLogActivity={logActivity} />
          )}

          {/* Secondary Admin Views */}
          {currentPage === 'manage_users' && (
            <UserManagement
              users={users}
              onAddUser={handleAddUser}
              onToggleStatus={handleToggleUserStatus}
              onResetPassword={handleResetUserPassword}
            />
          )}

          {currentPage === 'manage_courses' && (
            <CourseManagement
              courses={courses}
              onCreateCourse={handleCreateCourse}
              onDeleteCourse={handleDeleteCourse}
            />
          )}

          {currentPage === 'system_activity' && (
            <ActivityLog logs={activityLogs} />
          )}

          {currentPage === 'settings' && (
            <SettingsPage
              onResetData={handleResetDemoData}
              onClearLogs={handleClearLogs}
              onLogActivity={logActivity}
            />
          )}

          {/* Dedicated Teacher Views */}
          {currentPage === 'create_assignment' && currentUser && (
            <CreateAssignmentPage
              currentUser={currentUser}
              courses={courses}
              assignments={assignments}
              submissions={submissions}
              onCreateAssignment={handleCreateAssignment}
              onDeleteAssignment={handleDeleteAssignment}
            />
          )}

          {currentPage === 'view_submissions' && currentUser && (
            <ViewSubmissionsPage
              currentUser={currentUser}
              courses={courses}
              assignments={assignments}
              submissions={submissions}
              onGradeSubmission={handleGradeSubmission}
            />
          )}

          {currentPage === 'upload_materials' && currentUser && (
            <UploadMaterialsPage
              currentUser={currentUser}
              courses={courses}
              materials={materials}
              onUploadMaterial={handleUploadMaterial}
              onDeleteMaterial={handleDeleteMaterial}
            />
          )}

          {/* Common Views (Grades & Profile) */}
          {currentPage === 'grades' && currentUser && (
            <GradesPage
              currentUser={currentUser}
              courses={courses}
              assignments={assignments}
              submissions={submissions}
            />
          )}

          {currentPage === 'profile' && currentUser && (
            <ProfilePage
              currentUser={currentUser}
              courses={courses}
              enrollments={enrollments}
              onToggleEnrollment={handleToggleEnrollment}
              onUpdateUser={handleUpdateUser}
            />
          )}

          {/* Dedicated Student Views */}
          {currentPage === 'my_courses' && (
            <div className="p-8 max-w-7xl mx-auto space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h1 className="text-2xl font-bold text-[#172033]">University Courses & Live Enrollment</h1>
                  <p className="text-sm text-slate-500 font-medium">Browse syllabus catalogs, join new courses, or drop electives in real time</p>
                </div>
                {currentUser?.role === 'student' && (
                  <span className="px-3 py-1.5 rounded-lg bg-blue-50 text-blue-700 text-xs font-bold border border-blue-200">
                    {enrollments.filter(e => e.studentId === currentUser.id).length} Active Enrollments
                  </span>
                )}
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {courses.map(c => {
                  const isEnrolled = currentUser?.role === 'student' && enrollments.some(e => e.courseId === c.id && e.studentId === currentUser.id);
                  const liveCount = enrollments.filter(e => e.courseId === c.id).length;

                  return (
                    <div key={c.id} className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="px-2.5 py-1 rounded-md bg-blue-50 text-blue-700 font-bold text-xs font-mono">
                            {c.code}
                          </span>
                          <span className="text-xs text-slate-500 font-medium flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-emerald-500" />
                            <span>{liveCount} {liveCount === 1 ? 'Student' : 'Students'} Enrolled</span>
                          </span>
                        </div>
                        <h3 className="font-bold text-base text-slate-900 mb-1">{c.name}</h3>
                        <p className="text-xs text-slate-500 mb-4">{c.description}</p>
                      </div>
                      <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                        <span className="text-xs text-slate-600 font-medium truncate">Instructor: {c.teacherName}</span>
                        <div className="flex items-center gap-2 shrink-0">
                          {currentUser?.role === 'student' && (
                            isEnrolled ? (
                              <button
                                type="button"
                                onClick={() => handleToggleEnrollment(c.id)}
                                className="px-3 py-1.5 border border-rose-200 text-rose-700 hover:bg-rose-50 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                                title="Drop this course"
                              >
                                Drop Course
                              </button>
                            ) : (
                              <button
                                type="button"
                                onClick={() => handleToggleEnrollment(c.id)}
                                className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer"
                                title="Enroll in this course"
                              >
                                + Enroll Now
                              </button>
                            )
                          )}
                          <button
                            type="button"
                            onClick={() => setCurrentPage('materials')}
                            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                          >
                            Materials
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {currentPage === 'assignments' && (
            <div className="p-8 max-w-7xl mx-auto space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-[#172033]">All Course Assignments</h1>
                <p className="text-sm text-slate-500 font-medium">Track deadlines, problem sets, and submit your solution reports</p>
              </div>
              <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs divide-y divide-slate-100">
                {assignments.map(a => {
                  const sub = submissions.find(s => s.assignmentId === a.id && s.studentId === currentUser?.id);
                  const isSubmitted = Boolean(sub);

                  return (
                    <div key={a.id} className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-bold text-[10px]">{a.courseName}</span>
                          <span className="font-bold text-sm text-slate-900">{a.title}</span>
                        </div>
                        <p className="text-xs text-slate-500">{a.description}</p>
                        <div className="text-[11px] text-slate-400 font-medium flex items-center gap-3 pt-1">
                          <span>Due: {a.dueDate}</span>
                          <span>• Max Marks: {a.maxMarks}</span>
                        </div>
                      </div>

                      <div>
                        {isSubmitted ? (
                          <div className="text-right">
                            <span className="px-2.5 py-1 rounded-md text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                              ✓ {sub?.status || 'Submitted'}
                            </span>
                            <div className="text-[10px] text-slate-400 font-mono mt-1">{sub?.fileName}</div>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setCurrentPage('dashboard')}
                            className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer"
                          >
                            Submit on Dashboard
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {currentPage === 'materials' && (
            <div className="p-8 max-w-7xl mx-auto space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-[#172033]">Course Study Materials</h1>
                <p className="text-sm text-slate-500 font-medium">Download verified lecture notes, reference PDFs, and syllabus handouts</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {materials.map(m => (
                  <div key={m.id} className="bg-white rounded-xl p-5 border border-slate-200/90 shadow-xs flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-bold text-[10px]">{m.courseName}</span>
                        <span className="text-xs text-slate-400 font-mono">{m.fileSize}</span>
                      </div>
                      <h3 className="font-bold text-sm text-slate-900 mb-1">{m.fileName}</h3>
                      <p className="text-xs text-slate-500 mb-3">{m.description || 'Verified course study handout.'}</p>
                    </div>
                    <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-[11px] text-slate-500">By {m.uploadedBy}</span>
                      <button
                        type="button"
                        onClick={async () => {
                          const stored = await getStoredFile(m.id);
                          const blob = stored || generateAcademicPdfBlob({
                            title: m.fileName,
                            course: m.courseName,
                            author: m.uploadedBy,
                            fileSize: m.fileSize,
                            description: m.description
                          });
                          const url = URL.createObjectURL(blob);
                          const link = document.createElement('a');
                          link.href = url;
                          link.download = m.fileName.endsWith('.pdf') ? m.fileName : `${m.fileName}.pdf`;
                          document.body.appendChild(link);
                          link.click();
                          document.body.removeChild(link);
                          setTimeout(() => URL.revokeObjectURL(url), 2000);
                        }}
                        className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-xs transition-colors cursor-pointer"
                      >
                        Download PDF
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
