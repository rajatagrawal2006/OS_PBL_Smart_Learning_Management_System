export type Role = 'student' | 'teacher' | 'admin';

export interface User {
  id: string;
  name: string;
  username: string;
  role: Role;
  email: string;
  isActive: boolean;
  createdAt: string;
  passwordHash?: string;
  salt?: string;
}

export interface Course {
  id: string;
  code: string;
  name: string;
  teacherId: string;
  teacherName: string;
  description: string;
  enrolledCount: number;
  materialsCount: number;
  assignmentsCount: number;
  isActive: boolean;
}

export interface Enrollment {
  id: string;
  studentId: string;
  courseId: string;
  enrolledAt: string;
}

export interface Assignment {
  id: string;
  courseId: string;
  courseName: string;
  title: string;
  description: string;
  dueDate: string;
  maxMarks: number;
  createdBy: string;
}

export interface Submission {
  id: string;
  assignmentId: string;
  assignmentTitle: string;
  courseName: string;
  studentId: string;
  studentName: string;
  fileName: string;
  fileSize: string;
  submissionDate: string;
  status: 'Submitted' | 'Graded' | 'Pending' | 'Late';
  marks?: number | null;
  feedback?: string;
}

export interface Material {
  id: string;
  courseId: string;
  courseName: string;
  title: string;
  fileName: string;
  fileType: string;
  fileSize: string;
  uploadedBy: string;
  date: string;
  description?: string;
}

export type ProcessState = 'New' | 'Ready' | 'Running' | 'Waiting' | 'Terminated';

export interface SimulatedProcess {
  pid: string;
  name: string;
  taskType: string;
  arrivalTime: number;
  burstTime: number;
  remainingTime: number;
  priority: number; // 1 = highest
  memoryReq: number; // in MB
  state: ProcessState;
  creationTime: string;
}

export interface GanttSegment {
  pid: string;
  start: number;
  end: number;
  isIdle?: boolean;
}

export interface SchedulingResult {
  algorithm: string;
  timeline: GanttSegment[];
  executionOrder: string;
  avgWaitingTime: number;
  avgTurnaroundTime: number;
  details: {
    pid: string;
    arrivalTime: number;
    burstTime: number;
    completionTime: number;
    turnaroundTime: number;
    waitingTime: number;
  }[];
}

export interface MemoryBlock {
  start: number;
  size: number;
  status: 'Allocated' | 'Free';
  process: string;
}

export interface ActivityEntry {
  id: string;
  timestamp: string;
  user: string;
  activity: string;
  details?: string;
}
