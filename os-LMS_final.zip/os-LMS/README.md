# Smart LMS — Learning Management System with OS Concepts

A complete undergraduate college-level desktop application written in **Python (Tkinter & ttk)** with an integrated **Operating System Simulator**.

---

## 🚀 Features Overview

### 1. Learning Management System (LMS)
- **Role-Based Access Control (RBAC):** Distinct dashboards and access permissions for **Student**, **Teacher**, and **Administrator**.
- **Secure Password Hashing:** Uses `PBKDF2-HMAC-SHA256` with unique cryptographic salts via standard library `hashlib` & `secrets`.
- **Course & Materials Management:** Upload syllabus notes, lecture slides, assignments, and download/preview resources.
- **Student Submissions & Grading:** Students submit assignments; submissions trigger local file archiving and **real-time OS simulation processes** (Section 34 integration). Teachers review and assign grades and feedback.
- **Central JSON Storage:** Reusable data repository for persistent state across sessions (`data/users.json`, `courses.json`, `materials.json`, `assignments.json`, `submissions.json`, `processes.json`, `activity_log.json`).

### 2. Operating System Simulator (Admin Section)
- **Process Management (Panel 4.1):**
  - Process creation, unique PID generator (`P101`, `P102`...).
  - State machine transitions: `NEW` ➔ `READY` ➔ `RUNNING` ➔ `WAITING` ➔ `TERMINATED`.
  - Process Control Block (PCB) inspector dialog showing memory allocation, registers, priority, arrival, and burst times.
- **CPU Scheduling (Panel 4.2):**
  - Pure mathematical Python implementation of **FCFS**, **SJF (non-preemptive)**, **Priority Scheduling (1 = Highest)**, and **Round Robin** with customizable Time Quantum.
  - Dynamically generated Tkinter Canvas **Gantt Chart** with precise time tick markers (`0`, `5`, `8`, `12`...).
  - Calculates Completion Time, Turnaround Time, Waiting Time, Average Waiting Time, and Average Turnaround Time.
- **Memory Management (Panel 4.3):**
  - Simulated pool of **1000 MB** with **First Fit** and **Best Fit** allocation algorithms.
  - Dynamic visual colored memory partition bar showing allocated vs free blocks.
  - Automatic coalescing (merging) of adjacent free blocks on deallocation.
  - Strict input validation against over-allocation, duplicate requests, and invalid sizes.
- **File Management (Panel 4.4):**
  - Course Materials vs Student Submissions tabs.
  - Real local filesystem operations using Python's `pathlib`, `os`, and `shutil`.
- **Synchronization Lab (Panel 4.5):**
  - Demonstrates classic **Producer–Consumer Problem** with bounded buffer (Size 5).
  - Uses `threading.Semaphore` and `threading.Lock` (mutex) preventing overflow when buffer is full and underflow when empty.
  - Real-time animated Producer Log & Consumer Log.
- **Deadlock Simulation (Panel 4.6):**
  - Resource Allocation Table (Processes $P_1, P_2, P_3$ vs Resources $R_1, R_2, R_3$).
  - Visual Resource Allocation Graph (RAG) with nodes and directional arrows.
  - Cycle detection algorithm pinpointing circular waits: e.g. `Cycle: P1 → R2 → P2 → R1 → P1`.

---

## 🔑 Demo Login Credentials

| Role | Username | Password |
|---|---|---|
| **Administrator** | `admin` | `admin123` |
| **Teacher** | `drsharma` | `teacher123` |
| **Student** | `rohan` | `student123` |

---

## 🛠️ How to Run Locally

### Requirements
- **Python 3.10+** (Tkinter is included by default on standard Windows/macOS Python distributions).
- No external packages or SQL servers required! Zero third-party pip dependencies.

### Launch Application
```bash
cd SmartLMS
python main.py
```
*(On Linux systems where Tkinter is not bundled, run `sudo apt install python3-tk`)*

---

## 🎓 College Viva / Project Explanation

- *"Smart LMS is an undergraduate college project combining a modern Learning Management System with an interactive Operating System Simulator."*
- *"The normal LMS handles student enrollments, course materials, assignments, and grading using local JSON storage and secure password hashing."*
- *"In the Admin section, the OS Simulator provides functional, interactive simulations of Process Management, CPU Scheduling, Memory Management, File I/O, Concurrency Synchronization, and Deadlock Detection."*
- *"The LMS and OS Simulator are logically separated, but connected: whenever a student submits an assignment or a teacher uploads material, an optional simulated process is queued in the OS Process Manager for scheduling."*
