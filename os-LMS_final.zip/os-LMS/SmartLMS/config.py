"""
Configuration and constants for Smart LMS with OS Simulator.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
UPLOADS_DIR = BASE_DIR / "uploads"
MATERIALS_DIR = UPLOADS_DIR / "materials"
SUBMISSIONS_DIR = UPLOADS_DIR / "submissions"
LOGS_DIR = BASE_DIR / "logs"

# Ensure essential directories exist
for directory in [DATA_DIR, UPLOADS_DIR, MATERIALS_DIR, SUBMISSIONS_DIR, LOGS_DIR]:
    directory.mkdir(parents=True, exist_ok=True)

# UI Colors matching blueprint
COLOR_PRIMARY_DARK = "#173B63"
COLOR_PRIMARY_BLUE = "#2563EB"
COLOR_BG_LIGHT = "#F5F7FA"
COLOR_CARD_WHITE = "#FFFFFF"
COLOR_TEXT_MAIN = "#172033"
COLOR_TEXT_MUTED = "#64748B"
COLOR_BORDER = "#E2E8F0"

COLOR_SUCCESS = "#16A34A"
COLOR_WARNING = "#F59E0B"
COLOR_DANGER = "#EF4444"
COLOR_INFO = "#0284C7"

# Process state colors
STATE_COLORS = {
    "NEW": "#64748B",
    "READY": "#16A34A",
    "RUNNING": "#2563EB",
    "WAITING": "#F59E0B",
    "TERMINATED": "#94A3B8",
}

DEFAULT_MEMORY_SIZE = 1000  # MB
BUFFER_SIZE = 5
