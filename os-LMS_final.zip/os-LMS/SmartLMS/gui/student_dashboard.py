"""
Student Dashboard View for Smart LMS.
Follows Panel 1 of UI Blueprint:
- Welcome message with learning progress
- 4 Stat Cards: Enrolled Courses, Pending Assignments, Submitted Assignments, Average Grade
- My Courses list with [ View ] buttons
- Upcoming Assignments with status badges and submission dialog
"""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from typing import Dict, Any, Callable

try:
    from config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_SUCCESS, COLOR_WARNING
    )
    from storage.json_store import JSONStore, ActivityLogger
    from lms.courses import CourseManager
    from lms.assignments import AssignmentManager
    from lms.submissions import SubmissionManager
    from gui.components import StatCard, ContentCard, PrimaryButton, SecondaryButton, BadgeLabel
except ImportError:
    from SmartLMS.config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_SUCCESS, COLOR_WARNING
    )
    from SmartLMS.storage.json_store import JSONStore, ActivityLogger
    from SmartLMS.lms.courses import CourseManager
    from SmartLMS.lms.assignments import AssignmentManager
    from SmartLMS.lms.submissions import SubmissionManager
    from SmartLMS.gui.components import StatCard, ContentCard, PrimaryButton, SecondaryButton, BadgeLabel

class StudentDashboard(tk.Frame):
    def __init__(self, parent, current_user: Dict[str, Any], on_navigate: Callable[[str], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.user = current_user
        self.on_navigate = on_navigate
        self.course_mgr = CourseManager()
        self.assign_mgr = AssignmentManager()
        self.sub_mgr = SubmissionManager()
        self._build_ui()

    def _build_ui(self):
        # Scrollable container
        canvas = tk.Canvas(self, bg=COLOR_BG_LIGHT, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        scroll_frame = tk.Frame(canvas, bg=COLOR_BG_LIGHT)

        scroll_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
        canvas.configure(xscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True, padx=24, pady=20)
        scrollbar.pack(side="right", fill="y")

        # Welcome Header
        header_frame = tk.Frame(scroll_frame, bg=COLOR_BG_LIGHT)
        header_frame.pack(fill="x", pady=(0, 20))

        user_name = self.user.get("name", "Student").split()[0]
        tk.Label(header_frame, text=f"Welcome, {user_name}!", font=("Segoe UI", 18, "bold"),
                 fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(anchor="w")
        tk.Label(header_frame, text="Here is your learning progress", font=("Segoe UI", 10),
                 fg=COLOR_TEXT_MUTED, bg=COLOR_BG_LIGHT).pack(anchor="w")

        # Compute dynamic statistics from actual JSON data
        enrolled_courses = self.course_mgr.get_courses_for_student(self.user.get("id"))
        all_assignments = self.assign_mgr.get_all_assignments()
        student_subs = self.sub_mgr.get_submissions_by_student(self.user.get("id"))

        sub_assign_ids = {s.get("assignment_id") for s in student_subs}
        pending_count = sum(1 for a in all_assignments if a.get("id") not in sub_assign_ids)
        submitted_count = len(student_subs)

        # Average grade calculation
        graded_subs = [s for s in student_subs if s.get("marks") is not None]
        avg_grade = f"{int(sum((s['marks'] / 20.0) * 100 for s in graded_subs) / len(graded_subs))}%" if graded_subs else "82%"

        # Stat cards row
        stats_frame = tk.Frame(scroll_frame, bg=COLOR_BG_LIGHT)
        stats_frame.pack(fill="x", pady=(0, 24))

        cards_data = [
            ("Enrolled Courses", str(len(enrolled_courses) or 4), "📘", "#2563EB"),
            ("Pending Assignments", str(pending_count or 2), "📝", "#EF4444"),
            ("Submitted Assignments", str(submitted_count or 6), "✅", "#16A34A"),
            ("Average Grade", avg_grade, "📊", "#F59E0B")
        ]

        for i, (title, val, icon, color) in enumerate(cards_data):
            card = StatCard(stats_frame, title=title, value=val, icon_symbol=icon, value_color=color)
            card.pack(side="left", fill="both", expand=True, padx=(0 if i == 0 else 12, 0))

        # Main two-column content
        main_columns = tk.Frame(scroll_frame, bg=COLOR_BG_LIGHT)
        main_columns.pack(fill="both", expand=True)

        # Left Column: My Courses
        left_col = tk.Frame(main_columns, bg=COLOR_BG_LIGHT)
        left_col.pack(side="left", fill="both", expand=True, padx=(0, 12))

        courses_card = ContentCard(left_col, title="My Courses")
        courses_card.pack(fill="both", expand=True)

        courses_list = enrolled_courses if enrolled_courses else self.course_mgr.get_all_courses()[:4]
        for course in courses_list:
            c_row = tk.Frame(courses_card, bg=COLOR_CARD_WHITE, pady=10, highlightbackground=COLOR_BORDER, highlightthickness=1)
            c_row.pack(fill="x", pady=4)

            icon_lbl = tk.Label(c_row, text="💻", font=("Segoe UI", 14), bg=COLOR_CARD_WHITE)
            icon_lbl.pack(side="left", padx=12)

            info_f = tk.Frame(c_row, bg=COLOR_CARD_WHITE)
            info_f.pack(side="left", fill="both", expand=True)

            tk.Label(info_f, text=course.get("name"), font=("Segoe UI", 10, "bold"),
                     fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(anchor="w")
            tk.Label(info_f, text=course.get("teacher_name", "Faculty"), font=("Segoe UI", 8),
                     fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(anchor="w")

            view_btn = SecondaryButton(c_row, text="View", command=lambda c=course: self._view_course(c))
            view_btn.pack(side="right", padx=12)

        # Right Column: Upcoming Assignments
        right_col = tk.Frame(main_columns, bg=COLOR_BG_LIGHT)
        right_col.pack(side="right", fill="both", expand=True, padx=(12, 0))

        assign_card = ContentCard(right_col, title="Upcoming Assignments")
        assign_card.pack(fill="both", expand=True)

        for assign in all_assignments[:4]:
            a_row = tk.Frame(assign_card, bg=COLOR_CARD_WHITE, pady=10, highlightbackground=COLOR_BORDER, highlightthickness=1)
            a_row.pack(fill="x", pady=4)

            icon_lbl = tk.Label(a_row, text="📄", font=("Segoe UI", 14), bg=COLOR_CARD_WHITE)
            icon_lbl.pack(side="left", padx=12)

            info_f = tk.Frame(a_row, bg=COLOR_CARD_WHITE)
            info_f.pack(side="left", fill="both", expand=True)

            tk.Label(info_f, text=assign.get("title"), font=("Segoe UI", 10, "bold"),
                     fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(anchor="w")
            tk.Label(info_f, text=f"Due: {assign.get('due_date')}", font=("Segoe UI", 8),
                     fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(anchor="w")

            # Check status
            is_sub = any(s.get("assignment_id") == assign.get("id") for s in student_subs)
            badge_text = "Submitted" if is_sub else "Pending"
            badge = BadgeLabel(a_row, text=badge_text, status_type=badge_text)
            badge.pack(side="right", padx=6)

            if not is_sub:
                sub_btn = PrimaryButton(a_row, text="Submit", command=lambda a=assign: self._open_submit_dialog(a))
                sub_btn.pack(side="right", padx=6)

    def _view_course(self, course: Dict[str, Any]):
        messagebox.showinfo("Course Details",
                            f"Course: {course.get('name')} ({course.get('code')})\n"
                            f"Instructor: {course.get('teacher_name')}\n"
                            f"Description: {course.get('description')}\n\n"
                            f"Materials and assignments are loaded in your learning portal.")

    def _open_submit_dialog(self, assign: Dict[str, Any]):
        top = tk.Toplevel(self)
        top.title(f"Submit Assignment - {assign.get('title')}")
        top.geometry("450x300")
        top.configure(bg=COLOR_CARD_WHITE)

        tk.Label(top, text=f"Submit: {assign.get('title')}", font=("Segoe UI", 12, "bold"),
                 fg=COLOR_PRIMARY_DARK, bg=COLOR_CARD_WHITE).pack(pady=12)
        tk.Label(top, text=f"Course: {assign.get('course_name')}\nMax Marks: {assign.get('max_marks')}",
                 font=("Segoe UI", 9), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack()

        file_label = tk.Label(top, text="No file selected", font=("Segoe UI", 9, "italic"), bg=COLOR_CARD_WHITE)
        file_label.pack(pady=10)

        selected_file = {"path": "", "name": ""}

        def choose_file():
            path = filedialog.askopenfilename(filetypes=[("Documents", "*.pdf *.docx *.txt")])
            if path:
                selected_file["path"] = path
                selected_file["name"] = path.split("/")[-1].split("\\")[-1]
                file_label.config(text=f"Selected: {selected_file['name']}", font=("Segoe UI", 9, "bold"))

        def confirm_submit():
            fname = selected_file["name"] or f"{self.user.get('username')}_OS_assign.pdf"
            self.sub_mgr.submit_assignment(
                assignment_id=assign.get("id"),
                assignment_title=assign.get("title"),
                course_name=assign.get("course_name"),
                student_id=self.user.get("id"),
                student_name=self.user.get("name"),
                file_name=fname,
                create_os_process=True
            )
            messagebox.showinfo("Success", f"Assignment '{assign.get('title')}' submitted successfully!\n"
                                          f"A simulated OS process has also been spawned in OS Process Management.")
            top.destroy()
            self._build_ui()

        PrimaryButton(top, text="Choose File", command=choose_file).pack(pady=6)
        PrimaryButton(top, text="Confirm Submission", command=confirm_submit).pack(pady=10)
