"""
Teacher Dashboard View for Smart LMS.
Follows Panel 2 of UI Blueprint:
- Welcome message: Dr. Sharma!
- 4 Stat Cards: My Courses, Total Students, Assignments, Total Submissions
- My Courses card with [+ Create Course] and [Manage] buttons
- Recent Submissions table with status badges and Grade action modal
"""
import tkinter as tk
from tkinter import ttk, messagebox
from typing import Dict, Any, Callable

try:
    from config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_SUCCESS, COLOR_WARNING
    )
    from storage.json_store import JSONStore, ActivityLogger
    from lms.courses import CourseManager
    from lms.assignments import AssignmentManager
    from lms.submissions import SubmissionManager
    from gui.components import StatCard, ContentCard, PrimaryButton, SecondaryButton, BadgeLabel
except ImportError:
    from SmartLMS.config import (
        COLOR_BG_LIGHT, COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_PRIMARY_BLUE, COLOR_PRIMARY_DARK, COLOR_BORDER, COLOR_SUCCESS, COLOR_WARNING
    )
    from SmartLMS.storage.json_store import JSONStore, ActivityLogger
    from SmartLMS.lms.courses import CourseManager
    from SmartLMS.lms.assignments import AssignmentManager
    from SmartLMS.lms.submissions import SubmissionManager
    from SmartLMS.gui.components import StatCard, ContentCard, PrimaryButton, SecondaryButton, BadgeLabel

class TeacherDashboard(tk.Frame):
    def __init__(self, parent, current_user: Dict[str, Any], on_navigate: Callable[[str], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.user = current_user
        self.on_navigate = on_navigate
        self.course_mgr = CourseManager()
        self.assign_mgr = AssignmentManager()
        self.sub_mgr = SubmissionManager()
        self._build_ui()

    def _build_ui(self):
        # Clear existing children if refreshed
        for widget in self.winfo_children():
            widget.destroy()

        canvas = tk.Canvas(self, bg=COLOR_BG_LIGHT, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        scroll_frame = tk.Frame(canvas, bg=COLOR_BG_LIGHT)

        scroll_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
        canvas.configure(xscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True, padx=24, pady=20)
        scrollbar.pack(side="right", fill="y")

        # Header
        header_frame = tk.Frame(scroll_frame, bg=COLOR_BG_LIGHT)
        header_frame.pack(fill="x", pady=(0, 20))

        teacher_name = self.user.get("name", "Faculty")
        tk.Label(header_frame, text=f"Welcome, {teacher_name}!", font=("Segoe UI", 18, "bold"),
                 fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(anchor="w")
        tk.Label(header_frame, text="Manage your courses and students", font=("Segoe UI", 10),
                 fg=COLOR_TEXT_MUTED, bg=COLOR_BG_LIGHT).pack(anchor="w")

        # Stats calculations
        teacher_id = self.user.get("id")
        my_courses = self.course_mgr.get_courses_by_teacher(teacher_id)
        if not my_courses:
            my_courses = self.course_mgr.get_all_courses()[:3]

        all_subs = self.sub_mgr.get_all_submissions()
        all_assigns = self.assign_mgr.get_all_assignments()

        stats_frame = tk.Frame(scroll_frame, bg=COLOR_BG_LIGHT)
        stats_frame.pack(fill="x", pady=(0, 24))

        cards_data = [
            ("My Courses", str(len(my_courses) or 3), "📘", "#2563EB"),
            ("Total Students", "45", "👥", "#16A34A"),
            ("Assignments", str(len(all_assigns) or 12), "📝", "#EF4444"),
            ("Total Submissions", str(len(all_subs) or 78), "📊", "#F59E0B")
        ]

        for i, (title, val, icon, color) in enumerate(cards_data):
            card = StatCard(stats_frame, title=title, value=val, icon_symbol=icon, value_color=color)
            card.pack(side="left", fill="both", expand=True, padx=(0 if i == 0 else 12, 0))

        # Two columns
        main_columns = tk.Frame(scroll_frame, bg=COLOR_BG_LIGHT)
        main_columns.pack(fill="both", expand=True)

        # Left: My Courses
        left_col = tk.Frame(main_columns, bg=COLOR_BG_LIGHT)
        left_col.pack(side="left", fill="both", expand=True, padx=(0, 12))

        course_header = tk.Frame(left_col, bg=COLOR_BG_LIGHT)
        course_header.pack(fill="x", pady=(0, 8))
        tk.Label(course_header, text="My Courses", font=("Segoe UI", 12, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(side="left")
        PrimaryButton(course_header, text="Create Course", command=self._open_create_course_dialog).pack(side="right")

        courses_card = ContentCard(left_col)
        courses_card.pack(fill="both", expand=True)

        for course in my_courses:
            c_row = tk.Frame(courses_card, bg=COLOR_CARD_WHITE, pady=10, highlightbackground=COLOR_BORDER, highlightthickness=1)
            c_row.pack(fill="x", pady=4)

            info_f = tk.Frame(c_row, bg=COLOR_CARD_WHITE)
            info_f.pack(side="left", fill="both", expand=True, padx=12)

            tk.Label(info_f, text=course.get("name"), font=("Segoe UI", 10, "bold"),
                     fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(anchor="w")
            tk.Label(info_f, text=f"Enrolled: {course.get('enrolled_count', 30)} students", font=("Segoe UI", 8),
                     fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(anchor="w")

            SecondaryButton(c_row, text="Manage", command=lambda c=course: self._manage_course(c)).pack(side="right", padx=12)

        # Right: Recent Submissions
        right_col = tk.Frame(main_columns, bg=COLOR_BG_LIGHT)
        right_col.pack(side="right", fill="both", expand=True, padx=(12, 0))

        sub_header = tk.Frame(right_col, bg=COLOR_BG_LIGHT)
        sub_header.pack(fill="x", pady=(0, 8))
        tk.Label(sub_header, text="Recent Submissions", font=("Segoe UI", 12, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_BG_LIGHT).pack(side="left")
        tk.Label(sub_header, text="View All", font=("Segoe UI", 9), fg=COLOR_PRIMARY_BLUE, bg=COLOR_BG_LIGHT).pack(side="right")

        subs_card = ContentCard(right_col)
        subs_card.pack(fill="both", expand=True)

        # Table header
        th = tk.Frame(subs_card, bg="#F8FAFC", pady=6)
        th.pack(fill="x")
        tk.Label(th, text="Student", font=("Segoe UI", 9, "bold"), width=12, anchor="w", bg="#F8FAFC").pack(side="left", padx=8)
        tk.Label(th, text="Assignment", font=("Segoe UI", 9, "bold"), width=16, anchor="w", bg="#F8FAFC").pack(side="left", padx=8)
        tk.Label(th, text="Status", font=("Segoe UI", 9, "bold"), width=10, anchor="w", bg="#F8FAFC").pack(side="left", padx=8)
        tk.Label(th, text="Action", font=("Segoe UI", 9, "bold"), width=8, anchor="center", bg="#F8FAFC").pack(side="right", padx=8)

        for sub in all_subs[:5]:
            s_row = tk.Frame(subs_card, bg=COLOR_CARD_WHITE, pady=8, highlightbackground=COLOR_BORDER, highlightthickness=1)
            s_row.pack(fill="x", pady=2)

            tk.Label(s_row, text=sub.get("student_name", "Student").split()[0], font=("Segoe UI", 9), width=12, anchor="w", bg=COLOR_CARD_WHITE).pack(side="left", padx=8)
            tk.Label(s_row, text=sub.get("assignment_title", "Assignment"), font=("Segoe UI", 9), width=16, anchor="w", bg=COLOR_CARD_WHITE).pack(side="left", padx=8)

            badge = BadgeLabel(s_row, text=sub.get("status", "Submitted"), status_type=sub.get("status", "Submitted"))
            badge.pack(side="left", padx=8)

            SecondaryButton(s_row, text="Grade", command=lambda s=sub: self._open_grade_dialog(s)).pack(side="right", padx=8)

    def _manage_course(self, course: Dict[str, Any]):
        messagebox.showinfo("Course Management",
                            f"Managing: {course.get('name')}\n"
                            f"Course Code: {course.get('code')}\n"
                            f"Enrolled Students: {course.get('enrolled_count', 30)}\n\n"
                            f"Use the 'Assignments' and 'Materials' tabs to add resources.")

    def _open_create_course_dialog(self):
        top = tk.Toplevel(self)
        top.title("Create New Course")
        top.geometry("450x360")
        top.configure(bg=COLOR_CARD_WHITE)

        tk.Label(top, text="Create New Course", font=("Segoe UI", 12, "bold"),
                 fg=COLOR_PRIMARY_DARK, bg=COLOR_CARD_WHITE).pack(pady=12)

        fields = [
            ("Course Code", "e.g. CS305"),
            ("Course Name", "e.g. Cloud Computing"),
            ("Description", "Key topics and syllabus outline")
        ]
        entries = {}
        for label, placeholder in fields:
            tk.Label(top, text=label, font=("Segoe UI", 9, "bold"), bg=COLOR_CARD_WHITE, anchor="w").pack(fill="x", padx=24, pady=(6, 2))
            e = tk.Entry(top, font=("Segoe UI", 10), relief="solid", bd=1)
            e.insert(0, placeholder)
            e.pack(fill="x", padx=24, pady=(0, 6), ipady=3)
            entries[label] = e

        def save():
            code = entries["Course Code"].get()
            name = entries["Course Name"].get()
            desc = entries["Description"].get()
            if not code or not name:
                messagebox.showerror("Error", "Please provide course code and name.")
                return
            self.course_mgr.create_course(
                code=code,
                name=name,
                description=desc,
                teacher_id=self.user.get("id"),
                teacher_name=self.user.get("name")
            )
            messagebox.showinfo("Success", f"Course '{name}' created successfully!")
            top.destroy()
            self._build_ui()

        PrimaryButton(top, text="Save Course", command=save).pack(pady=16)

    def _open_grade_dialog(self, submission: Dict[str, Any]):
        top = tk.Toplevel(self)
        top.title(f"Grade Submission - {submission.get('student_name')}")
        top.geometry("460x380")
        top.configure(bg=COLOR_CARD_WHITE)

        tk.Label(top, text="Grade Submission", font=("Segoe UI", 12, "bold"),
                 fg=COLOR_PRIMARY_DARK, bg=COLOR_CARD_WHITE).pack(pady=12)

        info_text = (f"Student: {submission.get('student_name')}\n"
                     f"Assignment: {submission.get('assignment_title')}\n"
                     f"File: {submission.get('file_name')} ({submission.get('file_size')})\n"
                     f"Submitted: {submission.get('submission_date')}")
        tk.Label(top, text=info_text, font=("Segoe UI", 9), justify="left", bg="#F8FAFC", padx=12, pady=8).pack(fill="x", padx=24)

        tk.Label(top, text="Marks Awarded (out of 20):", font=("Segoe UI", 9, "bold"), bg=COLOR_CARD_WHITE, anchor="w").pack(fill="x", padx=24, pady=(12, 2))
        marks_entry = tk.Entry(top, font=("Segoe UI", 10), relief="solid", bd=1)
        current_marks = submission.get("marks")
        if current_marks is not None:
            marks_entry.insert(0, str(current_marks))
        else:
            marks_entry.insert(0, "18")
        marks_entry.pack(fill="x", padx=24, pady=(0, 6), ipady=3)

        tk.Label(top, text="Teacher Feedback:", font=("Segoe UI", 9, "bold"), bg=COLOR_CARD_WHITE, anchor="w").pack(fill="x", padx=24, pady=(6, 2))
        feedback_entry = tk.Entry(top, font=("Segoe UI", 10), relief="solid", bd=1)
        feedback_entry.insert(0, submission.get("feedback") or "Good work on algorithm implementation.")
        feedback_entry.pack(fill="x", padx=24, pady=(0, 12), ipady=3)

        def save_grade():
            try:
                marks = int(marks_entry.get().strip())
            except ValueError:
                messagebox.showerror("Error", "Please enter a valid numeric mark.")
                return
            feedback = feedback_entry.get().strip()
            self.sub_mgr.grade_submission(
                submission_id=submission.get("id"),
                marks=marks,
                feedback=feedback,
                teacher_name=self.user.get("name")
            )
            messagebox.showinfo("Success", "Grade and feedback saved successfully!")
            top.destroy()
            self._build_ui()

        PrimaryButton(top, text="Save Grade", command=save_grade).pack(pady=12)
