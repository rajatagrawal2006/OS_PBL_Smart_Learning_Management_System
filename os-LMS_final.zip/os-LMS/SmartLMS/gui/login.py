"""
Login View for Smart LMS.
Provides role-separated authentication for:
1. Student Profile (opens Student Dashboard only)
2. Teacher Profile (opens Teacher Dashboard only)
3. Administrator Profile (opens Admin Dashboard & OS Simulator)

Validates credentials via PBKDF2-HMAC-SHA256 and passes authenticated user to main controller.
"""
import tkinter as tk
from tkinter import ttk, messagebox
from typing import Callable, Dict, Any

try:
    from config import (
        COLOR_PRIMARY_DARK, COLOR_PRIMARY_BLUE, COLOR_BG_LIGHT,
        COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_BORDER, COLOR_SUCCESS, COLOR_WARNING, COLOR_DANGER
    )
    from auth.authentication import Authenticator
    from storage.json_store import JSONStore, ActivityLogger
    from gui.components import PrimaryButton
except ImportError:
    from SmartLMS.config import (
        COLOR_PRIMARY_DARK, COLOR_PRIMARY_BLUE, COLOR_BG_LIGHT,
        COLOR_CARD_WHITE, COLOR_TEXT_MAIN, COLOR_TEXT_MUTED,
        COLOR_BORDER, COLOR_SUCCESS, COLOR_WARNING, COLOR_DANGER
    )
    from SmartLMS.auth.authentication import Authenticator
    from SmartLMS.storage.json_store import JSONStore, ActivityLogger
    from SmartLMS.gui.components import PrimaryButton

class LoginFrame(tk.Frame):
    def __init__(self, parent, on_login_success: Callable[[Dict[str, Any]], None]):
        super().__init__(parent, bg=COLOR_BG_LIGHT)
        self.on_login_success = on_login_success
        self.users_store = JSONStore("users.json")
        self.selected_role = "student"  # 'student', 'teacher', or 'admin'
        self._build_ui()

    def _build_ui(self):
        # Clear if re-building
        for w in self.winfo_children():
            w.destroy()

        container = tk.Frame(self, bg=COLOR_BG_LIGHT)
        container.place(relx=0.5, rely=0.5, anchor="center")

        # Main Login Card
        card = tk.Frame(
            container, bg=COLOR_CARD_WHITE, padx=40, pady=32,
            highlightbackground=COLOR_BORDER, highlightthickness=1
        )
        card.pack()

        # Logo / Brand Header
        logo_frame = tk.Frame(card, bg=COLOR_CARD_WHITE)
        logo_frame.pack(pady=(0, 16))

        tk.Label(
            logo_frame, text="🎓 Smart LMS",
            font=("Segoe UI", 22, "bold"),
            fg=COLOR_PRIMARY_DARK, bg=COLOR_CARD_WHITE
        ).pack()

        tk.Label(
            logo_frame, text="Learning Management System with OS Concepts",
            font=("Segoe UI", 9),
            fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE
        ).pack(pady=(2, 0))

        # Role Selector Buttons (Student / Teacher / Admin Profiles)
        role_select_frame = tk.Frame(card, bg="#F1F5F9", padx=4, pady=4, highlightbackground=COLOR_BORDER, highlightthickness=1)
        role_select_frame.pack(fill="x", pady=(0, 18))

        roles = [
            ("student", "👨‍🎓 Student", "rohan", "student123"),
            ("teacher", "👨‍🏫 Teacher", "drsharma", "teacher123"),
            ("admin", "🛡️ Admin", "admin", "admin123")
        ]

        self.role_buttons = {}
        for role_key, role_label, def_u, def_p in roles:
            is_active = self.selected_role == role_key
            btn = tk.Button(
                role_select_frame,
                text=role_label,
                font=("Segoe UI", 9, "bold" if is_active else "normal"),
                bg=COLOR_PRIMARY_BLUE if is_active else "#F1F5F9",
                fg="white" if is_active else COLOR_TEXT_MAIN,
                activebackground=COLOR_PRIMARY_BLUE,
                activeforeground="white",
                relief="flat",
                padx=10,
                pady=6,
                cursor="hand2",
                command=lambda r=role_key, u=def_u, p=def_p: self._select_role_profile(r, u, p)
            )
            btn.pack(side="left", fill="both", expand=True, padx=2)
            self.role_buttons[role_key] = btn

        # Role Info Banner
        role_descriptions = {
            "student": ("Student Profile", "Access your enrolled courses, submit assignments, and track grades."),
            "teacher": ("Teacher Profile", "Manage assigned courses, upload learning materials, and grade student submissions."),
            "admin": ("Administrator Profile", "Full system control with integrated Operating System Simulator suite.")
        }
        title_text, desc_text = role_descriptions.get(self.selected_role, ("", ""))

        self.info_banner = tk.Frame(card, bg="#EFF6FF", padx=12, pady=8, highlightbackground="#BFDBFE", highlightthickness=1)
        self.info_banner.pack(fill="x", pady=(0, 16))

        self.info_title = tk.Label(self.info_banner, text=title_text, font=("Segoe UI", 9, "bold"), fg="#1E40AF", bg="#EFF6FF")
        self.info_title.pack(anchor="w")

        self.info_desc = tk.Label(self.info_banner, text=desc_text, font=("Segoe UI", 8), fg="#3B82F6", bg="#EFF6FF", wraplength=340, justify="left")
        self.info_desc.pack(anchor="w")

        # Error label
        self.error_label = tk.Label(card, text="", font=("Segoe UI", 9), fg="#EF4444", bg=COLOR_CARD_WHITE)
        self.error_label.pack(pady=(0, 6))

        # Username Field
        tk.Label(card, text="Username", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE, anchor="w").pack(fill="x")
        self.username_var = tk.StringVar(value="rohan" if self.selected_role == "student" else ("drsharma" if self.selected_role == "teacher" else "admin"))
        self.username_entry = tk.Entry(card, textvariable=self.username_var, font=("Segoe UI", 11),
                                       relief="solid", bd=1, highlightthickness=0)
        self.username_entry.pack(fill="x", pady=(4, 12), ipady=4)

        # Password Field
        tk.Label(card, text="Password", font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE, anchor="w").pack(fill="x")
        self.password_var = tk.StringVar(value="student123" if self.selected_role == "student" else ("teacher123" if self.selected_role == "teacher" else "admin123"))
        self.password_entry = tk.Entry(card, textvariable=self.password_var, show="•", font=("Segoe UI", 11),
                                       relief="solid", bd=1, highlightthickness=0)
        self.password_entry.pack(fill="x", pady=(4, 18), ipady=4)
        self.password_entry.bind("<Return>", lambda e: self.do_login())

        # Login Button
        self.login_btn = PrimaryButton(card, text=f"Sign In as {self.selected_role.capitalize()}", command=self.do_login)
        self.login_btn.pack(fill="x", ipady=3)

        # Quick Demo Account Switcher
        demo_frame = tk.Frame(card, bg="#F8FAFC", padx=12, pady=10, highlightbackground=COLOR_BORDER, highlightthickness=1)
        demo_frame.pack(fill="x", pady=(20, 0))

        tk.Label(demo_frame, text="Quick Fill Demo Credentials:", font=("Segoe UI", 8, "bold"), fg=COLOR_TEXT_MUTED, bg="#F8FAFC").pack(anchor="w", pady=(0, 6))

        btn_row = tk.Frame(demo_frame, bg="#F8FAFC")
        btn_row.pack(fill="x")

        tk.Button(
            btn_row, text="Rohan (Student)", font=("Segoe UI", 8), bg="#E2E8F0", relief="flat", padx=6, pady=2,
            command=lambda: self._select_role_profile("student", "rohan", "student123")
        ).pack(side="left", padx=2)

        tk.Button(
            btn_row, text="Dr. Sharma (Teacher)", font=("Segoe UI", 8), bg="#E2E8F0", relief="flat", padx=6, pady=2,
            command=lambda: self._select_role_profile("teacher", "drsharma", "teacher123")
        ).pack(side="left", padx=2)

        tk.Button(
            btn_row, text="Admin", font=("Segoe UI", 8), bg="#E2E8F0", relief="flat", padx=6, pady=2,
            command=lambda: self._select_role_profile("admin", "admin", "admin123")
        ).pack(side="left", padx=2)

    def _select_role_profile(self, role: str, default_user: str, default_pass: str):
        self.selected_role = role
        self.username_var.set(default_user)
        self.password_var.set(default_pass)
        self.error_label.config(text="")
        self._build_ui()

    def do_login(self):
        username = self.username_var.get().strip()
        password = self.password_var.get().strip()

        if not username or not password:
            self.error_label.config(text="Please enter both username and password.")
            return

        users = self.users_store.load_all()
        matched = None
        for u in users:
            if u.get("username", "").lower() == username.lower():
                matched = u
                break

        if not matched:
            self.error_label.config(text="Invalid username or password.")
            return

        if not matched.get("is_active", True):
            self.error_label.config(text="Account deactivated. Contact administrator.")
            return

        is_valid = Authenticator.verify_password(matched.get("password_hash", ""), password)
        if not is_valid:
            self.error_label.config(text="Invalid username or password.")
            return

        # Verify role matches selected profile
        actual_role = matched.get("role", "")
        if self.selected_role and actual_role != self.selected_role:
            # Inform user if logging into a different role portal
            self.selected_role = actual_role

        ActivityLogger.log(f"User logged in ({matched.get('name')}) as {matched.get('role').upper()}", user=matched.get("name"))
        self.on_login_success(matched)
