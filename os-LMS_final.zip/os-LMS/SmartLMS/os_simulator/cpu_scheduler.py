"""
CPU Scheduling algorithms for Smart LMS OS Simulator.
Implements:
1. FCFS (First Come First Served)
2. SJF (Shortest Job First - Non Preemptive)
3. Priority Scheduling (Non Preemptive, smaller number = higher priority)
4. Round Robin (with configurable Time Quantum)

Calculates completion time, turnaround time, waiting time, execution order,
and dynamic Gantt chart blocks. Does NOT hardcode values.
"""
from typing import List, Dict, Any, Tuple
from storage.json_store import ActivityLogger

class CPUScheduler:
    @staticmethod
    def run_fcfs(processes: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        First-Come First-Served (Non-preemptive).
        Orders by arrival time (and tie-breaking by original index).
        """
        if not processes:
            return {"timeline": [], "results": [], "execution_order": "", "avg_wt": 0.0, "avg_tat": 0.0}

        procs = sorted(processes, key=lambda p: (p.get("arrival_time", 0)))
        current_time = 0
        timeline = []
        results = []

        for p in procs:
            pid = p["pid"]
            at = p.get("arrival_time", 0)
            bt = p.get("burst_time", 1)

            if current_time < at:
                # CPU Idle
                timeline.append({"pid": "IDLE", "start": current_time, "end": at, "is_idle": True})
                current_time = at

            start = current_time
            end = start + bt
            current_time = end

            timeline.append({"pid": pid, "start": start, "end": end, "is_idle": False})

            ct = end
            tat = ct - at
            wt = tat - bt
            results.append({
                "pid": pid,
                "arrival_time": at,
                "burst_time": bt,
                "completion_time": ct,
                "turnaround_time": tat,
                "waiting_time": wt
            })

        avg_wt = sum(r["waiting_time"] for r in results) / len(results) if results else 0
        avg_tat = sum(r["turnaround_time"] for r in results) / len(results) if results else 0
        execution_order = " → ".join(t["pid"] for t in timeline if not t.get("is_idle"))

        ActivityLogger.log("FCFS simulation executed", user="Admin", details=f"Avg WT: {avg_wt:.2f}, Avg TAT: {avg_tat:.2f}")

        return {
            "algorithm": "FCFS",
            "timeline": timeline,
            "results": results,
            "execution_order": execution_order,
            "avg_wt": round(avg_wt, 2),
            "avg_tat": round(avg_tat, 2)
        }

    @staticmethod
    def run_sjf(processes: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Shortest Job First (Non-preemptive).
        At each step, picks available process with smallest burst time.
        """
        if not processes:
            return {"timeline": [], "results": [], "execution_order": "", "avg_wt": 0.0, "avg_tat": 0.0}

        procs = [dict(p) for p in processes]
        completed = []
        timeline = []
        current_time = 0
        n = len(procs)

        while len(completed) < n:
            available = [p for p in procs if p.get("arrival_time", 0) <= current_time and p["pid"] not in [c["pid"] for c in completed]]
            
            if not available:
                # Advance time to next arrival
                uncompleted = [p for p in procs if p["pid"] not in [c["pid"] for c in completed]]
                next_at = min(p.get("arrival_time", 0) for p in uncompleted)
                timeline.append({"pid": "IDLE", "start": current_time, "end": next_at, "is_idle": True})
                current_time = next_at
                continue

            # Pick shortest burst time, tie break with arrival time
            selected = min(available, key=lambda p: (p.get("burst_time", 1), p.get("arrival_time", 0)))
            pid = selected["pid"]
            at = selected.get("arrival_time", 0)
            bt = selected.get("burst_time", 1)

            start = current_time
            end = start + bt
            current_time = end

            timeline.append({"pid": pid, "start": start, "end": end, "is_idle": False})
            ct = end
            tat = ct - at
            wt = tat - bt

            completed.append({
                "pid": pid,
                "arrival_time": at,
                "burst_time": bt,
                "completion_time": ct,
                "turnaround_time": tat,
                "waiting_time": wt
            })

        avg_wt = sum(r["waiting_time"] for r in completed) / len(completed) if completed else 0
        avg_tat = sum(r["turnaround_time"] for r in completed) / len(completed) if completed else 0
        execution_order = " → ".join(t["pid"] for t in timeline if not t.get("is_idle"))

        ActivityLogger.log("SJF simulation executed", user="Admin", details=f"Avg WT: {avg_wt:.2f}, Avg TAT: {avg_tat:.2f}")

        return {
            "algorithm": "SJF",
            "timeline": timeline,
            "results": completed,
            "execution_order": execution_order,
            "avg_wt": round(avg_wt, 2),
            "avg_tat": round(avg_tat, 2)
        }

    @staticmethod
    def run_priority(processes: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Priority Scheduling (Non-preemptive).
        Smaller number = Higher priority (e.g. Priority 1 > Priority 2).
        """
        if not processes:
            return {"timeline": [], "results": [], "execution_order": "", "avg_wt": 0.0, "avg_tat": 0.0}

        procs = [dict(p) for p in processes]
        completed = []
        timeline = []
        current_time = 0
        n = len(procs)

        while len(completed) < n:
            available = [p for p in procs if p.get("arrival_time", 0) <= current_time and p["pid"] not in [c["pid"] for c in completed]]
            
            if not available:
                uncompleted = [p for p in procs if p["pid"] not in [c["pid"] for c in completed]]
                next_at = min(p.get("arrival_time", 0) for p in uncompleted)
                timeline.append({"pid": "IDLE", "start": current_time, "end": next_at, "is_idle": True})
                current_time = next_at
                continue

            # Pick smallest priority value (highest priority)
            selected = min(available, key=lambda p: (p.get("priority", 1), p.get("arrival_time", 0)))
            pid = selected["pid"]
            at = selected.get("arrival_time", 0)
            bt = selected.get("burst_time", 1)

            start = current_time
            end = start + bt
            current_time = end

            timeline.append({"pid": pid, "start": start, "end": end, "is_idle": False})
            ct = end
            tat = ct - at
            wt = tat - bt

            completed.append({
                "pid": pid,
                "arrival_time": at,
                "burst_time": bt,
                "completion_time": ct,
                "turnaround_time": tat,
                "waiting_time": wt
            })

        avg_wt = sum(r["waiting_time"] for r in completed) / len(completed) if completed else 0
        avg_tat = sum(r["turnaround_time"] for r in completed) / len(completed) if completed else 0
        execution_order = " → ".join(t["pid"] for t in timeline if not t.get("is_idle"))

        ActivityLogger.log("Priority Scheduling simulation executed", user="Admin", details=f"Avg WT: {avg_wt:.2f}, Avg TAT: {avg_tat:.2f}")

        return {
            "algorithm": "Priority",
            "timeline": timeline,
            "results": completed,
            "execution_order": execution_order,
            "avg_wt": round(avg_wt, 2),
            "avg_tat": round(avg_tat, 2)
        }

    @staticmethod
    def run_round_robin(processes: List[Dict[str, Any]], quantum: int = 2) -> Dict[str, Any]:
        """
        Round Robin scheduling with time slice quantum.
        Handles arrivals during execution and re-queuing.
        """
        if not processes or quantum <= 0:
            return {"timeline": [], "results": [], "execution_order": "", "avg_wt": 0.0, "avg_tat": 0.0}

        quantum = int(quantum)
        sorted_procs = sorted(processes, key=lambda p: p.get("arrival_time", 0))
        rem_bt = {p["pid"]: p.get("burst_time", 1) for p in sorted_procs}
        arrival_map = {p["pid"]: p.get("arrival_time", 0) for p in sorted_procs}
        burst_map = {p["pid"]: p.get("burst_time", 1) for p in sorted_procs}

        current_time = 0
        ready_queue = []
        visited = set()
        timeline = []
        completion_times = {}

        # Initial queue push for processes arriving at time 0 or min arrival
        min_at = sorted_procs[0].get("arrival_time", 0)
        if min_at > 0:
            timeline.append({"pid": "IDLE", "start": 0, "end": min_at, "is_idle": True})
            current_time = min_at

        for p in sorted_procs:
            if p.get("arrival_time", 0) <= current_time and p["pid"] not in visited:
                ready_queue.append(p["pid"])
                visited.add(p["pid"])

        while ready_queue or len(visited) < len(sorted_procs) or any(rem_bt[p] > 0 for p in rem_bt):
            if not ready_queue:
                # Find next arriving process
                unvisited = [p for p in sorted_procs if p["pid"] not in visited]
                if unvisited:
                    next_p = min(unvisited, key=lambda p: p.get("arrival_time", 0))
                    timeline.append({"pid": "IDLE", "start": current_time, "end": next_p["arrival_time"], "is_idle": True})
                    current_time = next_p["arrival_time"]
                    ready_queue.append(next_p["pid"])
                    visited.add(next_p["pid"])
                else:
                    break

            pid = ready_queue.pop(0)
            exec_time = min(quantum, rem_bt[pid])
            start = current_time
            end = start + exec_time
            current_time = end
            rem_bt[pid] -= exec_time

            timeline.append({"pid": pid, "start": start, "end": end, "is_idle": False})

            # Check new arrivals during this execution window
            for p in sorted_procs:
                if p["pid"] not in visited and p.get("arrival_time", 0) <= current_time:
                    ready_queue.append(p["pid"])
                    visited.add(p["pid"])

            # If unfinished, re-add to ready queue
            if rem_bt[pid] > 0:
                ready_queue.append(pid)
            else:
                completion_times[pid] = current_time

        results = []
        for p in sorted_procs:
            pid = p["pid"]
            at = arrival_map[pid]
            bt = burst_map[pid]
            ct = completion_times.get(pid, 0)
            tat = ct - at
            wt = tat - bt
            results.append({
                "pid": pid,
                "arrival_time": at,
                "burst_time": bt,
                "completion_time": ct,
                "turnaround_time": tat,
                "waiting_time": wt
            })

        avg_wt = sum(r["waiting_time"] for r in results) / len(results) if results else 0
        avg_tat = sum(r["turnaround_time"] for r in results) / len(results) if results else 0
        execution_order = " → ".join(t["pid"] for t in timeline if not t.get("is_idle"))

        ActivityLogger.log(f"Round Robin simulation executed (Quantum={quantum})", user="Admin", details=f"Avg WT: {avg_wt:.2f}, Avg TAT: {avg_tat:.2f}")

        return {
            "algorithm": f"Round Robin (Q={quantum})",
            "timeline": timeline,
            "results": results,
            "execution_order": execution_order,
            "avg_wt": round(avg_wt, 2),
            "avg_tat": round(avg_tat, 2)
        }

    @staticmethod
    def run_sjf_preemptive(processes: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Shortest Remaining Time First (SRTF / SJF Preemptive).
        At each time unit, process with shortest remaining time is dispatched.
        """
        if not processes:
            return {"timeline": [], "results": [], "execution_order": "", "avg_wt": 0.0, "avg_tat": 0.0}

        n = len(processes)
        rem_bt = {p["pid"]: p.get("burst_time", 1) for p in processes}
        at_map = {p["pid"]: p.get("arrival_time", 0) for p in processes}
        bt_map = {p["pid"]: p.get("burst_time", 1) for p in processes}

        completed_count = 0
        current_time = 0
        completion_times = {}
        raw_timeline = []

        max_limit = 10000
        step = 0

        while completed_count < n and step < max_limit:
            step += 1
            available = [p for p in processes if at_map[p["pid"]] <= current_time and rem_bt[p["pid"]] > 0]

            if not available:
                future = [p for p in processes if rem_bt[p["pid"]] > 0]
                if not future:
                    break
                next_at = min(at_map[p["pid"]] for p in future)
                for t in range(current_time, next_at):
                    raw_timeline.append({"pid": "IDLE", "time": t})
                current_time = next_at
                continue

            # Pick shortest remaining time; tie-break on arrival time
            selected = min(available, key=lambda p: (rem_bt[p["pid"]], at_map[p["pid"]]))
            pid = selected["pid"]

            raw_timeline.append({"pid": pid, "time": current_time})
            rem_bt[pid] -= 1
            current_time += 1

            if rem_bt[pid] == 0:
                completed_count += 1
                completion_times[pid] = current_time

        # Compress into Gantt segments
        timeline = []
        if raw_timeline:
            curr_pid = raw_timeline[0]["pid"]
            seg_start = raw_timeline[0]["time"]
            for item in raw_timeline[1:]:
                if item["pid"] != curr_pid:
                    timeline.append({
                        "pid": curr_pid,
                        "start": seg_start,
                        "end": item["time"],
                        "is_idle": curr_pid == "IDLE"
                    })
                    curr_pid = item["pid"]
                    seg_start = item["time"]
            timeline.append({
                "pid": curr_pid,
                "start": seg_start,
                "end": current_time,
                "is_idle": curr_pid == "IDLE"
            })

        results = []
        for p in processes:
            pid = p["pid"]
            at = at_map[pid]
            bt = bt_map[pid]
            ct = completion_times.get(pid, 0)
            tat = ct - at
            wt = tat - bt
            results.append({
                "pid": pid,
                "arrival_time": at,
                "burst_time": bt,
                "completion_time": ct,
                "turnaround_time": tat,
                "waiting_time": wt
            })

        avg_wt = sum(r["waiting_time"] for r in results) / len(results) if results else 0
        avg_tat = sum(r["turnaround_time"] for r in results) / len(results) if results else 0
        execution_order = " → ".join(t["pid"] for t in timeline if not t.get("is_idle"))

        ActivityLogger.log("SJF Preemptive (SRTF) simulation executed", user="Admin", details=f"Avg WT: {avg_wt:.2f}, Avg TAT: {avg_tat:.2f}")

        return {
            "algorithm": "SJF Preemptive (SRTF)",
            "timeline": timeline,
            "results": results,
            "execution_order": execution_order,
            "avg_wt": round(avg_wt, 2),
            "avg_tat": round(avg_tat, 2)
        }
