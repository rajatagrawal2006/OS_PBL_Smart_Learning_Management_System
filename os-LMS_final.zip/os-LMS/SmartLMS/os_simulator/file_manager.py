"""
File Management module for Smart LMS and OS demonstration.
Demonstrates OS file operations (open, delete, rename, copy) using
Python's standard pathlib, os, and shutil.
"""
import os
import shutil
from pathlib import Path
from typing import List, Dict, Any, Tuple
from storage.json_store import JSONStore, ActivityLogger

try:
    from config import MATERIALS_DIR, SUBMISSIONS_DIR
except ImportError:
    from SmartLMS.config import MATERIALS_DIR, SUBMISSIONS_DIR

class LocalFileManager:
    def __init__(self):
        self.materials_store = JSONStore("materials.json")
        self.submissions_store = JSONStore("submissions.json")

    def get_course_materials(self) -> List[Dict[str, Any]]:
        return self.materials_store.load_all()

    def get_student_submissions(self) -> List[Dict[str, Any]]:
        return self.submissions_store.load_all()

    def save_material_file(self, src_path: str, course_id: str, course_name: str, 
                           title: str, user_name: str, user_id: str, desc: str = "") -> Tuple[bool, str]:
        src = Path(src_path)
        if not src.exists():
            return False, "Selected source file does not exist."

        filename = src.name
        dest = MATERIALS_DIR / filename
        counter = 1
        while dest.exists():
            dest = MATERIALS_DIR / f"{src.stem}_{counter}{src.suffix}"
            counter += 1

        try:
            shutil.copy2(src, dest)
            size_mb = f"{dest.stat().st_size / (1024 * 1024):.1f} MB"
            file_type = dest.suffix.replace('.', '').upper() or "FILE"

            mat_id = JSONStore.generate_id("M", [m.get("id") for m in self.get_course_materials()])
            material = {
                "id": mat_id,
                "course_id": course_id,
                "course_name": course_name,
                "title": title or dest.name,
                "file_name": dest.name,
                "file_type": file_type,
                "file_size": size_mb,
                "uploaded_by": user_name,
                "uploaded_by_id": user_id,
                "date": "Today",
                "description": desc
            }
            self.materials_store.add(material)
            ActivityLogger.log(f"File uploaded: {dest.name}", user=user_name, details=f"Size: {size_mb}")
            return True, f"Successfully uploaded {dest.name}."
        except Exception as e:
            return False, f"Failed to copy file: {e}"

    def delete_material(self, mat_id: str, user_name: str = "Admin") -> Tuple[bool, str]:
        mat = self.materials_store.get_by_id(mat_id)
        if not mat:
            return False, "File metadata not found."

        file_name = mat.get("file_name", "")
        file_path = MATERIALS_DIR / file_name
        if file_path.exists():
            try:
                os.remove(file_path)
            except Exception as e:
                print(f"Warning: could not delete physical file: {e}")

        self.materials_store.delete(mat_id)
        ActivityLogger.log(f"File deleted: {file_name}", user=user_name)
        return True, f"File {file_name} deleted."

    def delete_submission_file(self, sub_id: str, user_name: str = "Admin") -> Tuple[bool, str]:
        sub = self.submissions_store.get_by_id(sub_id)
        if not sub:
            return False, "Submission metadata not found."

        file_name = sub.get("file_name", "")
        file_path = SUBMISSIONS_DIR / file_name
        if file_path.exists():
            try:
                os.remove(file_path)
            except Exception:
                pass

        self.submissions_store.delete(sub_id)
        ActivityLogger.log(f"Submission deleted: {file_name}", user=user_name)
        return True, f"Submission {file_name} deleted."
