"""
Process Management OS Simulator.
Demonstrates PCB, process states (NEW, READY, RUNNING, WAITING, TERMINATED),
process creation, and lifecycle termination.
"""
from typing import List, Dict, Any, Optional
from datetime import datetime
from storage.json_store import JSONStore, ActivityLogger

VALID_STATES = ["NEW", "READY", "RUNNING", "WAITING", "TERMINATED"]

class ProcessManager:
    def __init__(self):
        self.store = JSONStore("processes.json")

    def get_all_processes(self) -> List[Dict[str, Any]]:
        return self.store.load_all()

    def get_active_processes(self) -> List[Dict[str, Any]]:
        return [p for p in self.get_all_processes() if p.get("state") != "TERMINATED"]

    def create_process(self, name: str, task_type: str, arrival_time: int,
                       burst_time: int, priority: int, memory_req: int) -> Dict[str, Any]:
        existing = [p.get("pid") for p in self.get_all_processes()]
        pid = JSONStore.generate_id("P", existing)
        proc = {
            "pid": pid,
            "name": name.strip(),
            "task_type": task_type.strip(),
            "arrival_time": max(0, int(arrival_time)),
            "burst_time": max(1, int(burst_time)),
            "remaining_time": max(1, int(burst_time)),
            "priority": max(1, int(priority)),
            "memory_req": max(10, int(memory_req)),
            "state": "Ready",
            "creation_time": datetime.now().strftime("%d %b %Y, %I:%M %p")
        }
        self.store.add(proc)
        ActivityLogger.log(f"Process {pid} created ({name})", user="Admin", details=f"BT: {burst_time}, Priority: {priority}")
        return proc

    def change_process_state(self, pid: str, new_state: str, user: str = "Admin") -> bool:
        if new_state.upper() not in VALID_STATES and new_state.capitalize() not in ["New", "Ready", "Running", "Waiting", "Terminated"]:
            return False
        
        proc = self.store.get_by_id(pid, id_key="pid")
        if not proc:
            return False
            
        success = self.store.update(pid, {"state": new_state.capitalize()}, id_key="pid")
        if success:
            ActivityLogger.log(f"Process {pid} state changed to {new_state}", user=user)
        return success

    def terminate_process(self, pid: str, user: str = "Admin", release_memory: bool = True) -> bool:
        proc = self.store.get_by_id(pid, id_key="pid")
        if not proc:
            return False
        
        success = self.store.update(pid, {"state": "Terminated", "remaining_time": 0}, id_key="pid")
        if success:
            ActivityLogger.log(f"Process {pid} terminated", user=user)
            if release_memory:
                # Release allocated memory block if any
                from os_simulator.memory_manager import MemoryManager
                MemoryManager().release_memory(pid, user=user)
        return success

    def delete_process(self, pid: str, user: str = "Admin") -> bool:
        success = self.store.delete(pid, id_key="pid")
        if success:
            ActivityLogger.log(f"Process {pid} removed from record", user=user)
        return success

    def get_pcb(self, pid: str) -> Optional[Dict[str, Any]]:
        return self.store.get_by_id(pid, id_key="pid")
