"""
Synchronization Lab OS Simulator for Smart LMS.
Demonstrates the classic Producer-Consumer Problem using a Bounded Buffer (Size 5),
threading.Semaphore, threading.Lock, and queue simulation.
"""
import threading
import time
from typing import List, Dict, Any, Callable, Optional

BUFFER_CAPACITY = 5

class ProducerConsumerLab:
    def __init__(self, capacity: int = BUFFER_CAPACITY):
        self.capacity = capacity
        self.buffer: List[str] = ["A", "B", "C"]  # Seeded initial matching blueprint!
        self.producer_log: List[str] = ["Produced: A", "Produced: B", "Produced: C"]
        self.consumer_log: List[str] = ["Consumed: A", "Consumed: B"]
        
        self.mutex = threading.Lock()
        self.empty_semaphore = threading.Semaphore(self.capacity - len(self.buffer))
        self.full_semaphore = threading.Semaphore(len(self.buffer))
        
        self.item_counter = ord('D')
        self.is_running = False
        self.worker_thread: Optional[threading.Thread] = None
        self.on_update: Optional[Callable[[], None]] = None

    def get_state(self) -> Dict[str, Any]:
        with self.mutex:
            return {
                "buffer": list(self.buffer),
                "capacity": self.capacity,
                "empty_slots": self.capacity - len(self.buffer),
                "full_slots": len(self.buffer),
                "producer_log": list(self.producer_log[-15:]),
                "consumer_log": list(self.consumer_log[-15:]),
                "is_running": self.is_running
            }

    def produce_item(self) -> bool:
        """Produce an item if buffer has space."""
        # Try acquiring empty slot
        acquired = self.empty_semaphore.acquire(blocking=False)
        if not acquired:
            return False  # Buffer is full

        with self.mutex:
            if len(self.buffer) < self.capacity:
                item_name = chr(self.item_counter)
                self.item_counter = 65 + ((self.item_counter - 65 + 1) % 26)  # Wrap A-Z
                self.buffer.append(item_name)
                self.producer_log.append(f"Produced: {item_name}")
                self.full_semaphore.release()
                if self.on_update:
                    self.on_update()
                return True
            else:
                self.empty_semaphore.release()
                return False

    def consume_item(self) -> bool:
        """Consume an item if buffer is not empty."""
        acquired = self.full_semaphore.acquire(blocking=False)
        if not acquired:
            return False  # Buffer is empty

        with self.mutex:
            if len(self.buffer) > 0:
                item_name = self.buffer.pop(0)
                self.consumer_log.append(f"Consumed: {item_name}")
                self.empty_semaphore.release()
                if self.on_update:
                    self.on_update()
                return True
            else:
                self.full_semaphore.release()
                return False

    def reset(self):
        self.pause()
        with self.mutex:
            self.buffer = []
            self.producer_log = []
            self.consumer_log = []
            self.item_counter = ord('A')
            self.empty_semaphore = threading.Semaphore(self.capacity)
            self.full_semaphore = threading.Semaphore(0)
        if self.on_update:
            self.on_update()

    def start(self, interval: float = 1.2):
        if self.is_running:
            return
        self.is_running = True
        self.worker_thread = threading.Thread(target=self._run_loop, args=(interval,), daemon=True)
        self.worker_thread.start()

    def pause(self):
        self.is_running = False

    def _run_loop(self, interval: float):
        turn = 0
        while self.is_running:
            time.sleep(interval)
            if not self.is_running:
                break
            if turn % 2 == 0:
                self.produce_item()
            else:
                self.consume_item()
            turn += 1
