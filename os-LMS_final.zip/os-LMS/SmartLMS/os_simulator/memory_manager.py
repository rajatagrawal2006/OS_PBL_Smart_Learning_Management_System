"""
Memory Management OS Simulator for Smart LMS.
Implements:
1. First Fit Allocation
2. Best Fit Allocation
3. Memory Release and Adjacent Block Coalescing (Merging)
4. Comprehensive Validation & Simulated Pool of 1000 MB
"""
from typing import List, Dict, Any, Tuple
from storage.json_store import JSONStore, ActivityLogger

TOTAL_MEMORY_SIZE = 1000  # MB

class MemoryManager:
    def __init__(self):
        self.store = JSONStore("memory.json")
        self._ensure_init()

    def _ensure_init(self):
        blocks = self.store.load_all()
        if not blocks:
            initial = [{"start": 0, "size": TOTAL_MEMORY_SIZE, "status": "Free", "process": "-"}]
            self.store.save_all(initial)

    def get_memory_state(self) -> List[Dict[str, Any]]:
        return self.store.load_all()

    def get_summary(self) -> Dict[str, Any]:
        blocks = self.get_memory_state()
        allocated = sum(b["size"] for b in blocks if b["status"] == "Allocated")
        free_mem = sum(b["size"] for b in blocks if b["status"] == "Free")
        utilization = round((allocated / TOTAL_MEMORY_SIZE) * 100, 1) if TOTAL_MEMORY_SIZE > 0 else 0
        return {
            "total": TOTAL_MEMORY_SIZE,
            "allocated": allocated,
            "free": free_mem,
            "utilization": utilization
        }

    def allocate_memory(self, process_id: str, size: int, algorithm: str = "First Fit", user: str = "Admin") -> Tuple[bool, str]:
        """
        Allocate memory using First Fit or Best Fit.
        Returns (success: bool, message: str).
        """
        if size <= 0:
            return False, "Requested memory size must be greater than zero."
        if size > TOTAL_MEMORY_SIZE:
            return False, f"Requested memory size ({size} MB) exceeds total pool capacity ({TOTAL_MEMORY_SIZE} MB)."

        blocks = self.get_memory_state()

        # Check for duplicate allocation
        for b in blocks:
            if b["status"] == "Allocated" and b["process"].lower() == process_id.lower():
                return False, f"Process {process_id} already has an active memory allocation of {b['size']} MB."

        # Find suitable free blocks
        free_indices = [i for i, b in enumerate(blocks) if b["status"] == "Free" and b["size"] >= size]
        if not free_indices:
            return False, f"Memory allocation failed: No suitable free block available for {size} MB."

        target_idx = -1
        if algorithm == "First Fit":
            target_idx = free_indices[0]
        elif algorithm == "Best Fit":
            # Smallest free block that is still >= size
            target_idx = min(free_indices, key=lambda i: blocks[i]["size"])
        else:
            target_idx = free_indices[0]

        target_block = blocks[target_idx]
        rem_size = target_block["size"] - size

        new_allocated = {
            "start": target_block["start"],
            "size": size,
            "status": "Allocated",
            "process": process_id
        }

        if rem_size > 0:
            new_free = {
                "start": target_block["start"] + size,
                "size": rem_size,
                "status": "Free",
                "process": "-"
            }
            blocks[target_idx] = new_allocated
            blocks.insert(target_idx + 1, new_free)
        else:
            blocks[target_idx] = new_allocated

        self.store.save_all(blocks)
        ActivityLogger.log(f"Memory allocated to {process_id} ({size} MB via {algorithm})", user=user)
        return True, f"Successfully allocated {size} MB to {process_id} at address {new_allocated['start']} MB."

    def release_memory(self, process_id: str, user: str = "Admin") -> Tuple[bool, str]:
        """
        Release memory allocated to process_id and coalesce adjacent free blocks.
        """
        blocks = self.get_memory_state()
        found_idx = -1
        released_size = 0

        for i, b in enumerate(blocks):
            if b["status"] == "Allocated" and b["process"].lower() == process_id.lower():
                found_idx = i
                released_size = b["size"]
                break

        if found_idx == -1:
            return False, f"No active memory allocation found for process '{process_id}'."

        blocks[found_idx]["status"] = "Free"
        blocks[found_idx]["process"] = "-"

        # Coalesce adjacent free blocks
        merged = []
        for b in blocks:
            if not merged:
                merged.append(dict(b))
            else:
                last = merged[-1]
                if last["status"] == "Free" and b["status"] == "Free":
                    last["size"] += b["size"]
                else:
                    merged.append(dict(b))

        self.store.save_all(merged)
        ActivityLogger.log(f"Memory released from {process_id} ({released_size} MB)", user=user)
        return True, f"Successfully released {released_size} MB from {process_id}."

    def reset_memory(self, user: str = "Admin"):
        initial = [{"start": 0, "size": TOTAL_MEMORY_SIZE, "status": "Free", "process": "-"}]
        self.store.save_all(initial)
        ActivityLogger.log("Memory pool reset to initial 1000 MB free state", user=user)
