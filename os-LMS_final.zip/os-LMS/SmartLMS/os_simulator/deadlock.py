"""
Deadlock Simulation module for Smart LMS OS Simulator.
Implements:
1. Resource Allocation Table (Processes P1..Pn, Resources R1..Rm)
2. Cycle Detection in Resource Allocation Graph (RAG)
3. Banker's Algorithm Safety State Check & Safe Sequence generation
4. Step-by-step evaluation trace for interactive simulation
"""
from typing import List, Dict, Any, Tuple, Optional

try:
    from storage.json_store import ActivityLogger
except ImportError:
    try:
        from SmartLMS.storage.json_store import ActivityLogger
    except ImportError:
        class ActivityLogger:
            @staticmethod
            def log(*args, **kwargs):
                pass

class DeadlockDetector:
    def __init__(self):
        self.processes = ["P1", "P2", "P3"]
        self.resources = ["R1", "R2", "R3"]
        
        # Default allocation matrix: Process holds Resource
        self.allocation: Dict[str, Dict[str, int]] = {
            "P1": {"R1": 1, "R2": 0, "R3": 0},
            "P2": {"R1": 0, "R2": 1, "R3": 0},
            "P3": {"R1": 0, "R2": 0, "R3": 1}
        }
        
        # Default request matrix: Process requests Resource (3-way circular wait)
        self.request: Dict[str, Dict[str, int]] = {
            "P1": {"R1": 0, "R2": 1, "R3": 0},
            "P2": {"R1": 0, "R2": 0, "R3": 1},
            "P3": {"R1": 1, "R2": 0, "R3": 0}
        }

        # Available resources vector
        self.available: Dict[str, int] = {
            "R1": 0, "R2": 0, "R3": 0
        }

    def detect_deadlock(self) -> Dict[str, Any]:
        """
        Builds the Resource Allocation Graph:
        - Resource -> Process (Allocation edge: R held by P)
        - Process -> Resource (Request edge: P waits for R)
        Finds directed cycles and calculates Banker's safety state.
        """
        graph: Dict[str, List[str]] = {}
        for p in self.processes:
            graph[p] = []
        for r in self.resources:
            graph[r] = []

        # Allocation edges: R -> P (Resource is allocated to Process)
        for p in self.processes:
            for r in self.resources:
                if self.allocation.get(p, {}).get(r, 0) > 0:
                    graph[r].append(p)

        # Request edges: P -> R (Process is requesting Resource)
        for p in self.processes:
            for r in self.resources:
                if self.request.get(p, {}).get(r, 0) > 0:
                    graph[p].append(r)

        # Detect cycle via DFS
        visited = set()
        rec_stack = []

        def dfs(node: str) -> Optional[List[str]]:
            visited.add(node)
            rec_stack.append(node)

            for neighbor in graph.get(node, []):
                if neighbor not in visited:
                    cycle = dfs(neighbor)
                    if cycle:
                        return cycle
                elif neighbor in rec_stack:
                    idx = rec_stack.index(neighbor)
                    return rec_stack[idx:] + [neighbor]

            rec_stack.pop()
            return None

        detected_cycle = None
        for node in list(graph.keys()):
            if node not in visited:
                cycle = dfs(node)
                if cycle:
                    detected_cycle = cycle
                    break

        # Also calculate Banker's Safety Sequence & simulation steps
        is_safe, safe_seq, sim_steps = self.run_bankers_safety()

        if detected_cycle:
            cycle_str = " -> ".join(detected_cycle)
            deadlocked_procs = [n for n in detected_cycle if n.startswith("P")]
            msg = f"Deadlock Detected!\nCycle: {cycle_str}"
            try:
                ActivityLogger.log("Deadlock simulation executed (Deadlock Detected)", user="Admin", details=cycle_str)
            except Exception:
                pass
            return {
                "has_deadlock": True,
                "cycle": detected_cycle,
                "cycle_string": cycle_str,
                "deadlocked_processes": deadlocked_procs,
                "is_safe": False,
                "safe_sequence": [],
                "safe_sequence_string": "None (Circular Wait prevents resolution)",
                "simulation_steps": sim_steps,
                "message": msg
            }
        else:
            safe_seq_str = " -> ".join(safe_seq) if safe_seq else "All processes satisfied"
            msg = f"No Deadlock Detected. System is safe.\nSafe Sequence: {safe_seq_str}"
            try:
                ActivityLogger.log("Deadlock simulation executed (No Deadlock)", user="Admin", details=f"Safe: {safe_seq_str}")
            except Exception:
                pass
            return {
                "has_deadlock": False,
                "cycle": [],
                "cycle_string": "",
                "deadlocked_processes": [],
                "is_safe": True,
                "safe_sequence": safe_seq,
                "safe_sequence_string": safe_seq_str,
                "simulation_steps": sim_steps,
                "message": msg
            }

    def run_bankers_safety(self) -> Tuple[bool, List[str], List[str]]:
        """
        Runs Banker's algorithm safety test using current Available vector,
        Allocation matrix, and Request matrix.
        Returns (is_safe, safe_sequence, simulation_steps).
        """
        work = dict(self.available)
        finish = {p: False for p in self.processes}
        safe_sequence: List[str] = []
        steps: List[str] = []

        steps.append(f"Initial Available (Work): {self._format_vector(work)}")

        step_num = 1
        while len(safe_sequence) < len(self.processes):
            found_candidate = False
            for p in self.processes:
                if not finish[p]:
                    # Check if request[p] <= work
                    can_allocate = all(self.request.get(p, {}).get(r, 0) <= work.get(r, 0) for r in self.resources)
                    if can_allocate:
                        req_vec = self._format_vector(self.request.get(p, {}))
                        alloc_vec = self._format_vector(self.allocation.get(p, {}))
                        for r in self.resources:
                            work[r] = work.get(r, 0) + self.allocation.get(p, {}).get(r, 0)
                        finish[p] = True
                        safe_sequence.append(p)
                        steps.append(
                            f"Step {step_num}: Process {p} needs {req_vec} <= Available. "
                            f"{p} completes & releases {alloc_vec}. Updated Available: {self._format_vector(work)}"
                        )
                        step_num += 1
                        found_candidate = True
                        break

            if not found_candidate:
                stuck = [p for p in self.processes if not finish[p]]
                steps.append(
                    f"Deadlock/Unsafe: Cannot satisfy requests for remaining processes with Available {self._format_vector(work)}. "
                    f"Stalled: {', '.join(stuck)}"
                )
                return False, [], steps

        seq_display = " -> ".join(safe_sequence)
        steps.append(f"Safe sequence established: {seq_display}. System is 100% deadlock-free!")
        return True, safe_sequence, steps

    def _format_vector(self, d: Dict[str, int]) -> str:
        items = [f"{r}:{d.get(r, 0)}" for r in self.resources]
        return "[" + ", ".join(items) + "]"

    def set_safe_state(self):
        """Set a realistic, clearly distinct safe scenario."""
        self.allocation = {
            "P1": {"R1": 0, "R2": 1, "R3": 0},
            "P2": {"R1": 2, "R2": 0, "R3": 0},
            "P3": {"R1": 0, "R2": 0, "R3": 2}
        }
        self.request = {
            "P1": {"R1": 0, "R2": 0, "R3": 1},
            "P2": {"R1": 0, "R2": 1, "R3": 0},
            "P3": {"R1": 0, "R2": 0, "R3": 0}
        }
        self.available = {
            "R1": 1, "R2": 0, "R3": 1
        }

    def set_deadlock_state(self):
        """Set classic 3-way circular wait deadlock scenario."""
        self.allocation = {
            "P1": {"R1": 1, "R2": 0, "R3": 0},
            "P2": {"R1": 0, "R2": 1, "R3": 0},
            "P3": {"R1": 0, "R2": 0, "R3": 1}
        }
        self.request = {
            "P1": {"R1": 0, "R2": 1, "R3": 0},
            "P2": {"R1": 0, "R2": 0, "R3": 1},
            "P3": {"R1": 1, "R2": 0, "R3": 0}
        }
        self.available = {
            "R1": 0, "R2": 0, "R3": 0
        }

    def reset_state(self):
        """Reset all tables and vectors to zeroes for custom user entry."""
        self.allocation = {p: {r: 0 for r in self.resources} for p in self.processes}
        self.request = {p: {r: 0 for r in self.resources} for p in self.processes}
        self.available = {r: 1 for r in self.resources}
