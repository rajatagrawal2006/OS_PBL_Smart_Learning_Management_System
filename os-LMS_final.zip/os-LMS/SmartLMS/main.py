"""
Main entry point for Smart LMS with OS Simulator.
Application Controller managing authentication, navigation, and replaceable views.
Recreates the exact UI blueprint layout:
- Deep navy sidebar (#173B63)
- Role-based navigation buttons with active page indicator
- Top bar with page title, user info, and role badge
- Seamless view swapping without opening separate windows
"""
import sys
import os
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox
from typing import Dict, Any, Optional

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import (
    COLOR_PRIMARY_DARK, COLOR_PRIMARY_BLUE, COLOR_BG_LIGHT, COLOR_CARD_WHITE,
    COLOR_TEXT_MAIN, COLOR_TEXT_MUTED, COLOR_BORDER
)
from storage.json_store import JSONStore, ActivityLogger
from gui.login import LoginFrame
from gui.student_dashboard import StudentDashboard
from gui.teacher_dashboard import TeacherDashboard
from gui.admin_dashboard import AdminDashboard
from gui.process_page import ProcessPage
from gui.scheduler_page import SchedulerPage
from gui.memory_page import MemoryPage
from gui.file_page import FilePage
from gui.synchronization_page import SynchronizationPage
from gui.deadlock_page import DeadlockPage
from gui.settings_page import SettingsPage

class SmartLMSApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Smart LMS — Learning Management System with OS Concepts")
        self.geometry("1280x760")
        self.minsize(1024, 600)
        self.configure(bg=COLOR_BG_LIGHT)

        # State
        self.current_user: Optional[Dict[str, Any]] = None
        self.current_page: str = "dashboard"
        self.sidebar_buttons: Dict[str, tk.Button] = {}

        # Shell Layout frames
        self.main_container = tk.Frame(self, bg=COLOR_BG_LIGHT)
        self.main_container.pack(fill="both", expand=True)

        self.sidebar_frame = tk.Frame(self.main_container, bg=COLOR_PRIMARY_DARK, width=240)
        self.content_container = tk.Frame(self.main_container, bg=COLOR_BG_LIGHT)

        self.top_bar = tk.Frame(self.content_container, bg=COLOR_CARD_WHITE, height=54,
                                highlightbackground=COLOR_BORDER, highlightthickness=1)
        self.page_frame = tk.Frame(self.content_container, bg=COLOR_BG_LIGHT)

        # Show Login initially
        self.show_login()

    def show_login(self):
        self.current_user = None
        self.sidebar_frame.pack_forget()
        self.content_container.pack_forget()

        # Clear container
        for w in self.main_container.winfo_children():
            w.destroy()

        login_view = LoginFrame(self.main_container, on_login_success=self.on_login_success)
        login_view.pack(fill="both", expand=True)

    def on_login_success(self, user: Dict[str, Any]):
        self.current_user = user
        for w in self.main_container.winfo_children():
            w.destroy()

        # Re-pack shell
        self.sidebar_frame = tk.Frame(self.main_container, bg=COLOR_PRIMARY_DARK, width=230)
        self.sidebar_frame.pack_propagate(False)
        self.sidebar_frame.pack(side="left", fill="y")

        self.content_container = tk.Frame(self.main_container, bg=COLOR_BG_LIGHT)
        self.content_container.pack(side="right", fill="both", expand=True)

        self.top_bar = tk.Frame(self.content_container, bg=COLOR_CARD_WHITE, height=54,
                                highlightbackground=COLOR_BORDER, highlightthickness=1)
        self.top_bar.pack(fill="x", side="top")

        self.page_frame = tk.Frame(self.content_container, bg=COLOR_BG_LIGHT)
        self.page_frame.pack(fill="both", expand=True, side="bottom")

        self._build_sidebar()
        self._build_topbar()
        self.navigate_to("dashboard")

    def _build_sidebar(self):
        for w in self.sidebar_frame.winfo_children():
            w.destroy()
        self.sidebar_buttons = {}

        # Brand header
        brand_frame = tk.Frame(self.sidebar_frame, bg=COLOR_PRIMARY_DARK, padx=18, pady=20)
        brand_frame.pack(fill="x")

        tk.Label(brand_frame, text="Smart LMS", font=("Segoe UI", 14, "bold"),
                 fg="white", bg=COLOR_PRIMARY_DARK).pack(anchor="w")

        role = self.current_user.get("role", "student")

        # Navigation items based on role (matching blueprint exactly)
        nav_items = []
        if role == "student":
            nav_items = [
                ("dashboard", "📊  Dashboard"),
                ("my_courses", "📘  My Courses"),
                ("assignments", "📝  Assignments"),
                ("materials", "📁  Materials"),
                ("grades", "🏆  Grades"),
                ("profile", "👤  Profile")
            ]
        elif role == "teacher":
            nav_items = [
                ("dashboard", "📊  Dashboard"),
                ("my_courses", "📘  My Courses"),
                ("create_assignment", "📝  Create Assignment"),
                ("view_submissions", "📄  View Submissions"),
                ("upload_materials", "📁  Upload Materials"),
                ("grades", "🏆  Grades"),
                ("profile", "👤  Profile")
            ]
        elif role == "admin":
            nav_items = [
                ("dashboard", "📊  Dashboard"),
                ("manage_users", "👥  Manage Users"),
                ("manage_courses", "📘  Manage Courses"),
                ("system_activity", "📋  System Activity"),
                ("SEPARATOR_OS", "OS SIMULATOR"),
                ("process_management", "  • Process Management"),
                ("cpu_scheduling", "  • CPU Scheduling"),
                ("memory_management", "  • Memory Management"),
                ("file_management", "  • File Management"),
                ("synchronization", "  • Synchronization"),
                ("deadlock", "  • Deadlock Simulation"),
                ("SEPARATOR_GEN", "SETTINGS"),
                ("settings", "⚙️  Settings")
            ]

        # Render nav buttons
        for item_id, label in nav_items:
            if item_id.startswith("SEPARATOR"):
                sep_f = tk.Frame(self.sidebar_frame, bg=COLOR_PRIMARY_DARK, padx=18, pady=(16, 4))
                sep_f.pack(fill="x")
                tk.Label(sep_f, text=label, font=("Segoe UI", 8, "bold"), fg="#93C5FD", bg=COLOR_PRIMARY_DARK).pack(anchor="w")
                continue

            btn = tk.Button(
                self.sidebar_frame,
                text=label,
                anchor="w",
                font=("Segoe UI", 9, "bold"),
                bg=COLOR_PRIMARY_DARK,
                fg="#CBD5E1",
                activebackground=COLOR_PRIMARY_BLUE,
                activeforeground="white",
                relief="flat",
                padx=18,
                pady=9,
                cursor="hand2",
                command=lambda pid=item_id: self.navigate_to(pid)
            )
            btn.pack(fill="x")
            self.sidebar_buttons[item_id] = btn

        # Logout at bottom
        logout_f = tk.Frame(self.sidebar_frame, bg=COLOR_PRIMARY_DARK)
        logout_f.pack(side="bottom", fill="x", pady=12)

        tk.Button(
            logout_f,
            text="🚪  Logout",
            anchor="w",
            font=("Segoe UI", 9, "bold"),
            bg=COLOR_PRIMARY_DARK,
            fg="#FCA5A5",
            activebackground="#EF4444",
            activeforeground="white",
            relief="flat",
            padx=18,
            pady=8,
            cursor="hand2",
            command=self.logout
        ).pack(fill="x")

    def _build_topbar(self):
        for w in self.top_bar.winfo_children():
            w.destroy()

        left_f = tk.Frame(self.top_bar, bg=COLOR_CARD_WHITE, padx=20)
        left_f.pack(side="left", fill="y")

        self.page_title_lbl = tk.Label(left_f, text="Dashboard", font=("Segoe UI", 12, "bold"),
                                       fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE)
        self.page_title_lbl.pack(side="left", pady=14)

        # Right user info
        right_f = tk.Frame(self.top_bar, bg=COLOR_CARD_WHITE, padx=20)
        right_f.pack(side="right", fill="y")

        role_badge = self.current_user.get("role", "User").capitalize()
        user_name = self.current_user.get("name", "User")

        # Notification bell
        tk.Label(right_f, text="🔔", font=("Segoe UI", 11), bg=COLOR_CARD_WHITE, cursor="hand2").pack(side="left", padx=10)

        # Avatar
        tk.Label(right_f, text="👤", font=("Segoe UI", 14), bg=COLOR_CARD_WHITE).pack(side="left", padx=(4, 6))

        info_box = tk.Frame(right_f, bg=COLOR_CARD_WHITE)
        info_box.pack(side="left")

        tk.Label(info_box, text=user_name, font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(anchor="w")
        tk.Label(info_box, text=role_badge, font=("Segoe UI", 8), fg=COLOR_PRIMARY_BLUE, bg=COLOR_CARD_WHITE).pack(anchor="w")

    def navigate_to(self, page_id: str):
        # Enforce Role-based access control (Requirement 52)
        role = self.current_user.get("role", "student")
        admin_pages = ["manage_users", "manage_courses", "system_activity", "process_management",
                       "cpu_scheduling", "memory_management", "file_management", "synchronization", "deadlock"]

        if page_id in admin_pages and role != "admin":
            messagebox.showerror("Access Denied", "You do not have permission to access administrative or OS simulator modules.")
            return

        self.current_page = page_id

        # Highlight active sidebar button
        for pid, btn in self.sidebar_buttons.items():
            if pid == page_id:
                btn.config(bg=COLOR_PRIMARY_BLUE, fg="white")
            else:
                btn.config(bg=COLOR_PRIMARY_DARK, fg="#CBD5E1")

        # Clear page content
        for w in self.page_frame.winfo_children():
            w.destroy()

        # Update top bar title
        page_titles = {
            "dashboard": "Dashboard Overview",
            "my_courses": "My Courses",
            "assignments": "Assignments",
            "materials": "Course Materials",
            "create_assignment": "Create Assignment",
            "view_submissions": "Student Submissions",
            "upload_materials": "Upload Materials",
            "grades": "Grades & Progress",
            "profile": "User Profile",
            "manage_users": "Admin — Manage Users",
            "manage_courses": "Admin — Manage Courses",
            "system_activity": "Admin — System Activity Log",
            "process_management": "OS Simulator — Process Management",
            "cpu_scheduling": "OS Simulator — CPU Scheduling",
            "memory_management": "OS Simulator — Memory Management",
            "file_management": "OS Simulator — File Management",
            "synchronization": "OS Simulator — Synchronization Lab",
            "deadlock": "OS Simulator — Deadlock Detection",
            "settings": "System Settings"
        }
        self.page_title_lbl.config(text=page_titles.get(page_id, "Smart LMS"))

        # Render corresponding page
        if page_id == "dashboard":
            if role == "student":
                StudentDashboard(self.page_frame, self.current_user, self.navigate_to).pack(fill="both", expand=True)
            elif role == "teacher":
                TeacherDashboard(self.page_frame, self.current_user, self.navigate_to).pack(fill="both", expand=True)
            else:
                AdminDashboard(self.page_frame, self.current_user, self.navigate_to).pack(fill="both", expand=True)
        elif page_id == "process_management":
            ProcessPage(self.page_frame, self.current_user, self.navigate_to).pack(fill="both", expand=True)
        elif page_id == "cpu_scheduling":
            SchedulerPage(self.page_frame, self.current_user, self.navigate_to).pack(fill="both", expand=True)
        elif page_id == "memory_management":
            MemoryPage(self.page_frame, self.current_user, self.navigate_to).pack(fill="both", expand=True)
        elif page_id == "file_management":
            FilePage(self.page_frame, self.current_user, self.navigate_to).pack(fill="both", expand=True)
        elif page_id == "synchronization":
            SynchronizationPage(self.page_frame, self.current_user, self.navigate_to).pack(fill="both", expand=True)
        elif page_id == "deadlock":
            DeadlockPage(self.page_frame, self.current_user, self.navigate_to).pack(fill="both", expand=True)
        elif page_id == "settings":
            SettingsPage(self.page_frame, self.current_user, self.navigate_to).pack(fill="both", expand=True)
        elif page_id in ["manage_users", "manage_courses", "system_activity", "my_courses", "assignments", "materials", "grades", "profile"]:
            self._render_generic_view(page_id)
        else:
            self.navigate_to("dashboard")

    def _render_generic_view(self, page_id: str):
        """Clean fallback view for secondary items."""
        container = tk.Frame(self.page_frame, bg=COLOR_BG_LIGHT, padx=24, pady=20)
        container.pack(fill="both", expand=True)

        card = tk.Frame(container, bg=COLOR_CARD_WHITE, padx=20, pady=20, highlightbackground=COLOR_BORDER, highlightthickness=1)
        card.pack(fill="both", expand=True)

        if page_id == "manage_users":
            tk.Label(card, text="Manage System Users", font=("Segoe UI", 14, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(anchor="w", pady=(0, 10))
            users = JSONStore("users.json").load_all()
            for u in users:
                r = tk.Frame(card, bg=COLOR_CARD_WHITE, pady=6, highlightbackground=COLOR_BORDER, highlightthickness=1)
                r.pack(fill="x", pady=2)
                tk.Label(r, text=f"{u.get('id')} - {u.get('name')} (@{u.get('username')})", font=("Segoe UI", 9, "bold"), bg=COLOR_CARD_WHITE).pack(side="left", padx=8)
                tk.Label(r, text=f"Role: {u.get('role').upper()}", font=("Segoe UI", 9), fg=COLOR_PRIMARY_BLUE, bg=COLOR_CARD_WHITE).pack(side="left", padx=8)
                status_txt = "Active" if u.get("is_active", True) else "Inactive"
                tk.Label(r, text=status_txt, font=("Segoe UI", 9), fg="#16A34A" if status_txt == "Active" else "#EF4444", bg=COLOR_CARD_WHITE).pack(side="right", padx=8)

        elif page_id == "system_activity":
            tk.Label(card, text="Complete System Activity Log", font=("Segoe UI", 14, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(anchor="w", pady=(0, 10))
            acts = list(reversed(JSONStore("activity_log.json").load_all()))
            for a in acts[:12]:
                r = tk.Frame(card, bg=COLOR_CARD_WHITE, pady=4, highlightbackground=COLOR_BORDER, highlightthickness=1)
                r.pack(fill="x", pady=2)
                tk.Label(r, text=a.get("timestamp"), font=("Segoe UI", 8), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE, width=20, anchor="w").pack(side="left", padx=6)
                tk.Label(r, text=a.get("activity"), font=("Segoe UI", 9, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(side="left", padx=6)
                tk.Label(r, text=f"by {a.get('user')}", font=("Segoe UI", 8), fg=COLOR_PRIMARY_BLUE, bg=COLOR_CARD_WHITE).pack(side="right", padx=6)
        else:
            tk.Label(card, text=f"Module: {page_id.replace('_', ' ').title()}", font=("Segoe UI", 14, "bold"), fg=COLOR_TEXT_MAIN, bg=COLOR_CARD_WHITE).pack(anchor="w", pady=(0, 10))
            tk.Label(card, text="This section connects directly to your JSON records and courses.", font=("Segoe UI", 10), fg=COLOR_TEXT_MUTED, bg=COLOR_CARD_WHITE).pack(anchor="w")

    def logout(self):
        if messagebox.askyesno("Confirm Logout", "Are you sure you want to sign out?"):
            ActivityLogger.log(f"User signed out ({self.current_user.get('name')})", user=self.current_user.get("name"))
            self.show_login()

if __name__ == "__main__":
    app = SmartLMSApp()
    app.mainloop()
