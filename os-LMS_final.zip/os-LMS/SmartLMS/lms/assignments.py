"""
Assignment management for Smart LMS.
Handles assignment creation, retrieval, and validation.
"""
from typing import List, Dict, Any, Optional
from storage.json_store import JSONStore, ActivityLogger

class AssignmentManager:
    def __init__(self):
        self.store = JSONStore("assignments.json")

    def get_all_assignments(self) -> List[Dict[str, Any]]:
        return self.store.load_all()

    def get_assignments_by_course(self, course_id: str) -> List[Dict[str, Any]]:
        return [a for a in self.get_all_assignments() if a.get("course_id") == course_id]

    def create_assignment(self, course_id: str, course_name: str, title: str, 
                          description: str, due_date: str, max_marks: int, created_by: str) -> Dict[str, Any]:
        existing = [a.get("id") for a in self.get_all_assignments()]
        assignment_id = JSONStore.generate_id("A", existing)
        assignment = {
            "id": assignment_id,
            "course_id": course_id,
            "course_name": course_name,
            "title": title.strip(),
            "description": description.strip(),
            "due_date": due_date.strip(),
            "max_marks": int(max_marks),
            "created_by": created_by
        }
        self.store.add(assignment)
        ActivityLogger.log(f"Assignment created: {title} for {course_name}", user=created_by)
        return assignment
