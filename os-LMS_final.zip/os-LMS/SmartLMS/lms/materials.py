"""
Materials management for Smart LMS.
Handles lecture notes, slides, documents, and local file storage.
"""
from typing import List, Dict, Any
from datetime import datetime
from storage.json_store import JSONStore, ActivityLogger

class MaterialManager:
    def __init__(self):
        self.store = JSONStore("materials.json")

    def get_all_materials(self) -> List[Dict[str, Any]]:
        return self.store.load_all()

    def get_materials_by_course(self, course_id: str) -> List[Dict[str, Any]]:
        return [m for m in self.get_all_materials() if m.get("course_id") == course_id]

    def add_material(self, course_id: str, course_name: str, title: str,
                     file_name: str, file_type: str, file_size: str,
                     uploaded_by: str, uploaded_by_id: str, description: str = "") -> Dict[str, Any]:
        existing = [m.get("id") for m in self.get_all_materials()]
        material_id = JSONStore.generate_id("M", existing)
        material = {
            "id": material_id,
            "course_id": course_id,
            "course_name": course_name,
            "title": title.strip(),
            "file_name": file_name,
            "file_type": file_type.upper(),
            "file_size": file_size,
            "uploaded_by": uploaded_by,
            "uploaded_by_id": uploaded_by_id,
            "date": datetime.now().strftime("%d %b %Y"),
            "description": description.strip()
        }
        self.store.add(material)
        ActivityLogger.log(f"{uploaded_by} uploaded material: {title}", user=uploaded_by, details=f"Course: {course_name}")
        return material

    def delete_material(self, material_id: str, user: str = "Admin") -> bool:
        mat = self.store.get_by_id(material_id)
        name = mat.get("title") if mat else material_id
        success = self.store.delete(material_id)
        if success:
            ActivityLogger.log(f"Material deleted: {name}", user=user)
        return success
