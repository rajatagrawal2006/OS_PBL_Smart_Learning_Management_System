"""
Course management logic for Smart LMS.
Separates view logic from business operations.
"""
from typing import List, Dict, Any, Optional
from datetime import datetime
from storage.json_store import JSONStore, ActivityLogger

class CourseManager:
    def __init__(self):
        self.store = JSONStore("courses.json")
        self.enrollment_store = JSONStore("enrollments.json")

    def get_all_courses(self) -> List[Dict[str, Any]]:
        return self.store.load_all()

    def get_courses_by_teacher(self, teacher_id: str) -> List[Dict[str, Any]]:
        all_courses = self.get_all_courses()
        return [c for c in all_courses if c.get("teacher_id") == teacher_id]

    def get_courses_for_student(self, student_id: str) -> List[Dict[str, Any]]:
        enrollments = self.enrollment_store.load_all()
        student_course_ids = {e.get("course_id") for e in enrollments if e.get("student_id") == student_id}
        all_courses = self.get_all_courses()
        return [c for c in all_courses if c.get("id") in student_course_ids]

    def get_available_courses_for_student(self, student_id: str) -> List[Dict[str, Any]]:
        enrollments = self.enrollment_store.load_all()
        student_course_ids = {e.get("course_id") for e in enrollments if e.get("student_id") == student_id}
        all_courses = self.get_all_courses()
        return [c for c in all_courses if c.get("id") not in student_course_ids and c.get("is_active", True)]

    def enroll_student(self, student_id: str, course_id: str, user_name: str = "Student") -> bool:
        enrollments = self.enrollment_store.load_all()
        for e in enrollments:
            if e.get("student_id") == student_id and e.get("course_id") == course_id:
                return False
        existing_ids = [e.get("id") for e in enrollments]
        eid = JSONStore.generate_id("E", existing_ids)
        new_enrollment = {
            "id": eid,
            "student_id": student_id,
            "course_id": course_id,
            "enrolled_at": datetime.now().strftime("%d %b %Y")
        }
        self.enrollment_store.add(new_enrollment)
        
        course = self.store.get_by_id(course_id)
        if course:
            count = course.get("enrolled_count", 0) + 1
            self.store.update(course_id, {"enrolled_count": count})
            ActivityLogger.log(f"Student enrolled in {course.get('name')} ({course.get('code')})", user=user_name)
        return True

    def drop_course(self, student_id: str, course_id: str, user_name: str = "Student") -> bool:
        enrollments = self.enrollment_store.load_all()
        target = None
        for e in enrollments:
            if e.get("student_id") == student_id and e.get("course_id") == course_id:
                target = e
                break
        if not target:
            return False
        
        self.enrollment_store.delete(target.get("id"))
        
        course = self.store.get_by_id(course_id)
        if course:
            count = max(0, course.get("enrolled_count", 1) - 1)
            self.store.update(course_id, {"enrolled_count": count})
            ActivityLogger.log(f"Student dropped course {course.get('name')} ({course.get('code')})", user=user_name)
        return True

    def create_course(self, code: str, name: str, description: str, teacher_id: str, teacher_name: str) -> Dict[str, Any]:
        existing = [c.get("id") for c in self.get_all_courses()]
        course_id = JSONStore.generate_id("C", existing)
        course = {
            "id": course_id,
            "code": code.strip(),
            "name": name.strip(),
            "teacher_id": teacher_id,
            "teacher_name": teacher_name,
            "description": description.strip(),
            "enrolled_count": 0,
            "is_active": True,
            "created_at": datetime.now().strftime("%d %b %Y")
        }
        self.store.add(course)
        ActivityLogger.log(f"Course created: {course['name']} ({course['code']})", user=teacher_name)
        return course

    def update_course(self, course_id: str, updates: Dict[str, Any], user: str = "Admin") -> bool:
        success = self.store.update(course_id, updates)
        if success:
            ActivityLogger.log(f"Course updated: ID {course_id}", user=user)
        return success

    def delete_course(self, course_id: str, user: str = "Admin") -> bool:
        course = self.store.get_by_id(course_id)
        name = course.get("name") if course else course_id
        success = self.store.delete(course_id)
        if success:
            ActivityLogger.log(f"Course deleted: {name}", user=user)
        return success

