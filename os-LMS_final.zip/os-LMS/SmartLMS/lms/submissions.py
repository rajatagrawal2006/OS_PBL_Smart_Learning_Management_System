"""
Submissions management for Smart LMS.
Handles student assignment submissions, file storage, and grading.
Also triggers optional OS simulator process creation as specified in section 34.
"""
from typing import List, Dict, Any, Optional
from datetime import datetime
from storage.json_store import JSONStore, ActivityLogger

class SubmissionManager:
    def __init__(self):
        self.store = JSONStore("submissions.json")
        self.process_store = JSONStore("processes.json")

    def get_all_submissions(self) -> List[Dict[str, Any]]:
        return self.store.load_all()

    def get_submissions_by_student(self, student_id: str) -> List[Dict[str, Any]]:
        return [s for s in self.get_all_submissions() if s.get("student_id") == student_id]

    def get_submissions_by_course(self, course_name: str) -> List[Dict[str, Any]]:
        return [s for s in self.get_all_submissions() if s.get("course_name") == course_name]

    def get_submissions_by_teacher(self, teacher_id: str) -> List[Dict[str, Any]]:
        try:
            from lms.courses import CourseManager
        except ImportError:
            from SmartLMS.lms.courses import CourseManager
        teacher_courses = CourseManager().get_courses_by_teacher(teacher_id)
        if not teacher_courses:
            return self.get_all_submissions()
        teacher_course_ids = {c.get("id") for c in teacher_courses}
        teacher_course_names = {c.get("name") for c in teacher_courses}
        all_subs = self.get_all_submissions()
        return [
            s for s in all_subs
            if s.get("course_id") in teacher_course_ids or s.get("course_name") in teacher_course_names
        ]


    def submit_assignment(self, assignment_id: str, assignment_title: str, course_name: str,
                          student_id: str, student_name: str, file_name: str, file_size: str = "1.2 MB",
                          create_os_process: bool = True) -> Dict[str, Any]:
        existing = [s.get("id") for s in self.get_all_submissions()]
        submission_id = JSONStore.generate_id("S", existing)
        timestamp = datetime.now().strftime("%d %b %Y, %I:%M %p")

        submission = {
            "id": submission_id,
            "assignment_id": assignment_id,
            "assignment_title": assignment_title,
            "course_name": course_name,
            "student_id": student_id,
            "student_name": student_name,
            "file_name": file_name,
            "file_path": f"uploads/submissions/{file_name}",
            "file_size": file_size,
            "submission_date": timestamp,
            "status": "Submitted",
            "marks": None,
            "feedback": ""
        }
        self.store.add(submission)
        ActivityLogger.log(f"{student_name} submitted {assignment_title}", user=student_name, details=f"File: {file_name}")

        # Optional OS simulated process integration (Section 34)
        if create_os_process:
            processes = self.process_store.load_all()
            existing_pids = [p.get("pid") for p in processes]
            new_pid = JSONStore.generate_id("P", existing_pids)
            proc = {
                "pid": new_pid,
                "name": f"Submission: {student_name[:10]}",
                "task_type": "File Processing",
                "arrival_time": 0,
                "burst_time": 4,
                "remaining_time": 4,
                "priority": 2,
                "memory_req": 120,
                "state": "Ready",
                "creation_time": timestamp
            }
            self.process_store.add(proc)
            ActivityLogger.log(f"Process {new_pid} created (Assignment Submission)", user="OS Simulator")

        return submission

    def grade_submission(self, submission_id: str, marks: int, feedback: str, teacher_name: str) -> bool:
        updates = {
            "status": "Graded",
            "marks": int(marks),
            "feedback": feedback.strip()
        }
        success = self.store.update(submission_id, updates)
        if success:
            ActivityLogger.log(f"Grade assigned for submission {submission_id} ({marks} marks)", user=teacher_name)
        return success
