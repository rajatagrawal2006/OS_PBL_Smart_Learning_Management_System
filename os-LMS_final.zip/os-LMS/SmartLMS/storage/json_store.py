"""
Central JSON storage layer for Smart LMS.
Handles persistence, file-locking safety, ID generation, and system activity logs.
"""
import json
import os
import threading
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional

try:
    from config import DATA_DIR
except ImportError:
    from SmartLMS.config import DATA_DIR

_LOCK = threading.Lock()

class JSONStore:
    def __init__(self, filename: str):
        self.filepath = DATA_DIR / filename
        self._ensure_file()

    def _ensure_file(self):
        if not self.filepath.exists():
            with open(self.filepath, "w", encoding="utf-8") as f:
                json.dump([], f, indent=2)

    def load_all(self) -> List[Dict[str, Any]]:
        with _LOCK:
            try:
                with open(self.filepath, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return []

    def save_all(self, items: List[Dict[str, Any]]) -> bool:
        with _LOCK:
            try:
                temp_path = self.filepath.with_suffix('.tmp')
                with open(temp_path, "w", encoding="utf-8") as f:
                    json.dump(items, f, indent=2)
                temp_path.replace(self.filepath)
                return True
            except Exception as e:
                print(f"Error saving {self.filepath}: {e}")
                return False

    def get_by_id(self, item_id: str, id_key: str = "id") -> Optional[Dict[str, Any]]:
        items = self.load_all()
        for item in items:
            if str(item.get(id_key)) == str(item_id):
                return item
        return None

    def add(self, item: Dict[str, Any]) -> bool:
        items = self.load_all()
        items.append(item)
        return self.save_all(items)

    def update(self, item_id: str, new_data: Dict[str, Any], id_key: str = "id") -> bool:
        items = self.load_all()
        updated = False
        for idx, item in enumerate(items):
            if str(item.get(id_key)) == str(item_id):
                items[idx].update(new_data)
                updated = True
                break
        if updated:
            return self.save_all(items)
        return False

    def delete(self, item_id: str, id_key: str = "id") -> bool:
        items = self.load_all()
        filtered = [item for item in items if str(item.get(id_key)) != str(item_id)]
        if len(filtered) != len(items):
            return self.save_all(filtered)
        return False

    @staticmethod
    def generate_id(prefix: str, existing_ids: List[str]) -> str:
        """Generate a next incremental ID like P101, C101, U101."""
        numbers = []
        for x in existing_ids:
            if str(x).startswith(prefix):
                try:
                    num_str = str(x)[len(prefix):]
                    numbers.append(int(num_str))
                except ValueError:
                    pass
        next_num = max(numbers) + 1 if numbers else 101
        return f"{prefix}{next_num}"


class ActivityLogger:
    @staticmethod
    def log(activity: str, user: str = "System", details: str = ""):
        """Record an activity event into activity_log.json."""
        store = JSONStore("activity_log.json")
        entry = {
            "id": f"act_{int(datetime.now().timestamp() * 1000)}",
            "timestamp": datetime.now().strftime("%d %b %Y, %I:%M %p"),
            "user": user,
            "activity": activity,
            "details": details
        }
        store.add(entry)
